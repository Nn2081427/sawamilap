import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/constants/constants.dart' show Constants;
import 'package:swamiil/core/dialog/drop_down_dialog.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/models/text_field_model.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/profile/domain/usecases/settings_use_case.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/main.dart';
part 'user_profile_state.dart';

class UserProfileCubit extends Cubit<UserProfileState> {
  UserProfileCubit({required this.settingsUseCase})
      : super(UserProfileInitial());

  final SettingsUseCase settingsUseCase;
  String? userUpdatedImage;
  //TextFieldModel userEmail = T
  void initializeUserInputs() {
    userInputs = [
      TextFieldModel(
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthCubit>()
                .userEntity
                ?.email),
        key: "email",
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        validator: (value) => null,
        hint: "enter your email".tr(),
        label: "Email".tr(),
        readOnly: true,
      ),
      TextFieldModel(
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthCubit>()
                .userEntity
                ?.firstName),
        key: "first_name",
        width: 45.w,
        label: "First Name".tr(),
        hint: "enter your first name".tr(),
      ),
      TextFieldModel(
        label: "Last Name".tr(),
        width: 45.w,
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthCubit>()
                .userEntity
                ?.lastName),
        key: "last_name",
        hint: "enter your last name".tr(),
      ),
      TextFieldModel(
        width: double.infinity,
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        controller: TextEditingController(
          text: navigatorKey.currentContext!
              .read<AuthCubit>()
              .userEntity
              ?.city
              ?.name,
        ),
        key: "area_id",
        label: "Area".tr(),
        onTap: () {
          showDropDownDialog(
            navigatorKey.currentContext!.read<CitiesCubit>(),
          ).then((selectedCity) {
            updateDropDown(selectedCity?.name ?? "", "area_id");
          });
        },
        readOnly: true,
        suffix: Icon(
          Icons.arrow_drop_down,
          color: Colors.black,
        ),
        validator: (value) => null,
        hint: "enter your city".tr(),
      ),
      TextFieldModel(
        width: double.infinity,
        suffix: Icon(
          Icons.arrow_drop_down,
          color: Colors.black,
        ),
        onTap: () {
          showDropDownDialog(
            navigatorKey.currentContext!.read<AreaCubit>(),
          ).then((selectedArea) {
            updateDropDown(selectedArea?.name ?? "", "city");
          });
        },
        label: "city".tr(),
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthCubit>()
                .userEntity
                ?.area
                ?.name),
        key: "city",
        readOnly: true,
        validator: (value) => null,
        hint: "enter your city".tr(),
      ),
      TextFieldModel(
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthCubit>()
                .userEntity
                ?.phone),
        key: "phone",
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        hint: "enter your phone number".tr(),
        label: "Phone Number".tr(),
      ),
    ];
  }

  List<TextFieldModel> userInputs = [];

  void updateDropDown(String value, String key) {
    userInputs.firstWhere((e) => e.key == key).controller.text = value;
  }

  Future<void> updateUserProfile() async {
    talker.info("Updating user profile");
    loading();
    talker.info("after loading updateUserProfile");
    emit(UpdateUserProfileLoading());
    try {
      // First create a map of the data
      Map<String, dynamic> dataMap = {};

      for (var element in userInputs) {
        if (element.key == "phone" ||
            element.key == "first_name" ||
            element.key == "last_name") {
          dataMap[element.key!] = element.controller.text;
        }
      }
      dataMap['area_id'] =
          Constants.globalContext().read<AreaCubit>().selectedArea?.id ??
              Constants.globalContext().read<AuthCubit>().userEntity?.area?.id;
      // Handle image separately
      if (userUpdatedImage != null && userUpdatedImage!.isNotEmpty) {
        talker.info("User updated image: $userUpdatedImage");
        if (userUpdatedImage!.startsWith('/')) {
          File imageFile = File(userUpdatedImage!);
          if (await imageFile.exists()) {
            String fileName = imageFile.path.split('/').last;
            dataMap['image'] = await MultipartFile.fromFile(
              imageFile.path,
              filename: fileName,
            );
          }
        }
      }

      // Log all fields
      dataMap.forEach((key, value) {
        talker.info("Field: $key = $value");
      });

      final response = await settingsUseCase.updateUserPofile(data: dataMap);
      navPop();

      response.fold((l) {
        showToast(l.message ?? "Connection error");
        emit(UpdateUserProfileError());
      }, (r) {
        successDialog(
            lottie: Assets.lottieSuccess,
            msg: "Profile Updated Successfully",
            then: () {
              navigatorKey.currentContext!.read<AuthCubit>().getUserInfo();
            });
        emit(UpdateUserProfileLoaded());
      });
    } catch (e) {
      navPop();
      showToast("Error updating profile: ${e.toString()}");
      emit(UpdateUserProfileError());
    }
  }
}
