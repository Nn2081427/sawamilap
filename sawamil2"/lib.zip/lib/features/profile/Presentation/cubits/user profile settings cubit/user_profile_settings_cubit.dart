import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/dialog/report_dialog.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/widgets/web_view.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20settings%20cubit/user_profile_settings_state.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/features/profile/Presentation/screens/user_profile_info_screen.dart';
import 'package:swamiil/main.dart';
import '../../../../user_auth/presentation/cubit/auth_cubit.dart';

class SettingsMenuCubit extends Cubit<SettingsMenuState> {
  SettingsMenuCubit() : super(const SettingsMenuState(items: [])) {
    loadMenuItems();
  }

  void loadMenuItems() {
    emit(SettingsMenuState(items: [
      ProfileMenuItem(
          iconPath: Assets.profileIcon2,
          title: "personal informations".tr(),
          onTap: () => navP(UserProfileInfoScreen())),
      ProfileMenuItem(
        iconPath: Assets.whoweareIcon,
        title: "about us".tr(),
        onTap: () {
          navP(WebViewPage(
              title: "about us".tr(),
              link: navigatorKey.currentContext!
                  .read<SettingsCubit>()
                  .settingsEntity!
                  .aboutLink));
        },
      ),
      ProfileMenuItem(
        iconPath: Assets.messageIcon,
        title: "contact us".tr(),
        //  onTap: () => reportDialog(),
        onTap: () {
          reportDialog(
              title: "write your suggestion or problem", type: "", id: 0);
        },
      ),
      ProfileMenuItem(
        iconPath: Assets.privacyIcon,
        title: "privacy policy".tr(),
        onTap: () {
          navP(WebViewPage(
              title: "Privacy_Policy".tr(),
              link: navigatorKey.currentContext!
                  .read<SettingsCubit>()
                  .settingsEntity!
                  .privacyLink));
        },
      ),
      ProfileMenuItem(
        iconPath: Assets.termsAndConditionsIcon,
        title: "terms and conditions".tr(),
        onTap: () {
          navP(WebViewPage(
              title: "terms and conditions".tr(),
              link: navigatorKey.currentContext!
                  .read<SettingsCubit>()
                  .settingsEntity!
                  .termsLink));
        },
      ),
      ProfileMenuItem(
        iconPath: Assets.logoutIcon,
        title: "delete_account".tr(),
        showTrailing: false,
        textColor: Colors.red,
        leading: const Icon(Icons.delete_outline, color: Colors.red),
        onTap: () {
          confirmDialog(
              title:
                  "إن حذفك للحساب هذا يعني حذف جميع البيانات المتعلقة بحسابك ستفقد طلباتك السابقه",
              confirm: "تأكيد",
              cancel: "ألغاء",
              confirmTap: () {
                getIt.get<AuthCubit>().userDeleteAccount();
              });
        },
      ),
      ProfileMenuItem(
        iconPath: Assets.logoutIcon,
        title: "log out".tr(),
        showTrailing: false,
        textColor: Colors.red,
        onTap: () {
          confirmDialog(
              title: "هل تريد حقا تسجيل الخروج",
              confirm: "تأكيد",
              cancel: "ألغاء",
              confirmTap: () {
                getIt.get<AuthCubit>().userLogout();
              });
        },
      ),
    ]));
  }
}
