import 'package:flutter/material.dart';

class ProfileMenuItem {
  final String iconPath;
  final String title;
  final void Function()? onTap;
  final Color? textColor;
  final Widget? leading;
  final bool? showTrailing;

  const ProfileMenuItem({
    required this.iconPath,
    this.showTrailing = true,
    required this.title,
    this.onTap,
    this.leading,
    this.textColor,
  });
}

class SettingsMenuState {
  final List<ProfileMenuItem> items;

  const SettingsMenuState({required this.items});
}
