import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/features/profile/domain/entities/settings_entity.dart';
import 'package:swamiil/features/profile/domain/usecases/settings_use_case.dart';

part 'settings_state.dart';

class SettingsCubit extends Cubit<SettingsState> {
  SettingsCubit(this.settingsUseCase) : super(SettingsInitial()) {
    _initializeSettings();
  }

  final SettingsUseCase settingsUseCase;
  bool _isFetched = false;

  SettingsEntity? settingsEntity;

  Future<void> _initializeSettings() async {
    if (!_isFetched) {
      emit(SettingsLoading());
      final result = await settingsUseCase.getSettings();
      _isFetched = true;
      result.fold(
        (l) => emit(SettingsError(l.message ?? "Unknown error")),
        (r) {
          print("settings cubit" + r.email);

          settingsEntity = r;
          emit(SettingsLoaded(r));
        },
      );
    }
  }

  Future<void> getSettings() async {
    if (!_isFetched) {
      await _initializeSettings();
    }
  }

  Future<void> refreshSettings() async {
    _isFetched = false;
    await _initializeSettings();
  }

  Future<void> contactUs({required Map<String, dynamic> data}) async {
    final result = await settingsUseCase.contactUs(data: data);
    result.fold((l) {
      showToast(l.message ?? "Unknown error");
    }, (r) {
      successDialog(msg: "contact_us_success".tr(), lottie: Assets.lottieSuccess);
    });
  }
}
