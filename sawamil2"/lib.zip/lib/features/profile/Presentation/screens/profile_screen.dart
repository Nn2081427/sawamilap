import 'package:flutter/material.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/supplier_information_widget.dart';
import 'package:swamiil/features/profile/Presentation/widgets/user_profile_widget.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int selectedIndex = 0; // 0 = Option A, 1 = Option B

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBarWidget(title: ""),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // const SizedBox(height: 5),
            const Center(
                child: UserProfileWidget(

              showEmail: false, isUser: true,
            )),
            const SizedBox(height: 30),
            Expanded(child: SupplierInformationsWidget()),
          ],
        ),
      ),
    );
  }
}
