import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/list_text_field.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/profile/Data/repositries/settings_repo_Impl.dart';
import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20cubit/user_profile_cubit.dart';
import 'package:swamiil/features/profile/Presentation/widgets/ProfileImage.dart';
import 'package:swamiil/features/profile/domain/usecases/settings_use_case.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/main.dart';

class UserProfileInfoScreen extends StatefulWidget {
  const UserProfileInfoScreen({super.key});

  @override
  State<UserProfileInfoScreen> createState() => _UserProfileInfoScreenState();
}

class _UserProfileInfoScreenState extends State<UserProfileInfoScreen> {
  final formFieldKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    context.read<CitiesCubit>().getCities();
    context
        .read<AreaCubit>()
        .getAreas(context.read<AuthCubit>().userEntity!.id);

    return AnnotatedRegion(
      value: barColor(),
      child: SafeArea(
        top: true,
        bottom: false,
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBarWidget(title: "personal_info".tr()),
          body: BlocBuilder<UserProfileCubit, UserProfileState>(
            builder: (context, state) {
              var cubit = context.read<UserProfileCubit>()
                ..initializeUserInputs();

              return SingleChildScrollView(
                child: Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 5.h),
                    child: Form(
                      key: formFieldKey,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Center(
                                child: Hero(
                              tag: "user_profile",
                              child: ProfileImage(
                                imageUrl:
                                    context.read<AuthCubit>().userEntity?.image,
                                onImagePicked: (p0) {
                                  context
                                      .read<UserProfileCubit>()
                                      .userUpdatedImage = p0;
                                },
                              ),
                            )),
                            SizedBox(height: 3.h),
                            //      ListTextFieldWidget(inputs: [cubit.userEmail]),
                            SizedBox(height: 1.h),
                            ListTextFieldWidget(
                              inputs: cubit.userInputs,
                              isWrap: true,
                            ),
                            SizedBox(height: 1.h),
                            //   ListTextFieldWidget(inputs: cubit.userDataInputs),
                            SizedBox(height: 1.h),
                            CustomButton(
                              onTap: () {
                                if (formFieldKey.currentState!.validate()) {
                                  talker.info("save changes");
                                  context
                                      .read<UserProfileCubit>()
                                      .updateUserProfile();
                                }
                              },
                              backgroundColor: AppColors.mainColor,
                              padding: EdgeInsets.symmetric(vertical: 12),
                              borderRadius: BorderRadius.circular(8),
                              child: Center(
                                child: Text(
                                  "save_changes".tr(),
                                  style: Fonts.textWhite18,
                                ),
                              ),
                            ),
                          ]),
                    )),
              );
            },
          ),
        ),
      ),
    );
  }
}
