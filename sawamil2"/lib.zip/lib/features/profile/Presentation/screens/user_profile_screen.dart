import 'package:easy_localization/easy_localization.dart'; // Added import
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';

import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20settings%20cubit/user_profile_settings_cubit.dart';
import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20settings%20cubit/user_profile_settings_state.dart';
import 'package:swamiil/features/profile/Presentation/widgets/SettingsListTile.dart';
import 'package:swamiil/features/profile/Presentation/widgets/user_profile_widget.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';

class UserProfileScreen extends StatelessWidget {
  const UserProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => SettingsMenuCubit(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 12.h),
              Center(
                child: UserProfileWidget(
                  isUser: true,
                  userEntity: context.read<AuthCubit>().userEntity,
                ),
              ),
              SizedBox(height: 2.h),
              BlocBuilder<SettingsMenuCubit, SettingsMenuState>(
                builder: (context, state) {
                  return Column(
                    children: state.items.map((item) {
                      return Padding(
                        padding: EdgeInsets.only(bottom: 0.5.h),
                        child: Column(
                          children: [
                            SettingsListTile(
                              iconPath: item.iconPath,
                              title: item.title,
                              onTap: item.onTap,
                              showTrailing: item.showTrailing ?? true,
                              textColor: item.textColor,
                              leading: item.leading,
                            ),
                            Divider(
                              thickness: 1,
                              color: Colors.grey.shade300.withOpacity(0.4),
                              endIndent: 20,
                              indent: 20,
                            )
                          ],
                        ),
                      );
                    }).toList(),
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
