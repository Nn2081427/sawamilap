import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

class ProfileField extends StatelessWidget {
  final String label;
  final Widget child;
  final String? icon;

  const ProfileField({super.key, required this.label, required this.child, this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: Fonts.text16Black.copyWith(fontWeight: FontWeight.bold),
            ),
            if (icon != null) ...[
              SizedBox(width: 2.w),
              SvgPicture.asset(
                icon!,
                width: 5.w,
                height: 5.w,
              ),
            ],
          ],
        ),
        SizedBox(height: 1.h),
        child,
      ],
    );
  }
}
