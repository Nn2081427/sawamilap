import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/utilies/ImagePickerUtil.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';

class ProfileImage extends StatefulWidget {
  final Function(String) onImagePicked;
  final bool? isAuthScreen;
  final String? imageUrl;
  const ProfileImage(
      {super.key,
      required this.onImagePicked,
      this.isAuthScreen = false,
      this.imageUrl});

  @override
  State<ProfileImage> createState() => _ProfileImageState();
}

class _ProfileImageState extends State<ProfileImage> {
  String? _imagePath;

  @override
  void initState() {
    super.initState();
    // Initialize _imagePath with imageUrl if provided
    _imagePath = widget.imageUrl;
  }

  @override
  void didUpdateWidget(ProfileImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Update _imagePath if imageUrl changes from parent
    if (widget.imageUrl != oldWidget.imageUrl) {
      _imagePath = widget.imageUrl;
    }
  }

  Widget _buildImage() {
    // Priority: local picked image > network image > placeholder
    if (_imagePath != null && _imagePath!.startsWith('/')) {
      // Local file path (picked image)
      return GestureDetector(
        onTap: openImagePicker,
        child: Image.file(
          File(_imagePath!),
          width: 25.w,
          height: 25.w,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => Container(
            width: 25.w,
            height: 25.w,
            color: Colors.grey[300],
            child: Icon(
              Icons.person,
              size: 12.w,
              color: Colors.grey[600],
            ),
          ),
        ),
      );
    } else if (_imagePath != null &&
        (_imagePath!.startsWith('http') || _imagePath!.startsWith('https'))) {
      // Network image URL
      return CustomImageCacheProvider(
        imageUrl: _imagePath!,
        width: 25.w,
        height: 25.w,
        borderRadius: 50,
      );
    } else {
      // Placeholder when no image
      return Container(
        width: 25.w,
        height: 25.w,
        color: Colors.grey[300],
        child: Icon(
          Icons.person,
          size: 12.w,
          color: Colors.grey[600],
        ),
      );
    }
  }

  void openImagePicker() async {
    final imageResult = await ImagePickerUtil.showImageSourcePicker(
      context: context,
      onLoading: (_) {},
    );
    if (imageResult != null) {
      setState(() {
        _imagePath = imageResult.path;
      });
      widget.onImagePicked(imageResult.path!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async => openImagePicker(),
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          ClipOval(
            child: _buildImage(),
          ),
          GestureDetector(
            onTap: () async => openImagePicker(),
            child: widget.isAuthScreen!
                ? Container(
                    padding: EdgeInsets.all(1.w),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 4,
                          offset: const Offset(0, 6),
                        )
                      ],
                    ),
                    child: Icon(Icons.camera_alt_outlined,
                        size: 6.w, color: AppColors.mainColor))
                : SvgPicture.asset(
                    Assets.editIcon,
                    width: 6.w,
                    height: 6.w,
                  ),
          ),
        ],
      ),
    );
  }
}
