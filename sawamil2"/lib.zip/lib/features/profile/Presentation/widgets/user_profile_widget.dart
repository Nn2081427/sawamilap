import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';
import 'package:swamiil/main.dart';

import '../../../auth_supplier/domain/entities/supplier_entity.dart';

class UserProfileWidget extends StatelessWidget {
  const UserProfileWidget(
      {super.key,
      required this.isUser,
      this.showEmail = true,
      this.supplierEntity,
      this.userEntity});

  final bool? showEmail;
  final bool isUser;
  final SupplierEntity? supplierEntity;
  final UserEntity? userEntity;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Hero(
            tag: "user_profile",
            child: CustomImageCacheProvider(
              imageUrl: isUser
                  ? (userEntity?.image ?? '')
                  : (supplierEntity?.image ?? ''),
              width: 30.w,
              height: 15.h,
              borderRadius: 100,
            ),
          ),
          SizedBox(
            height: 13,
          ),
          Text(
            isUser
                ? "${userEntity?.firstName} ${userEntity?.lastName ?? ""}"
                : "${supplierEntity?.firstName} ${supplierEntity?.lastName}",
            style: Fonts.headTitle20,
          ),
          SizedBox(
            height: 0.5.h,
          ),
          isUser
              ? showEmail!
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          Assets.emailIcon,
                          width: 20,
                          height: 20,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          userEntity?.email ?? "",
                          style: Fonts.textSplash14.copyWith(
                              color: Colors.black.withOpacity(0.6),
                              fontSize: 16),
                        ),
                      ],
                    )
                  : Container()
              : Container(),
          // Text(
          //     "ID : 2291450493",
          //     style: Fonts.text14Black,
          //   ),
          SizedBox(
            height: 1.5.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SvgPicture.asset(
                Assets.locationIcon,
                width: 20,
                height: 20,
              ),
              SizedBox(
                width: 5,
              ),
              Text(
                isUser
                    ? "${userEntity?.area?.city!.name} - ${userEntity?.area?.name}"
                    : supplierEntity?.area?.city?.name ?? "",
                style: Fonts.textSplash14.copyWith(
                    color: Colors.black.withOpacity(0.6), fontSize: 16),
              ),
            ],
          ),
          SizedBox(
            height: 20,
          ),
          // isUser
          //     ? SizedBox()
          //     : Container(
          //         padding: EdgeInsets.all(8),
          //         width: 55,
          //         decoration: BoxDecoration(
          //           color: AppColors.mainColor,
          //           borderRadius: BorderRadius.circular(8),
          //         ),
          //         child: Center(
          //             child: Text(
          //           "موثق".tr(),
          //           style: Fonts.textSplash14
          //               .copyWith(fontWeight: FontWeight.bold),
          //         )),
          //       )
        ],
      ),
    );
  }
}
