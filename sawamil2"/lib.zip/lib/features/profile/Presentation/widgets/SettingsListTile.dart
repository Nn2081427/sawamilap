// SettingsListTile.dart
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

class SettingsListTile extends StatelessWidget {
  const SettingsListTile({
    super.key,
    required this.title,
    required this.iconPath,
    this.onTap,
    this.textColor,
    this.trailing,
    this.leading,
    this.showTrailing = true, // Set default to true
  });

  final String title;
  final String iconPath;
  final void Function()? onTap;
  final Color? textColor;
  final Widget? trailing;
  final Widget? leading;
  final bool showTrailing; // Changed to non-nullable with default value

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 7.h,
      child: Column(
        children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            minLeadingWidth: 25,
            horizontalTitleGap: 3.w,
            dense: true,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            visualDensity: const VisualDensity(vertical: -4),
            leading: leading ??
                SvgPicture.asset(
                  iconPath,
                  width: 3.w,
                  height: 3.h,
                  fit: BoxFit.contain,
                ),
            title: Text(
              title,
              style: Fonts.text16Black.copyWith(
                fontWeight: FontWeight.w500,
                color: textColor,
                fontSize: 16.sp,
              ),
            ),
            trailing: trailing ??
                (showTrailing
                    ? Icon(
                        Icons.arrow_forward_ios,
                        size: 15.sp,
                        color: Colors.black,
                      )
                    : null),
            onTap: onTap,
          ),
          SizedBox(
            height: 15,
          ),
          Container(
            height: 1,
            width: double.infinity,
            color: Colors.grey.shade100,
          ),
        ],
      ),
    );
  }
}
