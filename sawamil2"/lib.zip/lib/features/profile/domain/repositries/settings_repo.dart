import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/profile/Data/models/settings_model.dart';
import 'package:swamiil/features/profile/domain/entities/settings_entity.dart';

abstract class SettingsRepo {
  Future<Either<DioException, SettingsEntity>> getSettings();

  Future<Either<DioException, void>> updateUserPofile({required Map<String, dynamic> data});

  Future<Either<DioException, bool>> contactUs({required Map<String, dynamic> data});
}
