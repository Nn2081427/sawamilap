class SettingsEntity {
  final int id;
  final num percentage;
  final String email;
  final String supportEmail;
  final int userVersion;
  final bool mustUpdateUser;
  final String termsLink;
  final String privacyLink;
  final String aboutLink;
  final String refundLink;

  const SettingsEntity({
    required this.id,
    required this.percentage,
    required this.email,
    required this.supportEmail,
    required this.userVersion,
    required this.mustUpdateUser,
    required this.termsLink,
    required this.privacyLink,
    required this.aboutLink,
    required this.refundLink,
  });
}