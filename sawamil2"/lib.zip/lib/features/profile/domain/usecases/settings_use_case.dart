import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/profile/domain/entities/settings_entity.dart';
import 'package:swamiil/features/profile/domain/repositries/settings_repo.dart';

class SettingsUseCase {
  final SettingsRepo settingsRepo;
  SettingsUseCase({required this.settingsRepo});

  Future<Either<DioException, SettingsEntity>> getSettings() async {
    return await settingsRepo.getSettings();
  }

  Future<Either<DioException, void>> updateUserPofile({required Map<String, dynamic> data}) async {
    return await settingsRepo.updateUserPofile(data: data);
  }

  Future<Either<DioException, bool>> contactUs({required Map<String, dynamic> data}) async {
    return await settingsRepo.contactUs(data: data);
  }
}
