import 'package:dartz/dartz.dart';
import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/profile/Data/datasource/settings_remote_data_source.dart';
import 'package:swamiil/features/profile/Data/models/settings_model.dart';
import 'package:swamiil/features/profile/domain/entities/settings_entity.dart';
import 'package:swamiil/features/profile/domain/repositries/settings_repo.dart';

class SettingsRepoImpl extends SettingsRepo {
  @override
  Future<Either<DioException, SettingsEntity>> getSettings() async {
    return await SettingsRemoteDataSource.getSettings();
  }

  @override
  Future<Either<DioException, void>> updateUserPofile(
      {required Map<String, dynamic> data}) async {
    return await SettingsRemoteDataSource.updateUserPofile(data: data);
  }

  @override
  Future<Either<DioException, bool>> contactUs(
      {required Map<String, dynamic> data}) async {
    return await SettingsRemoteDataSource.contactUs(data: data);
  }
}
