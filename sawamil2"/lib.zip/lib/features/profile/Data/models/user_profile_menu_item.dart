import 'package:flutter/material.dart';

class ProfileMenuItem {
  final String iconPath;
  final String title;
  final void Function()? onTap;
  final Color? textColor;

  const ProfileMenuItem({
    this.textColor,
    required this.iconPath,
    required this.title,
    this.onTap,
  });
}