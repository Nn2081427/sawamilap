import 'dart:io';

import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/profile/domain/entities/settings_entity.dart';

class SettingsModel extends SettingsEntity {
  SettingsModel({
    required super.id,
    required super.percentage,
    required super.email,
    required super.supportEmail,
    required super.userVersion,
    required super.mustUpdateUser,
    required super.termsLink,
    required super.privacyLink,
    required super.aboutLink,
    required super.refundLink,
  });

  factory SettingsModel.fromJson(Map<String, dynamic> data) {
    print('Parsing SettingsModel at ${DateTime.now().toLocal()}'); // Debug log
    return SettingsModel(
      id: convertStringToInt(data['id']),
      percentage: data['percentage'] as int? ?? 0,
      email: data['email'] as String? ?? '',
      supportEmail: data['support_email'] as String? ?? '',
      userVersion: convertStringToInt(
          Platform.isAndroid ? data['user_version'] : data['user_version_ios']),
      mustUpdateUser: convertDataToBool(data['must_update_user']),
      termsLink: data['terms_link'] as String? ?? '',
      privacyLink: data['privacy_link'] as String? ?? '',
      aboutLink: data['about_link'] as String? ?? '',
      refundLink: data['refund_link'] as String? ?? '',
    );
  }
}
