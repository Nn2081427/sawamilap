import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/features/profile/Data/models/settings_model.dart';

class SettingsRemoteDataSource {
  static Future<Either<DioException, SettingsModel>> getSettings() async {
    var response = await ApiHandel.getInstance.get('get_settings');
    return response.fold((l) => Left(l), (r) {
      return Right(SettingsModel.fromJson(r.data['data']));
    });
  }

  static Future<Either<DioException, void>> updateUserPofile(
      {required Map<String, dynamic> data}) async {
    var response =
        await ApiHandel.getInstance.post('user/update_profile', data);
    return response.fold((l) => Left(l), (r) {
      return Right(null);
    });
  }

  static Future<Either<DioException, bool>> contactUs(
      {required Map<String, dynamic> data}) async {
    var response =
        await ApiHandel.getInstance.post('user/create_contact_us', data);
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }
}
