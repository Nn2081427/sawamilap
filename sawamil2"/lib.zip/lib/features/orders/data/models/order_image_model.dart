import '../../domain/entity/order_image_entity.dart';

class OrderImageModel extends OrderImageEntity {
  OrderImageModel({
    super.id,
    super.image,
    super.orderId,
  });

  factory OrderImageModel.fromJson(Map<String, dynamic> json) {
    return OrderImageModel(
      id: json['id'],
      image: json['image'],
      orderId: json['order_id'],
    );
  }
}