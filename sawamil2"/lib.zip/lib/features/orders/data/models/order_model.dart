import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/brands/data/models/brand_type_model.dart';
import 'package:swamiil/features/brands/data/models/brands_model.dart';
import 'package:swamiil/features/offers/data/models/offer_model.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/user_auth/Data/models/user_model.dart';

import 'order_image_model.dart';

class OrderModel extends OrderEntity {
  OrderModel({
    required super.id,
    required super.year,
    required super.brandName,
    required super.notes,
    required super.orderType,
    required super.status,
    required super.statusName,
    required super.cancelReason,
    required super.createdAt,
    required super.acceptedOffer,
    required super.appliedOffer,
    required super.isRated,
    required super.isUserComplaint,
    required super.isSupplierComplaint,
    required super.images,
    required super.brand,
    required super.brandModel,
    required super.statusDescription,
    required super.user,
    required super.offerNumbers,
    required super.title,
  });

  factory OrderModel.fromJson(Map<String, dynamic> json, {int total = 0}) {
    BrandModel? brandModel;
    BrandsTypeModel? brandsTypeModel;
    if (json.containsKey('brand') && json['brand'] != null) {
      brandModel = BrandModel.fromJson(json['brand']);
      brandsTypeModel = BrandsTypeModel.fromJson(json['brand_model']);
    }

    UserModel? userModel;
    if (json.containsKey('user') && json['user'] != null) {
      userModel = UserModel.fromJson(json['user']);
    }

    OfferModel? offerModel;
    if (json.containsKey('offer') && json['offer'] != null) {
      offerModel = OfferModel.fromJson(json['offer']);
    }
    List<OrderImageModel> images = [];
    if (json.containsKey('images') && json['images'] != null) {
      for (var i in json['images']) {
        images.add(OrderImageModel.fromJson(i));
      }
    }
    print('hamza order entity');
    return OrderModel(
      id: json['id'],
      year: json['year'],
      brandName: json['brand_name'],
      notes: json['notes'],
      offerNumbers: convertStringToInt(json['offer_numbers']),
      orderType: json['order_type'] == 'buy' ? OrderType.buy : OrderType.sell,
      status: orderStatusMap[json['status']],
      statusName: json['status_name'],
      cancelReason: json['cancel_reason'],
      statusDescription: json['status_description'],
      title: json['title'] ?? '',
      user: userModel,
      createdAt: DateTime.parse(json['created_at']),
      acceptedOffer: offerModel,
      appliedOffer: convertDataToBool(json['applied_offer']),
      isRated: convertDataToBool(json['is_rated']),
      isUserComplaint: convertDataToBool(json['is_user_complaint']),
      isSupplierComplaint: convertDataToBool(json['is_supplier_complaint']),
      images: images,
      brand: brandModel,
      brandModel: brandsTypeModel,
    );
  }
}
