import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/features/orders/data/models/order_model.dart';

class OrderRemoteDataSource {
  final ApiHandel apiHandel;

  OrderRemoteDataSource({required this.apiHandel});

  Future<Either<DioException, List<OrderModel>>> getNewOrders() async {
    var response = await apiHandel.get('user/get_new_orders');
    List<OrderModel> data = [];
    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        data.add(OrderModel.fromJson(i));
      }
      return Right(data);
    });
  }

  Future<Either<DioException, List<OrderModel>>> getWaitingOrders(
      {required int pageKey}) async {
    var response = await apiHandel.get('user/get_current_orders', {
      "page": pageKey,
      // "skip": 2,
    });
    List<OrderModel> data = [];
    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        data.add(OrderModel.fromJson(i));
      }
      return Right(data);
    });
  }

  Future<Either<DioException, List<OrderModel>>> getEndedOrders(
      {required int pageKey}) async {
    var response = await apiHandel.get(
      'user/get_ended_orders',
      {
        "page": pageKey,
        //  "skip": 2,
      },
    );
    List<OrderModel> data = [];

    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        data.add(OrderModel.fromJson(i),);
      }
      // navigatorKey.currentContext!.read<OrderCubit>().totalPages =
      //     r.data['pages_count'] ?? 0;
      return Right(data);
    });
  }

  Future<Either<DioException, bool>> updateOrderStatus(
    Map<String, dynamic>? data,
  ) async {
    var response = await apiHandel.post('supplier/update_order_status', data!);
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }

  Future<Either<DioException, void>> reportAnIssue(
      {required int orderId, required String message}) async {
    var response = await apiHandel.post(
        'user/create_complaint', {"order_id": orderId, "message": message});
    return response.fold((l) => Left(l), (r) {
      return Right(null);
    });
  }

  Future<Either<DioException, List<OrderModel>>> getAllOrders(
      {required int pageKey}) async {
    var response = await apiHandel.get(
      'supplier/get_suppliers_orders',
      {
        "page": pageKey,
        //  "skip": 2,
      },
    );
    List<OrderModel> data = [];
    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        data.add(OrderModel.fromJson(i));
      }
      return Right(data);
    });
  }

  // hide order
  Future<Either<DioException, bool>> hideOrder({required int orderId}) async {
    var response =
        await apiHandel.post('supplier/hide_order', {'order_id': orderId});
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }

  // get new supplier orders
  Future<Either<DioException, List<OrderModel>>> getSupplierNewOrders(
      {Map<String, dynamic>? data, required int pageKey}) async {
    var response = await apiHandel.post(
      'supplier/get_supplier_new_orders',
      {
        "page": pageKey,
        //  "skip": 2,
      },
    );
    List<OrderModel> newOrders = [];
    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        newOrders.add(OrderModel.fromJson(i));
      }
      return Right(newOrders);
    });
  }

  // get supplier order
  Future<Either<DioException, OrderModel>> getSupplierOrder({
    required int orderId,
  }) async {
    var response = await apiHandel
        .post('supplier/get_supplier_order', {'order_id': orderId});
    return response.fold((l) => Left(l), (r) {
      return Right(OrderModel.fromJson(r.data['data']));
    });
  }
}
