import 'package:dartz/dartz.dart';
import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/orders/data/data_source/order_remote_data_source.dart';
import 'package:swamiil/features/orders/data/models/order_model.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/orders/domain/repos/order_repo.dart';

class OrderRepoImpl extends OrderRepo {
  final OrderRemoteDataSource orderRemoteDataSource;

  OrderRepoImpl({required this.orderRemoteDataSource});
  @override
  Future<Either<DioException, List<OrderModel>>> getNewOrders() async {
    return await orderRemoteDataSource.getNewOrders();
  }

  @override
  Future<Either<DioException, List<OrderModel>>> getEndedOrders(
      {required int pageKey}) async {
    return await orderRemoteDataSource.getEndedOrders(pageKey: pageKey);
  }

  @override
  Future<Either<DioException, List<OrderModel>>> getWaitingOrders(
      {required int pageKey}) async {
    return await orderRemoteDataSource.getWaitingOrders(pageKey: pageKey);
  }

  @override
  Future<Either<DioException, void>> reportAnIssue(
      {required int orderId, required String message}) async {
    return await orderRemoteDataSource.reportAnIssue(
        orderId: orderId, message: message);
  }

  @override
  Future<Either<DioException, List<OrderEntity>>> getAllSupplierOrders(
      {required int pageKey}) async {
    return await orderRemoteDataSource.getAllOrders(pageKey: pageKey);
  }

  @override
  Future<Either<DioException, List<OrderEntity>>> getNewSupplierOrders(
      {Map<String, dynamic>? data, required int pageKey}) async {
    return await orderRemoteDataSource.getSupplierNewOrders(pageKey: pageKey);
  }

  @override
  Future<Either<DioException, OrderEntity>> getSupplierOrder(
      {required int orderId}) async {
    return await orderRemoteDataSource.getSupplierOrder(orderId: orderId);
  }

  @override
  Future<Either<DioException, bool>> hideOrder({required int orderId}) async {
    return await orderRemoteDataSource.hideOrder(orderId: orderId);
  }

  @override
  Future<Either<DioException, bool>> updateOrderStatus(
      Map<String, dynamic> data) async {
    return await orderRemoteDataSource.updateOrderStatus(data);
  }
}
