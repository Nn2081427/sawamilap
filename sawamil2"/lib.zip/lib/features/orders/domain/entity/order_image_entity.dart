class OrderImageEntity {
  final int? id;
  final String? image;
  final int? orderId;

  const OrderImageEntity({
    this.id,
    this.image,
    this.orderId,
  });
}