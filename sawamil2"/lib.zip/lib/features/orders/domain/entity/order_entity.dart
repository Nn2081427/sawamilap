import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';

import '../../../../core/helper_function/helper_function.dart';
import '../../../brands/domain/entities/brands_entitiy.dart';
import 'order_image_entity.dart';

class OrderEntity {
  final int id;
  final String year;
  final String? brandName;
  final String? notes;
  final OrderType orderType;
  final OrderStatus status;
  final String? statusName;
  final String? cancelReason;
  final String? statusDescription;
  final String? title;
  // int pagesCount;
  final DateTime createdAt;
  bool appliedOffer;
  bool isRated;
  bool isUserComplaint;
  bool isSupplierComplaint;
  final List<OrderImageEntity> images;
  final BrandEntity? brand;
  final BrandTypeEntity? brandModel;
  final OfferEntity? acceptedOffer;
  final UserEntity? user;
  int offerNumbers;

  OrderEntity({
    required this.id,
    required this.year,
    required this.title,
    required this.brandName,
    required this.notes,
    required this.orderType,
    required this.status,
    required this.statusName,
    required this.cancelReason,
    required this.statusDescription,
    required this.offerNumbers,
    // required this.pagesCount,
    required this.createdAt,
    required this.acceptedOffer,
    required this.appliedOffer,
    required this.isRated,
    required this.isUserComplaint,
    required this.isSupplierComplaint,
    required this.images,
    required this.brand,
    required this.brandModel,
    required this.user,
  });

  String? get formattedBrandWithYear {
    final name = brandName ?? "${brand?.name}_${brandModel?.name}";
    // if (name == "" || year == null) return null;
    return '${name}_$year';
  }

  String getStatus() {
    return getKeyByValue(orderStatusMap, status)!;
  }

  String getType() {
    return getKeyByValue(orderTypeMap, orderType)!;
  }

  String? imageClint() {
    return user?.image ?? acceptedOffer?.supplier?.image;
  }

  String? nameClint() {
    if (user != null) {
      return userName();
    } else {
      return supplierName();
    }
  }

  String? userName() {
    if (user != null) {
      return "${user!.firstName!} ${user!.lastName!}";
    }
    return null;
  }

  String? supplierName() {
    if (acceptedOffer != null) {
      return "${acceptedOffer?.supplier?.firstName!} ${acceptedOffer?.supplier?.lastName!}";
    }
    return null;
  }

  String? cityClint() {
    if (user != null) {
      return "${user?.city?.name}";
    } else {
      return "${acceptedOffer?.supplier?.city?.name}";
    }
  }

  OrderEntity copyWith({
    int? id,
    String? year,
    String? title,
    String? brandName,
    String? notes,
    OrderType? orderType,
    OrderStatus? status,
    String? statusName,
    String? cancelReason,
    String? statusDescription,
    int? offerNumbers,
    // int? total,
    // int? pagesCount,
    DateTime? createdAt,
    OfferEntity? acceptedOffer,
    bool? appliedOffer,
    bool? isRated,
    bool? isSupplierComplaint,
    List<OrderImageEntity>? images,
    BrandEntity? brand,
    BrandTypeEntity? brandModel,
    UserEntity? user,
    bool? isUserComplaint,
  }) {
    return OrderEntity(
        id: id ?? this.id,
        year: year ?? this.year,
        title: title ?? this.title,
        brandName: brandName ?? this.brandName,
        notes: notes ?? this.notes,
        orderType: orderType ?? this.orderType,
        status: status ?? this.status,
        statusName: statusName ?? this.statusName,
        cancelReason: cancelReason ?? this.cancelReason,
        statusDescription: statusDescription ?? this.statusDescription,
        offerNumbers: offerNumbers ?? this.offerNumbers,
        createdAt: createdAt ?? this.createdAt,
        appliedOffer: appliedOffer ?? this.appliedOffer,
        isRated: isRated ?? this.isRated,
        isUserComplaint: isUserComplaint ?? this.isUserComplaint,
        isSupplierComplaint: isSupplierComplaint ?? this.isSupplierComplaint,
        images: images ?? this.images,
        brand: brand ?? this.brand,
        brandModel: brandModel ?? this.brandModel,
        acceptedOffer: acceptedOffer ?? this.acceptedOffer,
        user: user ?? this.user);
  }

}

Map orderStatusMap = {
  "new": OrderStatus.newOrder,
  "in_progress": OrderStatus.inProgress,
  "user_cancelled": OrderStatus.userCancelled,
  "completed": OrderStatus.completed,
  "admin_cancelled": OrderStatus.adminCancelled,
  "supplier_cancelled": OrderStatus.supplierCancelled,
};

Map orderTypeMap = {
  "sell": OrderType.sell,
  "buy": OrderType.buy,
};

enum OrderType { buy, sell }

enum OrderStatus {
  newOrder,
  inProgress,
  completed,
  userCancelled,
  supplierCancelled,
  adminCancelled
}
