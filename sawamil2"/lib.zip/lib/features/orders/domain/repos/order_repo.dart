import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/orders/data/models/order_model.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

abstract class OrderRepo {
  Future<Either<DioException, List<OrderEntity>>> getNewOrders();

  Future<Either<DioException, List<OrderEntity>>> getWaitingOrders(
      {required int pageKey});

  Future<Either<DioException, List<OrderEntity>>> getEndedOrders(
      {required int pageKey});

  Future<Either<DioException, void>> reportAnIssue(
      {required int orderId, required String message});

  Future<Either<DioException, List<OrderEntity>>> getAllSupplierOrders(
      {required int pageKey});
  // hide order
  Future<Either<DioException, bool>> hideOrder({required int orderId});

  /// get new orders
  Future<Either<DioException, List<OrderEntity>>> getNewSupplierOrders(
      {Map<String, dynamic>? data, required int pageKey});
  // update order status
  Future<Either<DioException, bool>> updateOrderStatus(
      Map<String, dynamic> data);

  /// get supplier order
  Future<Either<DioException, OrderEntity>> getSupplierOrder(
      {required int orderId});
}
