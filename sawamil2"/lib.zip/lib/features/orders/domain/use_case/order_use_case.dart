import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/orders/domain/repos/order_repo.dart';

class OrderUseCase {
  final OrderRepo orderRepo;

  OrderUseCase({required this.orderRepo});

  Future<Either<DioException, List<OrderEntity>>> getNewOrders() async {
    return await orderRepo.getNewOrders();
  }

  Future<Either<DioException, List<OrderEntity>>> getEndedOrders(
      {required int pageKey}) async {
    return await orderRepo.getEndedOrders(pageKey: pageKey);
  }

  Future<Either<DioException, List<OrderEntity>>> getWaitingOrders(
      {required int pageKey}) async {
    return await orderRepo.getWaitingOrders(pageKey: pageKey);
  }

  Future<Either<DioException, void>> reportAnIssue(
      {required int orderId, required String message}) async {
    return await orderRepo.reportAnIssue(orderId: orderId, message: message);
  }

  Future<Either<DioException, List<OrderEntity>>> getAllSupplierOrders(
      {required int pageKey}) async {
    return await orderRepo.getAllSupplierOrders(pageKey: pageKey);
  }

  Future<Either<DioException, List<OrderEntity>>> getNewSupplierOrders({
    Map<String, dynamic>? data,
    required int pageKey,
  }) async {
    return await orderRepo.getNewSupplierOrders(pageKey: pageKey);
  }

  Future<Either<DioException, OrderEntity>> getSupplierOrder(
      {required int orderId}) async {
    return await orderRepo.getSupplierOrder(orderId: orderId);
  }

  Future<Either<DioException, bool>> hideOrder({required int orderId}) async {
    return await orderRepo.hideOrder(orderId: orderId);
  }

  Future<Either<DioException, bool>> updateOrderStatus(
      Map<String, dynamic> data) async {
    return await orderRepo.updateOrderStatus(data);
  }
}
