import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_state.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/orders/domain/use_case/order_use_case.dart';

class WaitingOrdersCubit extends Cubit<WaitingOrdersState> {
  WaitingOrdersCubit({required this.orderUseCase})
      : super(WaitingOrdersInitial()) {
    pagingController.addPageRequestListener((pageKey) {
      _loadPage(pageKey);
    });
  }

  final OrderUseCase orderUseCase;
  final PagingController<int, OrderEntity> pagingController =
      PagingController(firstPageKey: 1);

  Future<void> _loadPage(int pageKey) async {
    try {
      emit(WaitingOrdersLoading(pagingController.itemList ?? []));

      final result = await orderUseCase.getWaitingOrders(pageKey: pageKey);
      result.fold(
        (failure) {
          pagingController.error = failure.message ?? "Unknown error";
          final currentItems = pagingController.itemList ?? [];
          emit(WaitingOrdersError(
              failure.message ?? "Unknown error", currentItems));
        },
        (orderResponse) {
          final pageSize = 10;
          final isLastPage = orderResponse.length < pageSize;

          if (isLastPage) {
            pagingController.appendLastPage(orderResponse);
          } else {
            pagingController.appendPage(orderResponse, pageKey + 1);
          }

          emit(WaitingOrdersLoaded(orderResponse));
        },
      );
    } catch (error) {
      pagingController.error = error.toString();
      final currentItems = pagingController.itemList ?? [];
      emit(WaitingOrdersError(error.toString(), currentItems));
    }
  }

  Future<void> reportAnIssue({
    required int orderId,
    required String message,
  }) async {
    try {
      final currentItems = pagingController.itemList ?? [];
      emit(WaitingOrdersLoading(currentItems));

      final result = await orderUseCase.reportAnIssue(
        orderId: orderId,
        message: message,
      );
      result.fold(
        (failure) {
          emit(WaitingOrdersError(
              failure.message ?? "Unknown error", currentItems));
          showToast(failure.message ?? "Unknown error");
        },
        (success) {
          final updatedItems = currentItems.map((order) {
            if (order.id == orderId) {
              return order.copyWith(isUserComplaint: true);
            }
            return order;
          }).toList();
          pagingController.itemList = updatedItems;

          emit(WaitingOrdersLoaded(updatedItems));
          // showToast("Issue reported successfully",
          //     success: true, color: Colors.green);
        },
      );
    } catch (e) {
      final currentItems = pagingController.itemList ?? [];
      emit(WaitingOrdersError("An error occurred", currentItems));
      showToast("An error occurred");
    }
  }

  Future<void> refresh() async {
    pagingController.refresh();
  }

  void initialize() {
    if (pagingController.itemList?.isEmpty != false) {
      pagingController.refresh();
    }
  }

  @override
  Future<void> close() {
    pagingController.dispose();
    return super.close();
  }

  void removeOrder(int orderId) {
    int index = pagingController.itemList!.indexWhere((element) => element.id == orderId);
    if(index!=-1){
      pagingController.itemList!.removeAt(index);
    }
  }
}
