
import 'package:equatable/equatable.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

abstract class WaitingOrdersState extends Equatable {
  final List<OrderEntity>? orders;
  
  const WaitingOrdersState({this.orders});

  @override
  List<Object?> get props => [orders];
}

class WaitingOrdersInitial extends WaitingOrdersState {}

class WaitingOrdersLoading extends WaitingOrdersState {
  const WaitingOrdersLoading(List<OrderEntity> orders) : super(orders: orders);
}

class WaitingOrdersLoaded extends WaitingOrdersState {
  const WaitingOrdersLoaded(List<OrderEntity> orders) : super(orders: orders);
}

class WaitingOrdersError extends WaitingOrdersState {
  final String message;
  
  const WaitingOrdersError(this.message, List<OrderEntity> orders) 
      : super(orders: orders);

  @override
  List<Object?> get props => [message, orders];
}