import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/orders/domain/use_case/order_use_case.dart';

import 'finished_order_state.dart';

class FinishedOrdersCubit extends Cubit<FinishedOrdersState> {
  FinishedOrdersCubit({required this.orderUseCase})
      : super(FinishedOrdersInitial()) {
    pagingController.addPageRequestListener((pageKey) {
      _loadPage(pageKey);
    });
  }

  final OrderUseCase orderUseCase;
  final PagingController<int, OrderEntity> pagingController =
      PagingController(firstPageKey: 1);

  List<OrderEntity> currentItems = [];

  void updateOrderRating({required int orderId}) {
    final currentItems = pagingController.itemList ?? [];
    final updatedItems = currentItems.map((order) {
      if (order.id == orderId) {
        return order.copyWith(isRated: true);
      }
      return order;
    }).toList();

    pagingController.itemList = updatedItems;
    emit(FinishedOrdersLoaded(updatedItems));
  }

  Future<void> _loadPage(int pageKey) async {
    try {
      emit(FinishedOrdersLoading());
      final result = await orderUseCase.getEndedOrders(pageKey: pageKey);
      result.fold(
        (failure) {
          pagingController.error = failure.message ?? "Unknown error";
          emit(FinishedOrdersError(failure.message ?? "Unknown error"));
        },
        (orderResponse) {
          currentItems = orderResponse;
          final pageSize = 10;
          final isLastPage = orderResponse.length < pageSize;

          if (isLastPage) {
            pagingController.appendLastPage(orderResponse);
          } else {
            pagingController.appendPage(orderResponse, pageKey + 1);
          }
         emit(FinishedOrdersLoaded(orderResponse));
        },
      );
    } catch (error) {
      pagingController.error = error.toString();
      emit(FinishedOrdersError(error.toString()));
    }
  }

  Future<void> refresh() async {
    pagingController.refresh();
  }

  void initialize() {
    if (pagingController.itemList?.isEmpty != false) {
      pagingController.refresh();
    }
  }

  Future<void> reportAnIssue({
    required int orderId,
    required String message,
  }) async {
    try {
      final currentItems = pagingController.itemList ?? [];

      final result = await orderUseCase.reportAnIssue(
        orderId: orderId,
        message: message,
      );

      result.fold(
        (failure) {
          showToast(failure.message ?? "Unknown error");
        },
        (success) {
          final updatedItems = currentItems.map((order) {
            if (order.id == orderId) {
              order.isUserComplaint = true;
              return order.copyWith(isUserComplaint: true);
            }
            return order;
          }).toList();
          pagingController.itemList = updatedItems;

          emit(FinishedOrdersLoaded(updatedItems));
          showToast("Issue reported successfully",
              success: true, color: Colors.green);
        },
      );
    } catch (e) {
      final currentItems = pagingController.itemList ?? [];
      showToast("An error occurred");
    }
  }

  @override
  Future<void> close() {
    pagingController.dispose();
    return super.close();
  }
}
