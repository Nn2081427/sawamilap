import 'package:equatable/equatable.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

abstract class FinishedOrdersState extends Equatable {
  const FinishedOrdersState();

  @override
  List<Object?> get props => [];
}

class FinishedOrdersInitial extends FinishedOrdersState {}

class FinishedOrdersLoading extends FinishedOrdersState {}

class FinishedOrdersLoaded extends FinishedOrdersState {
  final List<OrderEntity> orders;

  const FinishedOrdersLoaded(this.orders);

  @override
  List<Object?> get props => [orders];
}

class FinishedOrdersError extends FinishedOrdersState {
  final String message;

  const FinishedOrdersError(this.message);

  @override
  List<Object?> get props => [message];
}
