import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/models/text_field_model.dart';
import 'package:swamiil/features/offers/Presentation/cubits/offers_cubit/offers_cubit.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/orders/domain/use_case/order_use_case.dart';
import 'package:swamiil/main.dart';
part 'order_state.dart';

class NewOrderCubit extends Cubit<OrderState> {
  NewOrderCubit({required this.orderUseCase}) : super(OrderInitial());

  final OrderUseCase orderUseCase;
  List<OrderEntity> currentOrders = [];

  Future<void> updateNewOrderWhenRejected() async {
    currentOrders[0].offerNumbers--;
    emit(OrderNewLoadedState(currentOrders));
  }

  Future<void> updateNewOrderWhenAccepted() async {
    emit(OrderNewLoadedState([]));
  }

  Future<void> getNewOrders() async {
    emit(OrderNewLoadingState());
    final result = await orderUseCase.getNewOrders();
    result.fold((l) {
      showToast(l.message ?? "Unknown error");
      emit(OrderNewErrorState());
    }, (r) {
      currentOrders = r;
      print(r.length);
      if (r.isNotEmpty) {
        print(r.first.id);
        navigatorKey.currentContext!
            .read<OffersCubit>()
            .getOrderOffers(orderId: r.first.id!);
      }
      emit(OrderNewLoadedState(r));
    });
  }

  Future<void> cancelOrder({required int orderId}) async {
    emit(OrderCancelLoadingState());
    Map<String, dynamic> data = {};
    data['order_id'] = orderId;
    data['status'] = "user_cancelled";
    final result = await orderUseCase.updateOrderStatus(data);
    result.fold((l) {
      showToast(l.message ?? "Unknown error");
      emit(OrderCancelErrorState());
    }, (r) {
      successDialog(
        msg: "order_canceled".tr(),
        lottie: Assets.lottieSuccess,
      );
      //showToast("Order canceled",success: true,color: Colors.green);
      emit(OrderCancelSuccessState());
      emit(OrderNewLoadedState([]));
    });
  }
}
