part of 'new_order_cubit.dart';

sealed class OrderState extends Equatable {
  const OrderState();

  @override
  List<Object?> get props => [];
}

class OrderInitial extends OrderState {}

class OrderNewLoadingState extends OrderState {}

class OrderNewLoadedState extends OrderState {
  final List<OrderEntity> orders;

  const OrderNewLoadedState(this.orders);

  @override
  List<Object?> get props => [orders];
}

class OrderNewErrorState extends OrderState {}

class OrderFinishedErrorState extends OrderState {}

class OrderCancelLoadingState extends OrderState {}

class OrderCancelSuccessState extends OrderState {}

class OrderCancelErrorState extends OrderState {}
