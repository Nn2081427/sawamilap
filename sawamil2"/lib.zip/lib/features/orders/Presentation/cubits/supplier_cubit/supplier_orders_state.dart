import '../../../domain/entity/order_entity.dart';

abstract class SupplierOrdersState {}

class SupplierOrdersInitial extends SupplierOrdersState {}

class SupplierOrdersLoading extends SupplierOrdersState {}

class SupplierOrdersLoaded extends SupplierOrdersState {
  final List<OrderEntity> data;

  SupplierOrdersLoaded({required this.data});

  SupplierOrdersLoaded copyWith({List<OrderEntity>? data}) {
    return SupplierOrdersLoaded(
      data: data ?? this.data,
    );
  }
}

class SupplierOrdersError extends SupplierOrdersState {
  final String message;

  SupplierOrdersError({required this.message});
}

class OrderHiddenSuccess extends SupplierOrdersState {}
