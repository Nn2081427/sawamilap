import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/features/orders/Presentation/cubits/supplier_cubit/supplier_orders_state.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/orders/domain/use_case/order_use_case.dart';

class SupplierOrdersCubit extends Cubit<SupplierOrdersState> {
  SupplierOrdersCubit({required this.useCases}) : super(SupplierOrdersInitial()) {
    pagingController.addPageRequestListener((pageKey) {
      _loadPage(pageKey);
    });
    newOrdersPagingController.addPageRequestListener((pageKey) {
      _loadNewOrdersPage(pageKey);
    });
  }

  final OrderUseCase useCases;

  final PagingController<int, OrderEntity> pagingController = PagingController(firstPageKey: 1);
  final PagingController<int, OrderEntity> newOrdersPagingController = PagingController(firstPageKey: 1);

  List<OrderEntity> _orders = [];
  List<OrderEntity> _newOrders = [];

  /// Map to keep track of toggled appliedOffer statuses by order ID
  final Map<int, bool> _localAppliedOfferToggles = {};

  /// Toggles appliedOffer locally and refreshes new orders from backend automatically
  Future<void> toggleAndRefresh(int orderId) async {
    toggleAppliedOfferStatus(orderId);
    // Automatically refresh new orders after toggle to sync with backend
    newOrdersPagingController.refresh();
  }

  void toggleAppliedOfferStatus(int orderId) {
    final currentItems = newOrdersPagingController.itemList ?? [];

    final index = currentItems.indexWhere((order) => order.id == orderId);
    if (index == -1) return;

    final newAppliedOfferValue = !currentItems[index].appliedOffer;
    _localAppliedOfferToggles[orderId] = newAppliedOfferValue;

    final updatedOrder = currentItems[index].copyWith(
      appliedOffer: newAppliedOfferValue,
    );

    currentItems[index] = updatedOrder;
    newOrdersPagingController.itemList = List.from(currentItems);
  }

  Future<void> _loadPage(int pageKey) async {
    try {
      emit(SupplierOrdersLoading());

      final result = await useCases.getAllSupplierOrders(pageKey: pageKey);

      result.fold(
        (failure) {
          pagingController.error = failure.message ?? 'Unknown error';
          emit(SupplierOrdersError(message: failure.message ?? 'Unknown error'));
        },
        (orderResponse) {
          const pageSize = 10;
          final isLastPage = orderResponse.length < pageSize;

          if (isLastPage) {
            pagingController.appendLastPage(orderResponse);
          } else {
            pagingController.appendPage(orderResponse, pageKey + 1);
          }

          _orders = pagingController.itemList ?? [];
          emit(SupplierOrdersLoaded(data: _orders));
        },
      );
    } catch (e) {
      pagingController.error = e.toString();
      emit(SupplierOrdersError(message: e.toString()));
    }
  }

  Future<void> _loadNewOrdersPage(int pageKey, {Map<String, dynamic>? filters}) async {
    try {
      emit(SupplierOrdersLoading());

      Map<String, dynamic> data = filters ?? {};
      Map<String, dynamic> requestData = {
        ...data,
        'page': pageKey,
      };

      final result = await useCases.getNewSupplierOrders(data: requestData, pageKey: pageKey);

      result.fold(
        (failure) {
          newOrdersPagingController.error = failure.message ?? 'Unknown error';
          emit(SupplierOrdersError(message: failure.message ?? 'Unknown error'));
        },
        (orderResponse) {
          const pageSize = 10;
          final isLastPage = orderResponse.length < pageSize;

          // Re-apply local toggles on fresh data
          final updatedOrders = orderResponse.map((order) {
            if (_localAppliedOfferToggles.containsKey(order.id)) {
              return order.copyWith(appliedOffer: _localAppliedOfferToggles[order.id]);
            }
            return order;
          }).toList();

          if (isLastPage) {
            newOrdersPagingController.appendLastPage(updatedOrders);
          } else {
            newOrdersPagingController.appendPage(updatedOrders, pageKey + 1);
          }

          _newOrders = newOrdersPagingController.itemList ?? [];
          emit(SupplierOrdersLoaded(data: _newOrders));
        },
      );
    } catch (e) {
      newOrdersPagingController.error = e.toString();
      emit(SupplierOrdersError(message: e.toString()));
    }
  }

  Future<void> refresh() async {
    pagingController.refresh();
    newOrdersPagingController.refresh();
  }

  void initialize() {
    if (pagingController.itemList?.isEmpty != false) {
      pagingController.refresh();
    }
    if (newOrdersPagingController.itemList?.isEmpty != false) {
      newOrdersPagingController.refresh();
    }
  }

  Future<void> getSupplierNewOrders({Map<String, dynamic>? filters}) async {
    newOrdersPagingController.refresh();
  }

  Future<void> hideOrder({required int orderId}) async {
    final result = await useCases.hideOrder(orderId: orderId);

    result.fold(
      (failure) {
        emit(SupplierOrdersError(message: failure.message ?? 'Failed to hide order'));
        emit(SupplierOrdersLoaded(data: _orders));
      },
      (success) {
        if (success) {
          _orders.removeWhere((order) => order.id == orderId);
          pagingController.itemList = List.from(_orders);
          emit(SupplierOrdersLoaded(data: _orders));
        } else {
          emit(SupplierOrdersError(message: 'Order could not be hidden.'));
          emit(SupplierOrdersLoaded(data: _orders));
        }
      },
    );
  }

  Future<void> updateOrderStatus({
    required int orderId,
    required String status,
    String? cancel_reason,
  }) async {
    emit(SupplierOrdersLoading());

    final Map<String, dynamic> data = {
      'order_id': orderId,
      'status': status,
      if (status == 'cancelled' && cancel_reason != null) 'cancel_reason': cancel_reason,
    };
    final result = await useCases.updateOrderStatus(data);
    result.fold(
      (failure) {
        emit(SupplierOrdersError(message: failure.message ?? 'Failed to update order status'));
        emit(SupplierOrdersLoaded(data: _orders));
      },
      (success) {
        _orders = List.from(_orders)..removeWhere((order) => order.id == orderId);
        pagingController.itemList = _orders;
        emit(SupplierOrdersLoaded(data: _orders));
        print("Order ID: $orderId, Status: $status, Cancel Reason: $cancel_reason");
      },
    );
  }

  @override
  Future<void> close() {
    pagingController.dispose();
    newOrdersPagingController.dispose();
    return super.close();
  }
}
