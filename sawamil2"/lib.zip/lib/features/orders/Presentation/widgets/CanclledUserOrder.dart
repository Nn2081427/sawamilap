import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/haveAnIssueDialog.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/orders/Presentation/cubits/finished_order_cubit/finished_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomProfileContainerWidget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

class CanclledUserOrder extends StatefulWidget {
  const CanclledUserOrder({
    super.key,
    this.orderData,
  });
  final OrderEntity? orderData;

  @override
  State<CanclledUserOrder> createState() => _CanclledUserOrderState();
}

class _CanclledUserOrderState extends State<CanclledUserOrder> {
  TextEditingController issueController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 2.w),
      padding: EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: AppColors.textFieldBgColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: widget.orderData == null
          ? const SizedBox()
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomCarNameAndDescription(
                  carStatus: widget.orderData!.statusName ?? "",
                  carStatusColorContainer: Colors.red,
                  showDeleteButton: true,
                  orderTypeDescription: widget.orderData?.statusDescription,
                  title: widget.orderData!.title ?? "",
                  description: widget.orderData!.notes ?? "",
                ),
                SizedBox(
                  height: 3.h,
                ),
                Text(
                  "cancelled_by".tr(),
                  style: Fonts.text16Black,
                ),
                SizedBox(
                  height: 1.h,
                ),
                widget.orderData?.acceptedOffer?.supplier != null
                    ? CustomProfileContainerWidget(
                        showPrice: false,
                        image: widget.orderData!.acceptedOffer?.supplier?.image,
                        name: widget.orderData!.acceptedOffer?.supplier?.name,
                        city: widget
                            .orderData!.acceptedOffer?.supplier?.city?.name,
                        price: widget.orderData!.acceptedOffer?.price,
                        supplierId:
                            widget.orderData!.acceptedOffer!.supplier!.id,
                      )
                    : const SizedBox(),
                SizedBox(
                  height: 1.5.h,
                ),
                Text(
                  "سبب الالغاء".tr(),
                  style: Fonts.text16Black,
                ),
                SizedBox(
                  height: 1.h,
                ),
                Container(
                  width: double.infinity,
                  padding:
                      EdgeInsets.symmetric(vertical: 1.5.h, horizontal: 3.w),
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(
                    widget.orderData?.cancelReason ?? "",
                    style: Fonts.text16Orange.copyWith(color: Colors.black),
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                CustomButton(
                  width: double.infinity,
                  // margin: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.h),
                  onTap: () {
                    if (widget.orderData!.isUserComplaint) {
                      showToast("already_reported".tr());
                      return;
                    } else {
                      haveAnIssueDialog(
                        controller: issueController,
                        okButtonTap: () {
                          final cubit = context.read<FinishedOrdersCubit>();
                          cubit
                              .reportAnIssue(
                            message: issueController.text,
                            orderId: widget.orderData!.id,
                          )
                              .then((_) {
                            issueController.clear();
                            navPop();
                            successDialog(
                              lottie: Assets.lottieSuccess,
                              msg: "report_done".tr(),
                            );
                          });
                        },
                      );
                      return;
                    }
                  },
                  padding: EdgeInsets.symmetric(vertical: 1.5.h),
                  borderRadius: BorderRadius.circular(8),
                  backgroundColor: AppColors.lightRed,
                  child: Center(
                    child: Text(
                      widget.orderData!.isUserComplaint
                          ? "report_done".tr()
                          : "report_problem".tr(),
                      style: Fonts.textWhite18
                          .copyWith(color: Colors.black, fontSize: 14),
                    ),
                  ),
                ),
                SizedBox(height: 2.h),
              ],
            ),
    );
  }
}
