import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/haveAnIssueDialog.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/Presentation/screens/message_screen.dart';
import 'package:swamiil/features/offers/Presentation/widgets/offer_widget.dart';
import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/widgets/under_reviewing_widget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

class WaitingUserOrders extends StatefulWidget {
  const WaitingUserOrders({super.key});

  @override
  State<WaitingUserOrders> createState() => _WaitingUserOrdersState();
}

class _WaitingUserOrdersState extends State<WaitingUserOrders> {
  final TextEditingController complaintController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        final cubit = context.read<WaitingOrdersCubit>();
        return RefreshIndicator(
          onRefresh: () => cubit.refresh(),
          color: AppColors.mainColor,
          child: PagedListView<int, OrderEntity>(
            pagingController: cubit.pagingController,
            builderDelegate: PagedChildBuilderDelegate<OrderEntity>(
              itemBuilder: (context, order, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.grey.shade400,
                        width: 1.5,
                      ),
                    ),
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          UnderReviewingWidget(
                            orderEntity: order,
                            carStatus: "restricted".tr(),
                            carStatusColorContainer: Color(0xff115AD7),
                            showDeleteButton: true,
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            "your_order_is_restricted_with".tr(),
                            style: Fonts.textBlack18,
                          ),
                          SizedBox(height: 2.h),
                          if (order.acceptedOffer != null)
                            OfferWidget(
                              orderEntity: order,
                              showPrice: false,
                              secondButtonTap: () {
                                context
                                    .read<MessagesCubit>()
                                    .goToMessagePage(order.id);
                              },
                              firstButtonTap: () {
                                if (order.isUserComplaint) {
                                  showToast("already_reported".tr());
                                  return;
                                } else {
                                  haveAnIssueDialog(
                                    controller: complaintController,
                                    okButtonTap: () {
                                      final cubit =
                                          context.read<WaitingOrdersCubit>();
                                      cubit
                                          .reportAnIssue(
                                        message: complaintController.text,
                                        orderId: order.id,
                                      )
                                          .then((_) {
                                        complaintController.clear();
                                        navPop();
                                        successDialog(
                                          lottie: Assets.lottieSuccess,
                                          msg: "report_done".tr(),
                                        );
                                      });
                                    },
                                  );
                                  return;
                                }
                              },
                              offerEntity: order.acceptedOffer!,
                              isRestrictedScreen: true,
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
              firstPageProgressIndicatorBuilder: (_) => Column(
                children: [
                  const ShimmerWidget(
                    height: 100,
                    width: double.infinity,
                    radius: 15,
                    numOfShimmer: 1,
                  ),
                  const ShimmerWidget(
                    height: 250,
                    width: double.infinity,
                    radius: 15,
                    numOfShimmer: 1,
                  ),
                ],
              ),
              newPageProgressIndicatorBuilder: (_) => const ShimmerWidget(
                height: 100,
                width: double.infinity,
                radius: 15,
                numOfShimmer: 1,
              ),
              noItemsFoundIndicatorBuilder: (_) => Center(
                child: EmptyAnimation(
                  title: "no_waiting_orders".tr(),
                  gif: Assets.emptyLottie,
                ),
              ),
              noMoreItemsIndicatorBuilder: (_) => Padding(
                padding: EdgeInsets.symmetric(vertical: 2.h),
                child: Center(
                  child: Text(
                    "no_more_orders".tr(),
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
              firstPageErrorIndicatorBuilder: (_) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("Error loading orders"),
                    SizedBox(height: 16),
                    CustomButton(
                      backgroundColor: AppColors.mainColor,
                      textStyle: Fonts.textWhite18,
                      padding: EdgeInsets.symmetric(vertical: 1.5.h),
                      margin: EdgeInsets.symmetric(horizontal: 5.w),
                      onTap: () => cubit.pagingController.refresh(),
                      buttonText: "Retry",
                    ),
                  ],
                ),
              ),
              newPageErrorIndicatorBuilder: (_) => Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: CustomButton(
                    backgroundColor: AppColors.mainColor,
                    textStyle: Fonts.textWhite18,
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    margin: EdgeInsets.symmetric(horizontal: 5.w),
                    onTap: () =>
                        cubit.pagingController.retryLastFailedRequest(),
                    buttonText: "Retry",
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
