import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/dialog/showRatingDialog.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomProfileContainerWidget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

class CompletedUserOrder extends StatelessWidget {
  const CompletedUserOrder({
    super.key,
    this.orderData,
  });
  final OrderEntity? orderData;

  @override
  Widget build(BuildContext context) {
    return Container(
      // margin: EdgeInsets.symmetric(horizontal: 2.w),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          color: AppColors.textFieldBgColor,
          //border: Border.all(color: Colors.grey.shade400, width: 1.5),
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomCarNameAndDescription(
            carStatus: orderData!.statusName ?? "",
            carStatusColorContainer: Colors.green,
            showDeleteButton: true,
            orderTypeDescription: orderData?.statusDescription,
            title: orderData!.title ?? "",
            description: orderData!.notes ?? "",
          ),
          SizedBox(
            height: 3.h,
          ),
          Text(
            "Completed By".tr(),
            style: Fonts.text16Black,
          ),
          SizedBox(
            height: 1.h,
          ),
          orderData?.acceptedOffer?.supplier != null
              ? CustomProfileContainerWidget(
                  image: orderData!.acceptedOffer?.supplier?.image,
                  name: orderData!.acceptedOffer?.supplier?.name,
                  city: orderData!.acceptedOffer?.supplier?.city?.name,
                  price: orderData!.acceptedOffer?.price,
                  isWhiteBackground: true,
                  supplierId: orderData!.acceptedOffer!.supplierId!,
                )
              : const SizedBox(),
          SizedBox(
            height: 3.h,
          ),
          CustomButton(
            onTap: () {
              if (orderData!.isRated) {
                showToast("You_have_already_rated".tr());
              } else {
                showRatingDialog(orderId: orderData!.id);
              }
            },
            borderRadius: BorderRadius.circular(8),
            padding: EdgeInsets.symmetric(vertical: 1.5.h),
            backgroundColor: orderData!.isRated
                ? Colors.green.withOpacity(0.3)
                : AppColors.mainColor.withOpacity(0.3),
            child: Center(
              child: Text(
                orderData!.isRated ? "order_rated".tr() : "rate seller".tr(),
                style: Fonts.textWhite18.copyWith(
                    fontSize: 14,
                    color: orderData!.isRated
                        ? Colors.green.withOpacity(0.8)
                        : AppColors.mainColor.withOpacity(0.8),
                    fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
