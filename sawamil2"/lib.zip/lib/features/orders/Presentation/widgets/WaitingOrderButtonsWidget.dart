import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/main.dart';

class WaitingOrderButtonsWidget extends StatelessWidget {
  const WaitingOrderButtonsWidget({
    super.key,
    required this.offerEntity,
    required this.ignoreOfferOnTap,
    required this.acceptOfferOnTap,
    this.orderEntity,
  });

  final OfferEntity offerEntity;
  final OrderEntity? orderEntity;
  final void Function()? ignoreOfferOnTap;
  final void Function()? acceptOfferOnTap;

  @override
  Widget build(BuildContext context) {
    talker.info(
        "WaitingOrderButtonsWidget: offerEntity: ${orderEntity?.isUserComplaint}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${offerEntity.price?.toStringAsFixed(0) ?? '0'} ${'SAR'.tr()}',
          style: Fonts.text24Orange.copyWith(fontWeight: FontWeight.w500),
        ),
        SizedBox(height: 1.5.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: CustomButton(
                // height: 50,
                onTap: ignoreOfferOnTap,
                padding: EdgeInsets.symmetric(vertical: 1.8.h),
                borderRadius: BorderRadius.circular(8),
                backgroundColor: AppColors.lightRed,
                child: Center(
                  child: Text(
                    orderEntity?.isUserComplaint != null &&
                            orderEntity!.isUserComplaint
                        ? "report_done".tr()
                        : "report_issue".tr(),
                    style: Fonts.textWhite18
                        .copyWith(color: Colors.black, fontSize: 14),
                  ),
                ),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: CustomButton(
                onTap: acceptOfferOnTap,
                padding: EdgeInsets.symmetric(vertical: 1.8.h),
                borderRadius: BorderRadius.circular(8),
                backgroundColor: AppColors.mainColor,
                child: Center(
                  child: Text(
                    "go_to_chat".tr(),
                    style: Fonts.textWhite18.copyWith(fontSize: 14),
                  ),
                ),
              ),
            )
          ],
        ),
      ],
    );
  }
}
