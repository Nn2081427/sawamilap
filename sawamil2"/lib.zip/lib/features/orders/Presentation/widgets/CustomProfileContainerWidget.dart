import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/screens/supplier_profile_view.dart';

import '../../../rate/presentation/cubits/supplier_profile_cubit/supplier_profile_cubit.dart';

class CustomProfileContainerWidget extends StatelessWidget {
  const CustomProfileContainerWidget({
    super.key,
    this.isFromMyClientScreen = false,
    required this.supplierId,
    this.isWhiteBackground = false,
    this.onTap,
    this.image,
    this.name,
    this.city,
    this.price,
    this.showPrice = true,
  });

  final bool isFromMyClientScreen;
  final int supplierId;
  // final SupplierEntity supplier;
  final bool? isWhiteBackground;
  final void Function()? onTap;
  final String? image, name, city;
  final num? price;
  final bool? showPrice;
  @override
  Widget build(BuildContext widgetContext) {
    return InkWell(
      onTap: () {},
      child: Container(
        padding: isWhiteBackground! ? EdgeInsets.all(10) : null,
        decoration: BoxDecoration(
          color: isWhiteBackground! ? Colors.white : null,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Builder(builder: (newContext) {
              return InkWell(
                onTap: () {
                  if (!isFromMyClientScreen) {
                    newContext
                        .read<SupplierPublicProfileCubit>()
                        .getSupplierProfile(supplierId: supplierId);

                    navP(SupplierPublicProfileView());
                  }
                },
                child: CustomImageCacheProvider(
                  imageUrl: image ?? '',
                  width: 50,
                  borderRadius: 50,
                  height: 50,
                ),
              );
            }),
            SizedBox(
              width: 10,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  name ?? '',
                  style: Fonts.textBlack18
                      .copyWith(fontSize: 15, fontWeight: FontWeight.w500),
                ),
                SizedBox(
                  height: 3,
                ),
                Text(
                  city ?? '',
                  style: Fonts.textSplash14.copyWith(
                    color: Colors.grey,
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
            Spacer(),
            price != null && showPrice!
                ? Text(
                    price!.toString() + " SAR".tr(),
                    style: Fonts.text16Orange
                        .copyWith(fontWeight: FontWeight.w500),
                  )
                : Container(),
            if (isFromMyClientScreen!) ...[
              CustomButton(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                borderRadius: BorderRadius.circular(10),
                onTap: onTap ?? () {},
                border: Border.all(color: AppColors.mainColor.withOpacity(0.5)),
                backgroundColor: Colors.transparent,
                child: Text(
                  "details".tr(),
                  style: Fonts.textSplash14.copyWith(
                    color: AppColors.mainColor,
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                  ),
                ),
              )
            ]
          ],
        ),
      ),
    );
  }
}
