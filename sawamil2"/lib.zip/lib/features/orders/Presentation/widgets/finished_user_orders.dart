import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/orders/Presentation/cubits/finished_order_cubit/finished_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CanclledUserOrder.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CompletedUserOrder.dart';
import 'package:swamiil/features/orders/Presentation/widgets/DeletedUserOrder.dart';

import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

class FinishedUserOrders extends StatelessWidget {
  const FinishedUserOrders({super.key});

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        final cubit = context.read<FinishedOrdersCubit>();
        return RefreshIndicator(
          color: AppColors.mainColor,
          onRefresh: () => cubit.refresh(),
          child: Padding(
            padding: EdgeInsets.only(top: 2.h),
            child: PagedListView<int, OrderEntity>(
              pagingController: cubit.pagingController,
              builderDelegate: PagedChildBuilderDelegate<OrderEntity>(
                itemBuilder: (context, order, index) {
                  if (order.status == OrderStatus.supplierCancelled) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: 2.h),
                      child: CanclledUserOrder(orderData: order),
                    );
                  } else if (order.status == OrderStatus.userCancelled) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: 2.h),
                      child: DeletedUserOrder(orderData: order),
                    );
                  } else if (order.status == OrderStatus.completed) {
                    return Padding(
                      padding: EdgeInsets.only(bottom: 2.h),
                      child: CompletedUserOrder(orderData: order),
                    );
                  }
                  return const SizedBox();
                },
                firstPageProgressIndicatorBuilder: (_) => Column(
                  children: [
                    const ShimmerWidget(
                      height: 100,
                      width: double.infinity,
                      radius: 15,
                      numOfShimmer: 1,
                    ),
                    const ShimmerWidget(
                      height: 250,
                      width: double.infinity,
                      radius: 15,
                      numOfShimmer: 1,
                    ),
                  ],
                ),
                newPageProgressIndicatorBuilder: (_) => const ShimmerWidget(
                  height: 100,
                  width: double.infinity,
                  radius: 15,
                  numOfShimmer: 1,
                ),
                noItemsFoundIndicatorBuilder: (_) => Center(
                  child: EmptyAnimation(
                    title: "no_ended_orders".tr(),
                    gif: Assets.emptyLottie,
                  ),
                ),
                noMoreItemsIndicatorBuilder: (_) => Padding(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  child: Center(
                    child: Text(
                      "no_more_orders".tr(),
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
                firstPageErrorIndicatorBuilder: (_) => Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Error loading orders"),
                      SizedBox(height: 16),
                      CustomButton(
                        backgroundColor: AppColors.mainColor,
                        textStyle: Fonts.textWhite18,
                        padding: EdgeInsets.symmetric(vertical: 1.5.h),
                        margin: EdgeInsets.symmetric(horizontal: 5.w),
                        onTap: () => cubit.pagingController.refresh(),
                        buttonText: "Retry",
                      ),
                    ],
                  ),
                ),
                newPageErrorIndicatorBuilder: (_) => Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(
                    child: CustomButton(
                      backgroundColor: AppColors.mainColor,
                      textStyle: Fonts.textWhite18,
                      padding: EdgeInsets.symmetric(vertical: 1.5.h),
                      margin: EdgeInsets.symmetric(horizontal: 5.w),
                      onTap: () =>
                          cubit.pagingController.retryLastFailedRequest(),
                      buttonText: "Retry",
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
