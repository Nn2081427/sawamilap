import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/offers/Presentation/cubits/offers_cubit/offers_cubit.dart';
import 'package:swamiil/features/offers/Presentation/widgets/offer_widget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

import '../../../offers/domain/entities/offer_entity.dart';
import '../cubits/new_order_cubit/new_order_cubit.dart';

class OfferListWidget extends StatelessWidget {
  const OfferListWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<OffersCubit, OffersState>(
      builder: (context, state) {
        final cubit = context.read<OffersCubit>();

        if (state is OffersLoadingState) {
          return const ShimmerWidget(
            height: 200,
            width: double.infinity,
            radius: 15,
            numOfShimmer: 3,
          );
        } else if (state is OffersErrorState) {
          return Center(
            child: Column(
              children: [
                Text("Error loading offers"),
                CustomButton(
                  onTap: () => cubit.pagingController.refresh(),
                  child: Text("Retry".tr()),
                ),
              ],
            ),
          );
        }

        return PagedListView<int, OfferEntity>(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          pagingController: cubit.pagingController,
          builderDelegate: PagedChildBuilderDelegate<OfferEntity>(
            itemBuilder: (context, offer, index) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: OfferWidget(
                showPrice: false,
                // orderEntity: order,
                secondButtonTap: () => context
                    .read<OffersCubit>()
                    .acceptedOffers(offerId: offer.id!),
                firstButtonTap: () => confirmDialog(
                  title: "confirm_ignore_offer".tr(),
                  confirm: "yes_ignore".tr(),
                  cancel: "cancel".tr(),
                  confirmTap: () => context
                      .read<OffersCubit>()
                      .rejectedOffers(offerId: offer.id!),
                ),
                isRestrictedScreen: false,
                offerEntity: offer,
              ),
            ),
            firstPageProgressIndicatorBuilder: (_) => const ShimmerWidget(
              height: 200,
              width: double.infinity,
              radius: 15,
              numOfShimmer: 3,
            ),
            newPageProgressIndicatorBuilder: (_) => const ShimmerWidget(
              height: 100,
              width: double.infinity,
              radius: 15,
              numOfShimmer: 1,
            ),
            noItemsFoundIndicatorBuilder: (_) => Center(
              child: EmptyAnimation(
                title: "no_offers".tr(),
                gif: Assets.emptyLottie,
              ),
            ),
            noMoreItemsIndicatorBuilder: (_) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Center(
                child: Text(
                  "no_more_offers".tr(),
                  style: const TextStyle(color: Colors.grey),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
