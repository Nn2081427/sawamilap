import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/dialog/cancelRequestDialog.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomProfileContainerWidget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

import 'order_details_dialog.dart';

class MyClinetCardWidget extends StatelessWidget {
  const MyClinetCardWidget({
    super.key,
    required this.orderEntity,
    required this.cancelTap,
    required this.confirmOrderTap,
  });
  final OrderEntity orderEntity;

  final void Function(String reason) cancelTap;
  final void Function() confirmOrderTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade400, width: 1),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.textFieldBgColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(),
                CustomProfileContainerWidget(
                  isFromMyClientScreen: true,
                  supplierId: 0,
                  image: orderEntity.acceptedOffer?.orderEntity?.user?.image,
                  name: orderEntity.acceptedOffer?.orderEntity?.user?.firstName,
                  city:
                      orderEntity.acceptedOffer?.orderEntity?.user?.city?.name,
                  price: orderEntity.acceptedOffer?.price,
                  onTap: () => showOrderDetailsOrder(
                    context,
                    orderEntity.brandModel?.name ?? "",
                    orderEntity.brand?.name ?? "",
                    orderEntity.year,
                    orderEntity.getType(),
                    orderEntity.notes ?? "",
                    orderEntity.userName() ?? "",
                    orderEntity.supplierName() ?? "",
                    (orderEntity.acceptedOffer?.price ?? 0).toString(),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                if (orderEntity.title != null)
                  Text(
                    orderEntity.title!,
                    style: Fonts.text16Orange.copyWith(
                        color: Colors.black, fontWeight: FontWeight.w600),
                  ),
                SizedBox(
                  height: 1.h,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 6,
                      child: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white,
                        ),
                        child: ExpandableDescriptionText(
                            description: orderEntity.notes!),
                      ),
                    ),
                    SizedBox(
                      width: 2.w,
                    ),
                    Expanded(
                      flex: 4,
                      child: CustomButton(
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                        borderRadius: BorderRadius.circular(8),
                        onTap: () {},
                        backgroundColor: Color(0xff3186F5),
                        child: FittedBox(
                          child: Text(
                            "go_to_chat".tr(),
                            style: Fonts.text16Orange.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: CustomButton(
                  onTap: () async {
                    final reason = await cancelRequestDialog();
                    if (reason != null) {
                      cancelTap(reason);
                    }
                  },
                  height: 40,
                  padding: EdgeInsets.symmetric(vertical: 12),
                  borderRadius: BorderRadius.circular(8),
                  backgroundColor: AppColors.lightRed,
                  child: Center(
                    child: Text(
                      "unable_to_complete".tr(),
                      style: Fonts.textWhite18
                          .copyWith(color: Colors.black, fontSize: 14),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: CustomButton(
                  onTap: () {
                    confirmDialog(
                      title: "Do you want to deliver this order ?".tr(),
                      confirm: "yes, deliver it".tr(),
                      cancel: "cancel".tr(),
                      confirmTap: confirmOrderTap,
                    );
                  },
                  height: 40,
                  padding: EdgeInsets.symmetric(vertical: 12),
                  borderRadius: BorderRadius.circular(8),
                  backgroundColor: AppColors.mainColor,
                  child: Center(
                    child: Text(
                      "deliver_order".tr(),
                      style: Fonts.textWhite18.copyWith(fontSize: 14),
                    ),
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
