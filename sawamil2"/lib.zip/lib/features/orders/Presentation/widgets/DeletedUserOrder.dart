import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import 'package:swamiil/features/orders/Presentation/widgets/under_reviewing_widget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

class DeletedUserOrder extends StatelessWidget {
  const DeletedUserOrder({
    super.key,
    this.orderData,
  });

  final OrderEntity? orderData;
  @override
  Widget build(BuildContext context) {
    return Container(
      // margin: EdgeInsets.symmetric(horizontal: 2.w),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
      decoration: BoxDecoration(
          color: AppColors.textFieldBgColor,
          //    border: Border.all(color: Colors.grey.shade400, width: 1.5),
          borderRadius: BorderRadius.circular(10)),
      child: CustomCarNameAndDescription(
        carStatus: orderData!.statusName ?? "",
        carStatusColorContainer: Colors.red,
        showDeleteButton: true,
        orderTypeDescription: orderData?.statusDescription,
        description: orderData!.notes ?? "",
        title: orderData!.title ?? "",
      ),
    );
  }
}
