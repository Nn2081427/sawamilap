import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/offers/Presentation/cubits/offers_cubit/offers_cubit.dart';
import 'package:swamiil/features/offers/Presentation/widgets/offer_widget.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/orders/Presentation/cubits/new_order_cubit/new_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/widgets/buildOffersList.dart';
import 'package:swamiil/features/orders/Presentation/widgets/under_reviewing_widget.dart';
import 'package:swamiil/main.dart';

class Newuserorderswidget extends StatelessWidget {
  const Newuserorderswidget({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: AppColors.mainColor,
      onRefresh: () => context.read<NewOrderCubit>().getNewOrders(),
      child: BlocBuilder<NewOrderCubit, OrderState>(
        builder: (orderContext, orderState) {
          if (orderState is OrderNewLoadingState) {
            return const ShimmerWidget(
              height: 200,
              width: double.infinity,
              radius: 15,
              numOfShimmer: 3,
            );
          } else if (orderState is OrderNewErrorState) {
            return Center(child: Text("Unknown error"));
          } else if (orderState is OrderNewLoadedState) {
            if (orderState.orders.isEmpty) {
              return Center(
                child: EmptyAnimation(
                  title: "no_new_orders".tr(),
                  gif: Assets.emptyLottie,
                ),
              );
            }

            return SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 2.h),
                  ...orderState.orders.map((order) => Padding(
                        padding: const EdgeInsets.only(bottom: 15.0),
                        child: UnderReviewingWidget(
                          showDeleteButton: false,
                          onPressed: () => confirmDialog(
                            title: "confirm_cancel_order".tr(),
                            confirm: "delete_order".tr(),
                            cancel: "cancel".tr(),
                            confirmTap: () => context
                                .read<NewOrderCubit>()
                                .cancelOrder(orderId: order.id),
                          ),
                          carStatus: "under_review".tr(),
                          carStatusColorContainer:
                              checkIfOrderIsUnderReviewing(order)["hasOffers"]
                                  ? Colors.green
                                  : AppColors.mainColor,
                          orderEntity: order,
                        ),
                      )),
                  SizedBox(height: 15),
                  Text("Offers".tr(), style: Fonts.textBlack18),
                  OfferListWidget(),
                ],
              ),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }
}
