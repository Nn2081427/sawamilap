import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';

class NewOrderButtonWidget extends StatelessWidget {
  const NewOrderButtonWidget({
    super.key,
    required this.offerEntity,
    required this.ignoreOfferOnTap,
    required this.acceptOfferOnTap,
  });

  final OfferEntity offerEntity;
  final void Function()? ignoreOfferOnTap;
  final void Function()? acceptOfferOnTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          '${offerEntity.price?.toStringAsFixed(0) ?? '0'} ${'SAR'.tr()}',
          style: Fonts.text20Orange.copyWith(fontWeight: FontWeight.w500),
        ),
        Spacer(),
        CustomButton(
          width: 80,
          height: 40,
          onTap: ignoreOfferOnTap,
          border: Border.all(color: Colors.grey.shade300),
          borderRadius: BorderRadius.circular(8),
          backgroundColor: AppColors.textFieldBgColor,
          child: Center(
            child: Text(
              "Ignore".tr(),
              style: Fonts.text16Black.copyWith(
                color: Colors.black54,
                fontSize: 18,
              ),
            ),
          ),
        ),
        SizedBox(width: 10),
        CustomButton(
          width: 80,
          height: 40,
          onTap: acceptOfferOnTap,
          borderRadius: BorderRadius.circular(8),
          backgroundColor: AppColors.mainColor,
          child: Center(
            child: Text(
              "Accept".tr(),
              style: Fonts.textWhite18,
            ),
          ),
        ),
      ],
    );
  }
}
