import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/features/Home/Presentation/widgets/upload_image_widget.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import 'package:swamiil/main.dart';
import '../../domain/entity/order_entity.dart';

class UnderReviewingWidget extends StatelessWidget {
  const UnderReviewingWidget({
    super.key,
    required this.showDeleteButton,
    this.restrictedWidget,
    required this.carStatus,
    required this.carStatusColorContainer,
    this.onPressed,
    this.orderEntity,
  });

  final OrderEntity? orderEntity;
  final bool showDeleteButton;
  final Widget? restrictedWidget;
  final String carStatus;
  final Color carStatusColorContainer;
  final void Function()? onPressed;

  @override
  Widget build(BuildContext context) {
    talker.debug(
        "UnderReviewingWidget: orderEntity: ${orderEntity?.offerNumbers}");
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
          //color: showDeleteButton ? null : AppColors.mainColor,
          color: AppColors.textFieldBgColor.withOpacity(0.5),
          border: !showDeleteButton
              ? Border.all(color: Colors.grey.shade300, width: 1.5)
              : null,
          borderRadius: BorderRadius.circular(10)),
      margin: EdgeInsets.symmetric(vertical: 0.1.h),
      padding: EdgeInsets.symmetric(vertical: 1.h, horizontal: 2.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomCarNameAndDescription(
              onPressed: onPressed,
              showStatusDescription:
                  !checkIfOrderIsUnderReviewing(orderEntity!)["hasOffers"],
              carStatus: checkIfOrderIsUnderReviewing(orderEntity!)["message"],
              description: orderEntity?.notes ?? '',
              title: orderEntity?.title ?? '',
              showDeleteButton: showDeleteButton,
              orderTypeDescription: orderEntity?.statusDescription,
              carStatusColorContainer: carStatusColorContainer),
          if (orderEntity?.notes != null)
            SizedBox(
              height: 15,
            ),
          if (orderEntity != null && orderEntity!.images != null)
            UploadImageWidget(
              title:
                  orderEntity!.images!.isNotEmpty ? "photo_gallery".tr() : "",
              images: (orderEntity!.images ?? []).map((e) => e.image!).toList(),
              isRestrictedScreen: showDeleteButton,
              weight: FontWeight.w500,
            ),
        ],
      ),
    );
  }
}

Map<String, dynamic> checkIfOrderIsUnderReviewing(OrderEntity orderEntity) {
  final hasOffers = orderEntity.status == OrderStatus.newOrder &&
      orderEntity.offerNumbers > 0;

  String message;

  if (hasOffers) {
    final offerCount = orderEntity.offerNumbers;
    if (offerCount == 1) {
      message = "${"you_have".tr()} 1 ${"offer_count_one".tr()}";
    } else {
      message = "${"you_have".tr()} $offerCount ${"offers_count".tr()}";
    }
  } else {
    message = orderEntity.statusName ?? "under_review".tr();
  }

  return {
    'message': message,
    'hasOffers': hasOffers,
  };
}
