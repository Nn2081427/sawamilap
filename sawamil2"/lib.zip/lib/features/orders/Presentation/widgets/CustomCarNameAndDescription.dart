import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/explain_dialog.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

class CustomCarNameAndDescription extends StatelessWidget {
  const CustomCarNameAndDescription({
    super.key,
    required this.carStatus,
    required this.showDeleteButton,
    required this.carStatusColorContainer,
    this.onPressed,
    required this.title,
    required this.description,
    this.orderTypeDescription,
    this.showStatusDescription = true,
  });

  final String carStatus;
  final bool showDeleteButton;
  final Color carStatusColorContainer;
  final void Function()? onPressed;
  final String title;
  final String description;
  final String? orderTypeDescription;
  final bool? showStatusDescription;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 7,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Fonts.textBlack18.copyWith(
                      color: Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            if (!showDeleteButton)
              Expanded(
                flex: 3,
                child: IconButton(
                  onPressed: onPressed,
                  icon: SvgPicture.asset(
                    Assets.deleteIcon,
                    height: 3.5.h,
                    width: 7.w,
                  ),
                ),
              ),
            StatusChip(
                status: carStatus,
                color: carStatusColorContainer,
                onTap: showStatusDescription!
                    ? () => explainDialog(
                          orderDescription: orderTypeDescription ?? '',
                          orderStatus: carStatus,
                          orderStatusColorContainer: carStatusColorContainer,
                        )
                    : () => {}),
          ],
        ),
        SizedBox(height: 2.h),
        ExpandableDescriptionText(description: description),
      ],
    );
  }
}

class ExpandableDescriptionText extends StatefulWidget {
  final String description;

  const ExpandableDescriptionText({
    super.key,
    required this.description,
  });

  @override
  State<ExpandableDescriptionText> createState() =>
      _ExpandableDescriptionTextState();
}

class _ExpandableDescriptionTextState extends State<ExpandableDescriptionText> {
  bool _isExpanded = false;
  static const int _maxCollapsedLines = 2;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final textSpan = TextSpan(
              text: widget.description,
              style: Fonts.textSplash14.copyWith(color: Colors.grey),
            );

            final textPainter = TextPainter(
              text: textSpan,
              maxLines: _maxCollapsedLines,
              textDirection: TextDirection.ltr,
            );
            textPainter.layout(maxWidth: constraints.maxWidth);
            final needsSeeMore = textPainter.didExceedMaxLines;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AnimatedSize(
                  duration: const Duration(milliseconds: 200),
                  child: Text.rich(
                    textSpan,
                    textAlign: TextAlign.start,
                    maxLines: _isExpanded ? null : _maxCollapsedLines,
                    overflow: _isExpanded ? null : TextOverflow.ellipsis,
                  ),
                ),
                if (needsSeeMore)
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _isExpanded = !_isExpanded;
                      });
                    },
                    child: Text(
                      _isExpanded ? 'See less' : 'See more',
                      style: Fonts.textSplash14.copyWith(
                        color: AppColors.mainColor,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  final Color color;
  final VoidCallback onTap;

  const StatusChip({
    super.key,
    required this.status,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: ShapeDecoration(
          color: color.withOpacity(0.1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(6),
          ),
        ),
        child: Text(
          status,
          style: Fonts.text16Orange.copyWith(color: color),
        ),
      ),
    );
  }
}
