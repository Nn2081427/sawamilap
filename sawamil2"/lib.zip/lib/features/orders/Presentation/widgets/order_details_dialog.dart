import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';

void showOrderDetailsOrder(
  BuildContext context,
  String brandType,
  String type,
  String year,
  String orderType,
  String notes,
  String supplierName,
  String clientName,
  String price,
) {
  final orderDetails = [
    {"label": "type :", "value": type},
    {"label": "brand type :", "value": brandType},
    {"label": "year :", "value": year},
    {"label": "order type :", "value": orderType},
    {"label": "order details :", "value": notes},
    {"label": "client name :", "value": clientName},
    {"label": "supplier name :", "value": supplierName},
    {"label": "price :", "value": price},
  ];

  final instructions = [
    "1- Ensure the client's request is complete.".tr(),
    "2- Make an agreement that is mutually acceptable to both parties.".tr(),
    "3- Do not complete the request before fully concluding the relationship with this client."
        .tr(),
  ];

  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Align(
          alignment: Alignment.topRight,
          child: Row(
            children: [
              Image.asset(
                Assets.whiteLogoBg,
                width: 70,
                height: 70,
                fit: BoxFit.contain,
              ),
              Spacer(),
              IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: Icon(Icons.close),
              )
            ],
          ),
        ),
        content: SizedBox(
          width: Constants.isTablet ? 40.w : 90.w,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Order Details :".tr(),
                  style: Fonts.text16Black.copyWith(color: Colors.grey),
                ),
                const SizedBox(height: 10),
                ...orderDetails.map((item) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: LabeledRichText(
                        labelKey: item["label"]!.tr(),
                        value: item["value"] ?? "",
                        labelStyle:
                            Fonts.text16Black.copyWith(color: Colors.grey),
                        valueStyle:
                            Fonts.text16Black.copyWith(color: Colors.grey),
                      ),
                    )),
                SizedBox(height: 10),
                Divider(
                  color: Colors.grey.shade300,
                  thickness: 1,
                ),
                const SizedBox(height: 10),
                Text(
                  "please follow the following instructions :".tr(),
                  style: Fonts.text16Black.copyWith(color: Colors.grey),
                ),
                SizedBox(height: 10),
                ...instructions.map((instruction) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(
                        instruction,
                        style: Fonts.text16Black.copyWith(color: Colors.grey),
                      ),
                    )),
                SizedBox(height: 15),
                Text(
                  "Note :".tr(),
                  style: Fonts.text16Black.copyWith(color: Colors.grey),
                ),
                Text(
                  "Contacting the client outside the platform is prohibited to ensure transparency between the two parties.Any external communication may result in your account being banned."
                      .tr(),
                  style: Fonts.text16Black.copyWith(color: Colors.grey),
                ),
                const SizedBox(height: 20),
                CustomButton(
                  onTap: () => Navigator.pop(context),
                  width: double.infinity,
                  backgroundColor: AppColors.mainColor,
                  borderRadius: BorderRadius.circular(8),
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Center(
                    child: Text(
                      "close page".tr(),
                      style: Fonts.text16Black.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

class LabeledRichText extends StatelessWidget {
  final String labelKey;
  final String value;
  final TextStyle? labelStyle;
  final TextStyle? valueStyle;

  const LabeledRichText({
    super.key,
    required this.labelKey,
    required this.value,
    this.labelStyle,
    this.valueStyle,
  });

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(
            text: "${labelKey.tr()} ",
            style: labelStyle ?? const TextStyle(color: Colors.grey),
          ),
          TextSpan(
            text: value,
            style: valueStyle ?? const TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
