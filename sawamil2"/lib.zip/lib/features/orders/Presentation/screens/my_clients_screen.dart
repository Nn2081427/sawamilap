import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/empty_widget.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import '../cubits/supplier_cubit/supplier_orders_cubit.dart';
import '../cubits/supplier_cubit/supplier_orders_state.dart';
import '../widgets/my_client_card_widget.dart';

class MyClientsScreen extends StatelessWidget {
  const MyClientsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) {
        final cubit = getIt.get<SupplierOrdersCubit>();
        cubit.initialize();
        return cubit;
      },
      child: Scaffold(
        appBar: AppBarWidget(title: "my_clients".tr()),
        backgroundColor: Colors.white,
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: BlocBuilder<SupplierOrdersCubit, SupplierOrdersState>(
            builder: (context, state) {
              final cubit = context.read<SupplierOrdersCubit>();

              return RefreshIndicator(
                onRefresh: () async {
                  cubit.pagingController.refresh();
                },
                child: PagedListView<int, OrderEntity>(
                  pagingController: cubit.pagingController,
                  builderDelegate: PagedChildBuilderDelegate<OrderEntity>(
                    itemBuilder: (context, order, index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: MyClinetCardWidget(
                          cancelTap: (reason) {
                            cubit.updateOrderStatus(
                              orderId: order.id,
                              status: "supplier_cancelled",
                              cancel_reason: reason,
                            );
                            print(
                                "Order ID: ${order.id} - Cancelled with reason: $reason  ");
                          },
                          orderEntity: order,
                          confirmOrderTap: () {
                            cubit.updateOrderStatus(
                                orderId: order.id, status: "completed");
                          },
                        ),
                      );
                    },
                    firstPageProgressIndicatorBuilder: (_) => Column(
                      children: [
                        const ShimmerWidget(
                          height: 100,
                          width: double.infinity,
                          radius: 15,
                          numOfShimmer: 1,
                        ),
                        const ShimmerWidget(
                          height: 250,
                          width: double.infinity,
                          radius: 15,
                          numOfShimmer: 1,
                        ),
                      ],
                    ),
                    newPageProgressIndicatorBuilder: (_) => const ShimmerWidget(
                      height: 100,
                      width: double.infinity,
                      radius: 15,
                      numOfShimmer: 1,
                    ),
                    noItemsFoundIndicatorBuilder: (context) =>
                        const EmptyAnimation(
                      title: "No Orders Found",
                      gif: Assets.emptyLottie,
                    ),
                    noMoreItemsIndicatorBuilder: (_) => Padding(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      child: Center(
                        child: Text(
                          "no more orders".tr(),
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    ),
                    firstPageErrorIndicatorBuilder: (_) => Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Error loading orders".tr()),
                          SizedBox(height: 16),
                          CustomButton(
                            backgroundColor: AppColors.mainColor,
                            textStyle: Fonts.textWhite18,
                            padding: EdgeInsets.symmetric(vertical: 1.5.h),
                            margin: EdgeInsets.symmetric(horizontal: 5.w),
                            onTap: () => cubit.pagingController.refresh(),
                            buttonText: "Retry".tr(),
                          ),
                        ],
                      ),
                    ),
                    newPageErrorIndicatorBuilder: (_) => Padding(
                      padding: EdgeInsets.all(16),
                      child: Center(
                        child: CustomButton(
                          backgroundColor: AppColors.mainColor,
                          textStyle: Fonts.textWhite18,
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          margin: EdgeInsets.symmetric(horizontal: 5.w),
                          onTap: () =>
                              cubit.pagingController.retryLastFailedRequest(),
                          buttonText: "Retry".tr(),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
