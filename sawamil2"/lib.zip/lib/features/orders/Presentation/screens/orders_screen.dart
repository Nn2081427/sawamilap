import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_tab_bar_widget.dart';
import 'package:swamiil/features/orders/Presentation/widgets/NewUserOrdersWidget.dart';
import 'package:swamiil/features/orders/Presentation/widgets/finished_user_orders.dart';
import 'package:swamiil/features/orders/Presentation/widgets/waiting_user_orders.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion(
      value: barColor(),
      child: SafeArea(
        top: true,
        bottom: false,
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBarWidget(title: "My Orders".tr()),
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 15),
            child: CustomTabBarWidget(
              tabTitles: ["New".tr(), "Waiting".tr(), "Finished".tr()],
              tabContents: [
                Newuserorderswidget(),
                WaitingUserOrders(),
                FinishedUserOrders(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
