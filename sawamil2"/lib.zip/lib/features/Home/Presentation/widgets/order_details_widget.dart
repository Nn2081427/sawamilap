import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/default_text_form_field.dart';
import 'package:swamiil/core/widgets/text_field.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/main.dart';

class OrderDetailsWidget extends StatelessWidget {
  const OrderDetailsWidget({
    super.key,
    required this.orderController,
    this.onChanged,
    this.hintText,
  });

  final TextEditingController orderController;
  final void Function(String)? onChanged;
  final String? hintText;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 0.5.h),
        Text(
          "Order details".tr(),
          style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
        ),

        TextFieldWidget(
          controller: orderController,
          width: double.infinity,
          onChange: onChanged,
          borderRadius: 10,
          hintText: hintTextForOrderDetailsWidget(),
          hintStyle:
              Fonts.text16Black.copyWith(fontSize: 14.sp, color: Colors.black),
          contentPadding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 4.w),
        ),
        // DefaultTextFormField(
        //   // Use dynamic hint text based on order type if provided, otherwise use default
        //   hintText: hintTextForOrderDetailsWidget(),
        //   controller: orderController,
        //   onChanged: onChanged,
        //   hintTextColor: Colors.black,
        // ),
      ],
    );
  }
}

String hintTextForOrderDetailsWidget() {
  if (navigatorKey.currentContext?.read<HomeCubit>().state.orderType == "buy") {
    return "enter_order_details".tr();
  } else {
    return "car_condition_details".tr();
  }
}
