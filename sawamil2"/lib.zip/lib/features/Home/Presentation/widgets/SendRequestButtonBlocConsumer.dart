import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/widgets/default_eleveted_button.dart';
import 'package:swamiil/features/Home/Presentation/cubits/date_picker_cubit/date_picker_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/upload%20images%20cubit/upload_images_cubit.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';

class SendRequestButtonBlocConsumer extends StatelessWidget {
  const SendRequestButtonBlocConsumer({
    super.key,
    required this.orderController,
    required this.customBrandController,
    required this.formKey,
  });

  final TextEditingController orderController;
  final TextEditingController customBrandController;
  final GlobalKey<FormState> formKey;
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomeCubit, HomeState>(
      listener: (context, state) {
        if (state.status == HomeStatus.success) {
          successDialog(lottie: Assets.lottieSuccess);
          orderController.clear();
          customBrandController.clear();
          context.read<BrandsCubit>().clearBrandsListTypes();
          context.read<DatePickerCubit>().clearSelection();
          context.read<ImageCubit>().clearImages();
          context.read<HomeCubit>().clear();
          context.read<BrandsCubit>().getBrandsTypes(
              brandId: context.read<BrandsCubit>().selectedBrandId!);
        } else if (state.status == HomeStatus.error &&
            state.errorMessage != null &&
            !state.errorMessage!.contains('validation')) {
          // showToast(state.errorMessage);
        }
      },
      builder: (context, state) {
        return DefaultElevetedButton(
          borderRadius: 12,
          onPressed: state.status == HomeStatus.loading
              ? () {}
              : () {
                  if (formKey.currentState!.validate()) {
                    context.read<HomeCubit>().createOrder();
                  }
                },
          label: "Send Request".tr(),
          fontSize: 15,

          //    isLoading: state.status == HomeStatus.loading,
        );
      },
    );
  }
}
