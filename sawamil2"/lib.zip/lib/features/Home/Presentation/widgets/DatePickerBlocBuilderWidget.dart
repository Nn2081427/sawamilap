import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/drop_down_widget.dart';
import 'package:swamiil/features/Home/Presentation/cubits/date_picker_cubit/date_picker_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';

class DatePickerBlocBuilderWidget extends StatelessWidget {
  const DatePickerBlocBuilderWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 3,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BlocBuilder<DatePickerCubit, DatePickerState>(
            builder: (context, state) {
              if (state is DatePickerLoading) {
                return const Center(child: CircularProgressIndicator());
              } else if (state is DatePickerError) {
                return Text(state.message);
              }
              return DropDownWidget(
                padding: 0.5.h,

                dropDownClass: context.read<DatePickerCubit>(),
                borderRadius: 8,
                color: Colors.white,
                // borderColor: Colors.grey,
                borderColor: context.read<HomeCubit>().state.hasError('year')
                    ? Colors.red
                    : Colors.grey.withOpacity(0.5),
              );
            },
          ),
          if (context.read<HomeCubit>().state.hasError('year'))
            Padding(
              padding: const EdgeInsets.only(top: 5.0, left: 10.0),
              child: Text(
                context.read<HomeCubit>().state.getError('year')!,
                style: Fonts.textWhite18.copyWith(
                  color: Colors.red,
                  fontSize: 12.sp,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
