import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/utilies/ImagePickerUtil.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/upload%20images%20cubit/upload_images_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/upload%20images%20cubit/upload_images_state.dart';
import 'package:swamiil/features/Home/Presentation/widgets/upload_images_widget.dart';

class ImageBlocBuilderWidget extends StatelessWidget {
  const ImageBlocBuilderWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ImageCubit, ImageState>(
      builder: (context, imageState) {
        final homeState = context.read<HomeCubit>().state;
        final isBuyOrder = homeState.orderType == "buy";
        final isSellOrder = homeState.orderType == "sell";

        return UploadImagesWidget(
          images: imageState.images,
          maxImages: isBuyOrder ? 1 : 3, // 1 for buy, 3 for sell
          errorText: homeState.validationErrors['images'],
          onPickImage: () async {
            // Prevent picking if limits reached
            if (isBuyOrder && imageState.images.length >= 1) {
              showToast('maximum_one_image'.tr());
              return;
            }
            if (isSellOrder && imageState.images.length >= 3) {
              showToast('maximum_three_images'.tr());
              return;
            }

            final remainingSlots = isBuyOrder
                ? 1 - imageState.images.length
                : 3 - imageState.images.length;

            final pickedImages =
                await ImagePickerUtil.showImageSourcePickerMulti(
              context: context,
              onLoading: (_) {},
            );

            if (pickedImages != null && pickedImages.isNotEmpty) {
              final imagesToAdd = isBuyOrder
                  ? pickedImages.take(1).toList()
                  : pickedImages.take(remainingSlots).toList();

              context
                  .read<ImageCubit>()
                  .addImage(imagesToAdd.whereType<XFile>().toList());
              context
                  .read<HomeCubit>()
                  .addImages(imagesToAdd.whereType<XFile>().toList());

              if (isSellOrder && pickedImages.length > remainingSlots) {
                showToast('added_images'.tr(args: [
                  imagesToAdd.length.toString(),
                  pickedImages.length.toString()
                ]));
              }
            }
          },
          isRequired: isSellOrder,
          onRemoveImage: (index) {
            context.read<ImageCubit>().removeImage(index);
            context.read<HomeCubit>().removeImage(index);
          },
          helperText: isSellOrder && imageState.images.isEmpty
              ? 'at_least_one_required'.tr()
              : null,
        );
      },
    );
  }
}
