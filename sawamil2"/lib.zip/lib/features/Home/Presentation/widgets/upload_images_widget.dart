import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

class UploadImagesWidget extends StatelessWidget {
  final List<XFile> images;
  final VoidCallback onPickImage;
  final Function(int index) onRemoveImage;
  final int maxImages;
  final String? errorText;
  final String? helperText;
  final bool isRequired;

  const UploadImagesWidget({
    super.key,
    required this.images,
    required this.onPickImage,
    required this.onRemoveImage,
    this.maxImages = 3, // Default to 3 (sell order)
    this.errorText,
    this.helperText,
    this.isRequired = false,
  });

  @override
  Widget build(BuildContext context) {
    final canAddMore = images.length < maxImages;
    final showError = errorText != null && errorText!.isNotEmpty;
    final showHelper =
        helperText != null && helperText!.isNotEmpty && !showError;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 0.5.h),

        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              "Upload Images".tr(),
              style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
            ),
            SizedBox(width: 2.w),
            Text(
              isRequired ? 'required'.tr() : 'optional'.tr(),
              style: Fonts.text16Black.copyWith(
                  fontWeight: FontWeight.w500,
                  fontSize: 14.sp,
                  color: Colors.grey),
            ),
            Text(
              " ($maxImages)".tr(),
              style: Fonts.text16Black.copyWith(
                  fontWeight: FontWeight.w500,
                  fontSize: 14.sp,
                  color: Colors.grey),
            )
          ],
        ),
        SizedBox(height: 2.h),

        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Add Photo Container
            canAddMore
                ? Column(
                    children: [
                      GestureDetector(
                        onTap: canAddMore ? onPickImage : null,
                        child: DottedBorder(
                          color: showError ? Colors.red : Colors.grey.shade400,
                          strokeWidth: showError ? 1.5 : 1,
                          borderType: BorderType.RRect,
                          radius: const Radius.circular(12),
                          dashPattern: [6, 4],
                          child: Container(
                            width: 30.w,
                            height: 100,
                            decoration: BoxDecoration(
                              color: Colors.transparent,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "Add Photos".tr(),
                                  style: Fonts.text16Black.copyWith(
                                    color:
                                        canAddMore ? Colors.black : Colors.grey,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                SvgPicture.asset(
                                  Assets.cameraImage,
                                  width: 60,
                                  height: 60,
                                  fit: BoxFit.fill,
                                ),
                                if (!canAddMore)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 4),
                                    child: Text(
                                      'Max $maxImages'.tr(),
                                      style: Fonts.text16Black.copyWith(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 10.sp,
                                          color: Colors.grey),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                : const SizedBox.shrink(),

            const SizedBox(width: 10),

            // Image List (scrollable under the add container)
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 5),
                  SizedBox(
                    height: 100,
                    child: images.isEmpty
                        ? SizedBox.shrink()
                        : ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount: images.length,
                            itemBuilder: (context, index) {
                              return Stack(
                                children: [
                                  Container(
                                    width: 100,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      image: DecorationImage(
                                        image:
                                            FileImage(File(images[index].path)),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    top: 4,
                                    right: 8,
                                    child: GestureDetector(
                                      onTap: () => onRemoveImage(index),
                                      child: const CircleAvatar(
                                        radius: 10,
                                        backgroundColor: Colors.white,
                                        child: Icon(Icons.close,
                                            size: 12, color: Colors.black),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ],
        ),

        // Validation messages
        if (showError)
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 10),
            child: Text(
              errorText!,
              style: TextStyle(
                color: Colors.red,
                fontSize: 10.sp,
              ),
            ),
          ),
        if (showHelper)
          Padding(
            padding: const EdgeInsets.only(top: 4, left: 10, right: 10),
            child: Text(
              helperText!,
              style: Fonts.text16Black.copyWith(
                  fontWeight: FontWeight.w500,
                  fontSize: 13.sp,
                  color: Colors.grey),
            ),
          ),

        // Counter
        if (images.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 4, right: 10),
            child: Text(
              '${images.length}/$maxImages ${'images'.tr()}',
              style: Fonts.text16Black.copyWith(
                  fontWeight: FontWeight.w500,
                  fontSize: 12.sp,
                  color: Colors.grey),
            ),
          ),
      ],
    );
  }
}
