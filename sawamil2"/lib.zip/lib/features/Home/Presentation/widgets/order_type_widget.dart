import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/checkbox_widget.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';

class OrderTypeWidget extends StatefulWidget {
  const OrderTypeWidget({super.key});

  @override
  State<OrderTypeWidget> createState() => _OrderTypeWidgetState();
}

bool isRequestPartsSelected = true;

class _OrderTypeWidgetState extends State<OrderTypeWidget> {
  @override
  void initState() {
    context.read<HomeCubit>().setOrderType("buy");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 0.5.h),
        Text(
          "Request type".tr(),
          style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _buildOption(
                isSelected: isRequestPartsSelected,
                text: "Request parts from the junkyard".tr(),
                onTap: () {
                  context
                      .read<HomeCubit>()
                      .clearAllImagesWhenOrderTypeChanges();

                  context.read<HomeCubit>().setOrderType("buy");
                  setState(() => isRequestPartsSelected = true);
                }),
            const SizedBox(width: 10),
            _buildOption(
                isSelected: !isRequestPartsSelected,
                text: "Display car for sale, scrap".tr(),
                onTap: () {
                  context
                      .read<HomeCubit>()
                      .clearAllImagesWhenOrderTypeChanges();
                  context.read<HomeCubit>().setOrderType("sell");
                  setState(() => isRequestPartsSelected = false);
                }),
          ],
        ),
      ],
    );
  }

  Widget _buildOption({
    required bool isSelected,
    required String text,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 1.7.h),
          //   height: 6.5.h,
          decoration: BoxDecoration(
            color: isSelected ? AppColors.opcityOrange : Colors.white,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(
              color: isSelected ? AppColors.mainColor : Colors.grey.shade300,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              CheckBoxWidget(
                check: isSelected,
                onChange: (bool value) => onTap(),
              ),
              Expanded(
                child: FittedBox(
                  child: Text(
                    text,
                    style: Fonts.textBlack18.copyWith(fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
