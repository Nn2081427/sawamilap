import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/default_text_form_field.dart';

class OrderDetails extends StatelessWidget {
  const OrderDetails({super.key, required this.orderController});
  final TextEditingController orderController;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Order details".tr(),
          style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w600),
        ),
        SizedBox(
          height: 12,
        ),
        DefaultTextFormField(
          hintText: "Give us some information about the car's condition".tr(),
          controller: orderController,
          hintTextColor: Colors.black,
        ),
      ],
    );
  }
}
