import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/svg_widget.dart';
import 'package:swamiil/features/notifications/presentation/cubit/notifications_cubit.dart';
import 'package:swamiil/features/notifications/presentation/screens/notifications_screen.dart';

class NewOrderWidget extends StatelessWidget {
  const NewOrderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          "Create New Order".tr(),
          style: Fonts.text20Orange
              .copyWith(color: Colors.black, fontWeight: FontWeight.w500),
        ),
        Spacer(),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: Colors.white,
            border: Border.all(color: Colors.grey.shade300, width: 2),
          ),
          child: GestureDetector(
            onTap: () {
              NotificationsCubit().navigateToNotifications();
            },
            child: SvgWidget(svg: Assets.notificationsIcon),
          ),
        ),
      ],
    );
  }
}
