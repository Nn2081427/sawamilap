import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/ImagesPreviewWidget.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

import '../../../orders/domain/entity/order_image_entity.dart';

class UploadImageWidget extends StatelessWidget {
  const UploadImageWidget({
    super.key,
    this.title,
    this.weight,
    required this.isRestrictedScreen,
    required this.images,
  });

  final String? title;
  final FontWeight? weight;
  final bool isRestrictedScreen;
  final List<String>? images;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!isRestrictedScreen)
          Text(
            title ?? "Upload Images".tr(),
            style: Fonts.textBlack18.copyWith(
              fontWeight: weight ?? FontWeight.w600,
            ),
          ),
        const SizedBox(height: 10),
        if (images != null && images!.isNotEmpty)
          SizedBox(
            height: 13.h,
            child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: images!.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5.0),
                child: InkWell(
                  onTap: () {
                    navP(ImagesPreviewWidget(
                        images: images!,
                        index: index));
                  },
                  child: Hero(
                    tag: images![index],
                    child: CustomImageCacheProvider(
                      borderRadius: 15,
                      imageUrl: images![index],
                      width: 27.w,
                      height: 7.h,
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
