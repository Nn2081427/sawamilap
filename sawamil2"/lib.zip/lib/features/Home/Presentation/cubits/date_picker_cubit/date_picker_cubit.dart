import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/models/drop_down_class.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/main.dart';

part 'date_picker_state.dart';

class DatePickerCubit extends Cubit<DatePickerState>
    implements DropDownClass<DateItem> {
  DatePickerCubit() : super(DatePickerInitial()) {
    getDates();
  }

  List<DateItem> dates = [];
  DateItem? selectedDate;
  void clearSelection() {
    selectedDate = DateItem(id: 0, name: DateTime.now().year.toString());
    emit(DatePickerInitial());
  }

  Future<void> getDates() async {
    emit(DatePickerLoading());
    try {
      final currentYear = DateTime.now().year;
      navigatorKey.currentContext!
          .read<HomeCubit>()
          .setYear(currentYear.toString());

      dates = List.generate(
        currentYear - 1990 + 1,
        (index) => DateItem(
          id: 1990 + index,
          name: (1990 + index).toString(),
        ),
      ).reversed.toList();
      emit(DatePickerLoaded(dates: dates));
      if (dates.isNotEmpty) {
        selectedDate = dates[0];
        emit(DatePickerSelected(selectedDate: selectedDate));
      }
    } catch (e) {
      emit(DatePickerError(message: 'Failed to load dates'));
    }
  }

  @override
  String displayedName() {
    return selectedDate?.name ?? 'Select Date'.tr();
  }

  @override
  String displayedOptionName(DateItem type) {
    return type.name;
  }

  @override
  Widget? displayedOptionWidget(DateItem type) {
    return null; // No custom widget for options
  }

  @override
  Widget? displayedWidget() {
    return null; // No custom widget for the dropdown
  }

  @override
  List<DateItem> list() {
    return dates;
  }

  @override
  Future onTap(DateItem? data) async {
    selectedDate = data;
    emit(DatePickerSelected(selectedDate: data));
    return Future.value();
  }

  @override
  DateItem? selected() {
    navigatorKey.currentContext!.read<HomeCubit>().setYear(selectedDate!.name);
    return selectedDate;
  }

  @override
  dynamic value() {
    return selectedDate?.id;
  }
}

class DateItem {
  final int id; // Unique identifier (e.g., year or timestamp)
  final String name; // Display name (e.g., "2023" or "01/01/2023")

  DateItem({required this.id, required this.name});

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DateItem && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}
