part of 'date_picker_cubit.dart';

abstract class DatePickerState extends Equatable {
  const DatePickerState();

  @override
  List<Object?> get props => [];
}

class DatePickerInitial extends DatePickerState {}

class DatePickerLoading extends DatePickerState {}

class DatePickerLoaded extends DatePickerState {
  final List<DateItem> dates;

  const DatePickerLoaded({required this.dates});

  @override
  List<Object?> get props => [dates];
}

class DatePickerError extends DatePickerState {
  final String message;

  const DatePickerError({required this.message});

  @override
  List<Object?> get props => [message];
}

class DatePickerSelected extends DatePickerState {
  final DateItem? selectedDate;

  const DatePickerSelected({this.selectedDate});

  @override
  List<Object?> get props => [selectedDate];
}