import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:swamiil/features/Home/Presentation/cubits/upload%20images%20cubit/upload_images_state.dart';

class ImageCubit extends Cubit<ImageState> {
  ImageCubit() : super(ImageState.initial()) {
    _loadImages();
  }

  Future<void> _loadImages() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePaths = prefs.getStringList('uploaded_images');
    if (imagePaths != null) {
      final images = imagePaths.map((path) => XFile(path)).toList();
      emit(state.copyWith(images: images));
    }
  }

  Future<void> _saveImages() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePaths = state.images.map((image) => image.path).toList();
    await prefs.setStringList('uploaded_images', imagePaths);
  }

  void addImage(List<XFile> image) {
    final updatedImages = List<XFile>.from(state.images)..addAll(image);
    emit(state.copyWith(images: updatedImages));
    _saveImages();
  }

  void removeImage(int index) {
    final updatedImages = List<XFile>.from(state.images)..removeAt(index);
    emit(state.copyWith(images: updatedImages));
    _saveImages();
  }

  void clearImages() {
    emit(state.copyWith(images: []));
    _saveImages();
  }
}
