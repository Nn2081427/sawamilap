import 'package:image_picker/image_picker.dart';

class ImageState {
  final List<XFile> images;

  ImageState({required this.images});

  factory ImageState.initial() => ImageState(images: []);

  ImageState copyWith({List<XFile>? images}) {
    return ImageState(images: images ?? this.images);
  }
}