part of 'home_cubit.dart';

enum HomeStatus { initial, loading, success, error }

class HomeState extends Equatable {
  final String notes;
  final String? orderType;
  final int? brandId;
  final int? brandTypeId;
  final String? brandName;
  final String? year;
  final List<String> images;
  final HomeStatus status;
  final String? errorMessage;
  final Map<String, String> validationErrors;

  const HomeState({
    this.notes = '',
    this.orderType,
    this.brandId,
    this.brandTypeId,
    this.brandName,
    this.year,
    this.images = const [],
    this.status = HomeStatus.initial,
    this.errorMessage,
    this.validationErrors = const {},
  });

  HomeState copyWith({
    String? notes,
    String? orderType,
    int? brandId,
    int? brandTypeId,
    String? brandName,
    String? year,
    List<String>? images,
    HomeStatus? status,
    String? errorMessage,
    Map<String, String>? validationErrors,
  }) {
    return HomeState(
      notes: notes ?? this.notes,
      orderType: orderType ?? this.orderType,
      brandId: brandId ?? this.brandId,
      brandTypeId: brandTypeId ?? this.brandTypeId,
      brandName: brandName ?? this.brandName, 
      year: year ?? this.year,
      images: images ?? this.images,
      status: status ?? this.status,
      errorMessage: errorMessage ?? this.errorMessage,
      validationErrors: validationErrors ?? this.validationErrors,
    );
  }

  // Helper methods to check specific validation errors
  bool hasError(String field) => validationErrors.containsKey(field);
  String? getError(String field) => validationErrors[field];

  @override
  List<Object?> get props => [
        notes,
        orderType,
        brandId,
        brandTypeId,
        brandName,
        year,
        images,
        status,
        errorMessage,
        validationErrors,
      ];
}