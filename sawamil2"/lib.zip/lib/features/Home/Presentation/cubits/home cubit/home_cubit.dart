import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/Home/Presentation/cubits/upload%20images%20cubit/upload_images_cubit.dart';
import 'package:swamiil/features/Home/domain/use_case/home_use_case.dart';
import 'package:swamiil/main.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  final HomeUseCase homeUseCase;

  HomeCubit({required this.homeUseCase}) : super(const HomeState());
  void clearAllImagesWhenOrderTypeChanges() {
    if (state.images.isNotEmpty) {
      navigatorKey.currentContext!.read<ImageCubit>().clearImages();
      state.images.clear();
    }
  }

  void setNotes(String? notes) {
    emit(state.copyWith(notes: notes ?? ''));
  }

  void setOrderType(String orderType) {
    final currentImages = state.images;
    final shouldClearImages =
        state.orderType != orderType && currentImages.isNotEmpty;

    emit(state.copyWith(
      orderType: orderType,
      images: shouldClearImages ? [] : currentImages,
      // Clear any image-specific errors when changing order type
      validationErrors: shouldClearImages
          ? (Map<String, String>.from(state.validationErrors)..remove('images'))
          : state.validationErrors,
    ));

    if (shouldClearImages) {
      showToast('images_cleared'.tr());
    }
  }

  void setBrandId(int? brandId) {
    if (brandId != state.brandId) {
      emit(state.copyWith(
        brandId: brandId,
        brandTypeId: null,
        brandName: brandId == 0 ? state.brandName : null,
        validationErrors: Map<String, String>.from(state.validationErrors)
          ..remove('brand')
          ..remove('brandName')
          ..remove('brandType'),
      ));
    } else {
      emit(state.copyWith(brandId: brandId));
    }
  }

  void setBrandTypeId(int? brandTypeId) {
    emit(state.copyWith(
      brandTypeId: brandTypeId,
      validationErrors: Map<String, String>.from(state.validationErrors)
        ..remove('brandType'),
    ));
  }

  void setBrandName(String? brandName) {
    emit(state.copyWith(
      brandName: brandName,
      validationErrors: Map<String, String>.from(state.validationErrors)
        ..remove('brandName'),
    ));
  }

  void setYear(String? year) {
    emit(state.copyWith(
      year: year,
      validationErrors: Map<String, String>.from(state.validationErrors)
        ..remove('year'),
    ));
  }

  void addImages(List<XFile> images) {
    final currentImages = List<String>.from(state.images);
    final paths = images.map((xfile) => xfile.path).toList();

    if (state.orderType == "buy") {
      // For "buy" orders (spare parts): optional (0-1 images)
      if (paths.isNotEmpty) {
        if (currentImages.isEmpty) {
          // Add first image if none exists
          emit(state.copyWith(
            images: [paths.first],
            validationErrors: Map.from(state.validationErrors)
              ..remove('images'),
          ));

          if (paths.length > 1) {
            showToast('only_one_image_allowed'.tr());
          }
        } else {
          showToast('maximum_one_image'.tr());
        }
      }
    } else if (state.orderType == "sell") {
      // For "sell" orders (cars): required (1-3 images)
      if (currentImages.length + paths.length > 3) {
        // Calculate how many we can add without exceeding limit
        final availableSlots = 3 - currentImages.length;
        if (availableSlots > 0) {
          final limitedPaths = paths.take(availableSlots).toList();
          emit(state.copyWith(
            images: [...currentImages, ...limitedPaths],
            validationErrors: Map.from(state.validationErrors)
              ..remove('images'),
          ));
          showToast('maximum_three_images'.tr());
        } else {
          showToast('maximum_three_images'.tr());
        }
      } else {
        emit(state.copyWith(
          images: [...currentImages, ...paths],
          validationErrors: Map.from(state.validationErrors)..remove('images'),
        ));
      }
    }
  }

  void removeImage(int index) {
    if (index >= 0 && index < state.images.length) {
      final updatedImages = List<String>.from(state.images);
      updatedImages.removeAt(index);
      emit(state.copyWith(
        images: updatedImages,
        validationErrors: Map<String, String>.from(state.validationErrors)
          ..remove('images'),
      ));
    }
  }

  void clear() {
    emit(const HomeState());
    setOrderType("buy");
    setYear(DateTime.now().year.toString());
  }

  Map<String, String> validateForm() {
    final errors = <String, String>{};
    if (state.brandId == null) {
      errors['brand'] = 'please_select_brand'.tr();
    } else if (state.brandId == 0 &&
        (state.brandName == null || state.brandName!.isEmpty)) {
      errors['brandName'] = 'enter_custom_brand'.tr();
    } else if (state.brandId != 0 && state.brandTypeId == null) {
      errors['brandType'] = 'select_car_model'.tr();
    }

    // Year validation
    if (state.year == null || state.year!.isEmpty) {
      errors['year'] = 'select_year'.tr();
    }

    // Order type validation
    if (state.orderType == null || state.orderType!.isEmpty) {
      errors['orderType'] = 'select_order_type'.tr();
    }

    // Image validation based on order type
    if (state.orderType == "sell") {
      // For car sale listings: at least 1 image, max 3
      if (state.images.isEmpty) {
        errors['images'] = 'upload_one_image'.tr();
      } else if (state.images.length > 3) {
        errors['images'] = 'max_three_images'.tr();
      }
    } else if (state.orderType == "buy") {
      // For spare part requests: optional, max 1
      if (state.images.length > 1) {
        errors['images'] = 'max_one_image'.tr();
      }
    }

    return errors;
  }

  Future<void> createOrder() async {
    final validationErrors = validateForm();

    if (validationErrors.isNotEmpty) {
      showToast(validationErrors.values.first);

      emit(state.copyWith(
        validationErrors: validationErrors,
        status: HomeStatus.error,
        errorMessage: 'fix_validation'.tr(),
      ));
      return;
    }

    emit(state.copyWith(
      status: HomeStatus.loading,
      validationErrors: {},
    ));
    loading();
    final data = <String, dynamic>{};
    if (state.brandId == 0) {
      data['brand_name'] = state.brandName;
    } else {
      data['brand_id'] = state.brandId;
      data['brand_model_id'] = state.brandTypeId;
    }
    data['year'] = state.year;
    data['order_type'] = state.orderType;
    if (state.notes.isNotEmpty) {
      data['notes'] = state.notes;
    }
    try {
      List<MultipartFile> imageFiles = [];
      if (state.images.isNotEmpty) {
        imageFiles = await Future.wait(
          state.images.map((path) async {
            try {
              return await MultipartFile.fromFile(path);
            } catch (e) {
              throw Exception(
                  'Failed to process image at $path: ${e.toString()}');
            }
          }),
        );
      }
      final Map<String,dynamic> formData = {
        ...data,
        if (imageFiles.isNotEmpty) 'images[]': imageFiles,
      };

      final result = await homeUseCase.createOrder(formData: formData);
      navPop();
      result.fold(
        (error) {
          showToast(error.message ?? "Unknown error");
          emit(state.copyWith(
            status: HomeStatus.error,
            errorMessage: error.message,
          ));
        },
        (_) => emit(state.copyWith(status: HomeStatus.success)),
      );
    } catch (e) {
      navPop();
      final errorMessage = e.toString().contains('Failed to process image')
          ? 'error_processing'.tr()
          : e.toString();

      emit(state.copyWith(
        status: HomeStatus.error,
        errorMessage: errorMessage,
      ));
    }
  }
}
