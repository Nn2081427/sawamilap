import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/widgets/main_layout_page.dart';
import 'package:swamiil/core/widgets/pull_to_refresh_widget.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/brands/presentation/widgets/CardBrandTypeBlocBuilderWidget.dart';
import 'package:swamiil/features/Home/Presentation/widgets/DatePickerBlocBuilderWidget.dart';
import 'package:swamiil/features/Home/Presentation/widgets/ImageBlocBuilderWidget.dart';
import 'package:swamiil/features/Home/Presentation/widgets/SendRequestButtonBlocConsumer.dart';
import 'package:swamiil/features/brands/presentation/widgets/car_type_widget.dart';
import 'package:swamiil/features/Home/Presentation/widgets/new_order_widget.dart';
import 'package:swamiil/features/Home/Presentation/widgets/order_details_widget.dart';
import 'package:swamiil/features/Home/Presentation/widgets/order_type_widget.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final TextEditingController orderController = TextEditingController();
  final TextEditingController customBrandController = TextEditingController();
  final RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    orderController.dispose();
    customBrandController.dispose();
    _refreshController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MainLayoutPage(
      child: SafeArea(
        top: true,
        bottom: false,
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18.0, vertical: 10),
            child: Form(
              key: formKey,
              child: Column(
                children: [
                  const NewOrderWidget(),
                  const SizedBox(height: 10),
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BlocBuilder<HomeCubit, HomeState>(
                            builder: (context, homeState) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const CarTypeWidget(),
                                  SizedBox(height: 2.h),
                                  SizedBox(
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        CardBrandTypeBlocBuilderWidget(
                                          customBrandController:
                                              customBrandController,
                                        ),
                                        const SizedBox(width: 10),
                                        DatePickerBlocBuilderWidget(),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 15),
                                  const OrderTypeWidget(),
                                  const SizedBox(height: 15),
                                  OrderDetailsWidget(
                                    orderController: orderController,
                                    onChanged: (value) => context
                                        .read<HomeCubit>()
                                        .setNotes(value),
                                  ),
                                  SizedBox(height: 2.h),
                                  ImageBlocBuilderWidget(),
                                  SizedBox(height: 2.h),
                                  SendRequestButtonBlocConsumer(
                                    orderController: orderController,
                                    formKey: formKey,
                                    customBrandController:
                                        customBrandController,
                                  ),
                                  SizedBox(height: 2.h),
                                ],
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
