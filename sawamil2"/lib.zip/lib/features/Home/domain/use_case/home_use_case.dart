import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/Home/domain/repos/home_repo.dart';

class HomeUseCase {
  final HomeRepo homeRepo;

  HomeUseCase({required this.homeRepo});

  Future<Either<DioException, bool>> createOrder(
      {required Map<String,dynamic>  formData}) async {
    return homeRepo.createOrder(formData : formData);
  }
}
