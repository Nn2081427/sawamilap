import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';

abstract class HomeRepo {
  Future<Either<DioException, bool>> createOrder(
      {required Map<String,dynamic> formData});
}
