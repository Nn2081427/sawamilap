import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/Home/data/data_source/home_remote_data_source.dart';
import 'package:swamiil/features/Home/domain/repos/home_repo.dart';

class HomeRepoImpl extends HomeRepo {
  final HomeRemoteDataSource homeRemoteDataSource;

  HomeRepoImpl({required this.homeRemoteDataSource});
  @override
  Future<Either<DioException, bool>> createOrder(
      {required Map<String,dynamic>  formData}) async {
    return homeRemoteDataSource.createOrder(formData: formData);
  }
}
