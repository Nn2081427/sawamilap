import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';

class HomeRemoteDataSource {
  final ApiHandel apiHandel;

  HomeRemoteDataSource({required this.apiHandel});

  Future<Either<DioException, bool>> createOrder({
    required Map<String,dynamic> formData ,
  }) async {
    // Send POST request
    final response = await ApiHandel.getInstance.post(
      '/user/create_order',
      formData,
    );

    return response.fold((l) => Left(l), (r) => const Right(true));
  }
}
