part of 'brands_type_cubit.dart';

abstract class BrandsTypeState {}

final class BrandsTypeInitial extends BrandsTypeState {}

final class BrandsTypeLoading extends BrandsTypeState {}

final class BrandsTypeLoaded extends BrandsTypeState {
  final List<BrandTypeEntity> brandTypes;
  BrandsTypeLoaded({required this.brandTypes});
}

final class BrandsTypeError extends BrandsTypeState {
  final String message;
  BrandsTypeError({required this.message});
}
