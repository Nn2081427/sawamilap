import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';
import 'package:swamiil/features/brands/domain/usecases/get_brands_use_case.dart';

part 'brands_type_state.dart';

class BrandsTypeCubit extends Cubit<BrandsTypeState> {
  BrandsTypeCubit(this.getBrandsTypeUseCase) : super(BrandsTypeInitial());

  final GetBrandsUseCase getBrandsTypeUseCase;

  Future<void> getBrandsTypes({required int brandId}) async {
    emit(BrandsTypeLoading());
    Map<String,dynamic> data = {};
    data['brand_id'] = brandId;
    final result = await getBrandsTypeUseCase.getBrandTypeUseCase(data);
    result.fold((l) => emit(BrandsTypeError(message: l.message!)),
        (r) => emit(BrandsTypeLoaded(brandTypes: r)));
  }
}
