import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/models/drop_down_class.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';
import 'package:swamiil/features/brands/domain/entities/brands_entitiy.dart';
import 'package:swamiil/features/brands/domain/usecases/get_brands_use_case.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_state.dart';
import 'package:swamiil/main.dart';

class BrandsCubit extends Cubit<BrandsState>
    implements DropDownClass<BrandTypeEntity> {
  BrandsCubit({required this.brandsUseCase}) : super(BrandsInitial());

  final GetBrandsUseCase brandsUseCase;
  String customBrandTypeName = '';
  List<BrandTypeEntity> brandTypes = [];
  BrandTypeEntity? selectedBrandType;
  int? selectedBrandId;
  Function(int)? onBrandTypeSelected;

  Future<void> getAllBrands() async {
    emit(BrandsLoading());
    final result = await brandsUseCase.getBrandsUseCase();
    result.fold((l) {
      emit(BrandsError(l.message));
      print(l.message);
    }, (r) {
      final brands = List<BrandEntity>.from(r)
        ..add(BrandEntity(name: "طراز اخر", id: 0, image: ''));
      emit(BrandsLoaded(brands: brands));
      // Select first brand by default
      if (brands.isNotEmpty) {
        selectedBrandId = brands[0].id;
        emit(BrandSelected(brandId: selectedBrandId!));
        getBrandsTypes(brandId: selectedBrandId!);
      }
    });
  }

  void clearSelection() {
    selectedBrandId = null;
    selectedBrandType = null;
    customBrandTypeName = '';
    emit(BrandsInitial());
  }

  void clearBrandsListTypes() {
    brandTypes = [];
    selectedBrandType = null;
    customBrandTypeName = '';
    emit(BrandsTypeLoaded(brandTypes: brandTypes));
  }
  void clear(){
    // clearBrandsListTypes();
    // clearSelection();
  }

  Future<void> getBrandsTypes({required int brandId}) async {
    emit(BrandsTypeLoading());
    brandTypes = [];
    selectedBrandType = null;
    selectedBrandId = brandId;

    navigatorKey.currentContext?.read<HomeCubit>().setBrandId(brandId);

    emit(BrandSelected(brandId: brandId));

    if (brandId == 0) {
      brandTypes = [
        BrandTypeEntity(
            brandId: brandId,
            id: 0,
            name: customBrandTypeName.isEmpty ? "Other" : customBrandTypeName)
      ];
      emit(BrandsTypeLoaded(brandTypes: brandTypes));

      navigatorKey.currentContext?.read<HomeCubit>().setBrandTypeId(0);
    } else {
      Map<String,dynamic> data = {};
      data['brand_id'] = brandId;
      final result = await brandsUseCase.getBrandTypeUseCase(data);
      result.fold((l) => emit(BrandsTypeError(message: l.message!)), (r) {
        brandTypes = r;
        emit(BrandsTypeLoaded(brandTypes: brandTypes));

        if (brandTypes.isNotEmpty) {
          onTap(brandTypes[0]);
        }
      });
    }
  }

  void setCustomBrandTypeName(String name) {
    customBrandTypeName = name;
    if (selectedBrandId == 0) {
      brandTypes = [
        BrandTypeEntity(
            brandId: selectedBrandId!,
            id: 0,
            name: name.isEmpty ? "Other" : name)
      ];
      emit(BrandsTypeLoaded(brandTypes: brandTypes));
    }
  }

  @override
  String displayedName() {
    return selectedBrandId == 0
        ? customBrandTypeName.isEmpty
            ? "Car model".tr()
            : customBrandTypeName
        : selectedBrandType?.name ?? "Car model".tr();
  }

  @override
  String displayedOptionName(BrandTypeEntity type) {
    return type.name;
  }

  @override
  Widget? displayedOptionWidget(BrandTypeEntity type) {
    return null;
  }

  @override
  Widget? displayedWidget() {
    return null;
  }

  @override
  List<BrandTypeEntity> list() {
    return brandTypes;
  }

  @override
  Future onTap(BrandTypeEntity? data) async {
    selectedBrandType = data;
    if (data?.id == 0) {
      customBrandTypeName =
          customBrandTypeName.isEmpty ? "Other" : customBrandTypeName;
    }

    // Immediately update HomeCubit state
    navigatorKey.currentContext?.read<HomeCubit>().setBrandTypeId(data?.id);

    if (onBrandTypeSelected != null && data != null) {
      onBrandTypeSelected!(data.id);
    }
    emit(BrandTypeSelected(data));
    return Future.value();
  }

  @override
  BrandTypeEntity? selected() {
    // Only update if we have valid selections
    if (selectedBrandId != null && selectedBrandType != null) {
      navigatorKey.currentContext!.read<HomeCubit>()
        ..setBrandId(selectedBrandId)
        ..setBrandTypeId(selectedBrandType?.id);
    }
    return selectedBrandType;
  }

  @override
  dynamic value() {
    return selectedBrandType?.id;
  }
}
