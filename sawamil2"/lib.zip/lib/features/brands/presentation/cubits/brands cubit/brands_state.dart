import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';
import 'package:swamiil/features/brands/domain/entities/brands_entitiy.dart';

abstract class BrandsState {}

class BrandsInitial extends BrandsState {}

class BrandsLoading extends BrandsState {}

class BrandsLoaded extends BrandsState {
  final List<BrandEntity> brands;
  BrandsLoaded({required this.brands});
}

class BrandsError extends BrandsState {
  final String? message;
  BrandsError(this.message);
}

final class BrandsTypeLoading extends BrandsState {}

final class BrandsTypeLoaded extends BrandsState {
  final List<BrandTypeEntity> brandTypes;
  BrandsTypeLoaded({required this.brandTypes});
}

final class BrandsTypeError extends BrandsState {
  final String message;
  BrandsTypeError({required this.message});
}

class BrandTypeSelected extends BrandsState {
  final BrandTypeEntity? selectedBrandType;

  BrandTypeSelected(this.selectedBrandType);

  @override
  List<Object?> get props => [selectedBrandType];
}

class BrandSelected extends BrandsState {
  final int brandId;

  BrandSelected({required this.brandId});

  @override
  List<Object?> get props => [brandId];
}
