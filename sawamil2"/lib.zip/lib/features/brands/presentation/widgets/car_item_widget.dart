import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';

class CarItemWidget extends StatelessWidget {
  final String name;
  final String iconPath;
  final bool isSelected;
  final VoidCallback onTap;

  const CarItemWidget({
    super.key,
    required this.name,
    required this.iconPath,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: isSelected ? AppColors.opcityOrange : Colors.white,
              shape: BoxShape.circle,
              border: Border.all(
                color: isSelected
                    ? Colors.orange.withOpacity(0.7)
                    : Colors.grey.shade200,
                width: 1.2,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: CustomImageCacheProvider(
                imageUrl: iconPath,
                width: 30,
                height: 30,
              ),
            ),
          ),
          SizedBox(height: 2.h),
          Text(
            name,
            style: Fonts.textBlack18.copyWith(
                fontSize: 16,
                color: isSelected ? Colors.orange : Colors.black,
                fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
