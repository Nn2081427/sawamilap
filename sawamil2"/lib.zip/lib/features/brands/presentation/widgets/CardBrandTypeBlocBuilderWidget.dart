import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/drop_down_widget.dart';
import 'package:swamiil/core/widgets/text_field.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_state.dart';

class CardBrandTypeBlocBuilderWidget extends StatelessWidget {
  const CardBrandTypeBlocBuilderWidget({
    super.key,
    required this.customBrandController,
  });

  final TextEditingController customBrandController;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 4,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BlocBuilder<BrandsCubit, BrandsState>(
                  buildWhen: (previous, current) {
                    return current is BrandSelected ||
                        current is BrandsTypeLoading ||
                        current is BrandsTypeLoaded ||
                        current is BrandsTypeError ||
                        current is BrandTypeSelected;
                  },
                  builder: (context, state) {
                    final isCustomBrand =
                        (state is BrandSelected && state.brandId == 0) ||
                            (context.read<BrandsCubit>().selectedBrandId == 0);
                    if (isCustomBrand) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextFieldWidget(
                            borderRadius: 8,
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 1.35.h, horizontal: 4.w),
                            color: Colors.white,
                            borderColor: context
                                    .read<HomeCubit>()
                                    .state
                                    .hasError('brandName')
                                ? Colors.red
                                : Colors.grey.withOpacity(0.5),
                            controller: customBrandController,
                            hintText: 'طراز السيارة'.tr(),
                            onChange: (value) {
                              context
                                  .read<BrandsCubit>()
                                  .setCustomBrandTypeName(value);
                              context.read<HomeCubit>().setBrandName(value);
                            },
                            width: double.infinity,
                          ),
                          if (context
                              .read<HomeCubit>()
                              .state
                              .hasError('brandName'))
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 5.0, left: 10.0),
                              child: Text(
                                context
                                    .read<HomeCubit>()
                                    .state
                                    .getError('brandName')!,
                                style: Fonts.textWhite18.copyWith(
                                  color: Colors.red,
                                  fontSize: 12.sp,
                                ),
                              ),
                            ),
                        ],
                      );
                    }
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        DropDownWidget(
                          padding: 0.5.h,
                          clear: state is BrandsTypeError
                              ? () => context
                                  .read<BrandsCubit>()
                                  .clearBrandsListTypes()
                              : null,
                          dropDownClass: context.read<BrandsCubit>(),
                          borderRadius: 8,
                          color: Colors.white,
                          borderColor: context
                                  .read<HomeCubit>()
                                  .state
                                  .hasError('brandType')
                              ? Colors.red
                              : Colors.grey,
                        ),
                        if (context
                            .read<HomeCubit>()
                            .state
                            .hasError('brandType'))
                          Padding(
                              padding:
                                  const EdgeInsets.only(top: 5.0, left: 10.0),
                              child: Text(
                                context
                                    .read<HomeCubit>()
                                    .state
                                    .getError('brandType')!,
                                style: Fonts.textWhite18.copyWith(
                                  color: Colors.red,
                                  fontSize: 12.sp,
                                ),
                              )),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
