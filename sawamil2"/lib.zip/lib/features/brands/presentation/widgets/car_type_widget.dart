import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/brands/domain/entities/brands_entitiy.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_state.dart';

import 'car_item_widget.dart';

class CarTypeWidget extends StatefulWidget {
  const CarTypeWidget({super.key});

  @override
  State<CarTypeWidget> createState() => _CarTypeWidgetState();
}

class _CarTypeWidgetState extends State<CarTypeWidget> {
  int selectedIndex = 0;

  @override
  void initState() {
    context.read<BrandsCubit>().getAllBrands();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 2.h),
        Text(
          "Car type".tr(),
          style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w400),
        ),
        SizedBox(height: 20),
        BlocBuilder<BrandsCubit, BrandsState>(
          buildWhen: (previous, current) {
            return current is BrandsLoading ||
                current is BrandsLoaded ||
                current is BrandsError;
          },
          builder: (context, state) {
            if (state is BrandsLoading) {
              return ShimmerWidget(width: double.infinity, height: 100);
            } else if (state is BrandsLoaded) {
              List<BrandEntity> allBrands = state.brands;

              if (allBrands.isNotEmpty && state is! BrandsTypeLoading) {
                context
                    .read<BrandsCubit>()
                    .getBrandsTypes(brandId: allBrands[selectedIndex].id);
              }
              return SizedBox(
                height: 100,
                child: ListView.separated(
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemCount: allBrands.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 16),
                  itemBuilder: (context, index) {
                    final car = allBrands[index];
                    final isSelected = index == selectedIndex;
                    return CarItemWidget(
                      name: car.name,
                      iconPath: car.image,
                      isSelected: isSelected,
                      onTap: () {
                        context.read<BrandsCubit>().clearBrandsListTypes();
                        if (selectedIndex != index) {
                          setState(() {
                            selectedIndex = index;
                          });
                          context
                              .read<BrandsCubit>()
                              .getBrandsTypes(brandId: car.id);
                        }
                      },
                    );
                  },
                ),
              );
            } else if (state is BrandsError) {
              return Text(state.message ?? 'error_request_message'.tr());
            }
            return SizedBox();
          },
        ),
      ],
    );
  }
}
