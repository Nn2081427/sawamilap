
import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';

class BrandsTypeModel extends BrandTypeEntity{

  BrandsTypeModel({required super.id, required super.name, required super.brandId});

 factory BrandsTypeModel.fromJson(Map<String, dynamic> json) {
    return BrandsTypeModel(
      id: json['id'],
      name: json['name'],
      brandId: json['brand_id'],
    );
  }

}