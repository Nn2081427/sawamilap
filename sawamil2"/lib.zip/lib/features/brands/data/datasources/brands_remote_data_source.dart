// import '../../../core/databases/api/api_consumer.dart';
// import '../../../core/databases/api/end_points.dart';
// import '../../../core/params/params.dart';
// import '../models/template_model.dart';

// class TemplateRemoteDataSource {
//   final ApiConsumer api;

//   TemplateRemoteDataSource({required this.api});
//   Future<TemplateModel> getTemplate(TemplateParams params) async {
//     final response = await api.get("${EndPoints.template}/${params.id}");
//     return TemplateModel.fromJson(response);
//   }
// }

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/features/brands/data/models/brand_type_model.dart';
import 'package:swamiil/features/brands/data/models/brands_model.dart';

class BrandsRemoteDataSource {
  Future<Either<DioException, List<BrandModel>>> getBrands() async {
    var response = await ApiHandel.getInstance.get('get_brands');
    return response.fold((l) => Left(l), (r) {
      List<BrandModel> list = [];
      for (var i in r.data['data']) {
        list.add(BrandModel.fromJson(i));
      }
      return Right(list);
    });
  }

  Future<Either<DioException, List<BrandsTypeModel>>> getBrandsTypes(
      Map<String,dynamic> data) async {
    var response = await ApiHandel.getInstance
        .post('get_brand_models', data);
    return response.fold((l) => Left(l), (r) {
      List<BrandsTypeModel> list = [];
      for (var i in r.data['data']) {
        list.add(BrandsTypeModel.fromJson(i));
      }
      return Right(list);
    });
  }
}
