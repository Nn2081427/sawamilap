class BrandEntity {
  final String name;
  final int id;
  final String image;

  const BrandEntity({
    required this.name,
    required this.id,
    required this.image,
  });
}
