
class BrandTypeEntity {
 final int id;
  final int brandId;
  final String name;
  
  BrandTypeEntity({
    required this.id,
    required this.brandId,
    required this.name,
  });
  }