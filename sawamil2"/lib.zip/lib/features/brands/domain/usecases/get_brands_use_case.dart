import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';
import 'package:swamiil/features/brands/domain/entities/brands_entitiy.dart';
import 'package:swamiil/features/brands/domain/repositories/brands_contract_repository.dart';

class GetBrandsUseCase {
  final BrandsContractRepository brandsContractRepository;

  GetBrandsUseCase({required this.brandsContractRepository});

  Future<Either<DioException, List<BrandEntity>>> getBrandsUseCase() async {
    return await brandsContractRepository.getBrands();
  }

  Future<Either<DioException, List<BrandTypeEntity>>> getBrandTypeUseCase(
      Map<String,dynamic> data) async {
    return await brandsContractRepository.getBrandsTypes(data);
  }
}
