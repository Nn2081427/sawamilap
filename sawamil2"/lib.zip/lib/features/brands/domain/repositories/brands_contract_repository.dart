import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/brands/domain/entities/brand_type_entity.dart';
import 'package:swamiil/features/brands/domain/entities/brands_entitiy.dart';

abstract class BrandsContractRepository {
  Future<Either<DioException, List<BrandTypeEntity>>> getBrandsTypes(Map<String,dynamic> data);

  Future<Either<DioException, List<BrandEntity>>> getBrands();
}
