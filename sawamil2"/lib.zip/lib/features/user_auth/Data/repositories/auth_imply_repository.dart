import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/user_auth/Data/datasources/auth_remote_data_source.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';
import 'package:swamiil/features/user_auth/Domain/repositories/auth_contract_repository.dart';

class AuthImplyRepository implements AuthContractRepository {
  @override
  Future<Either<DioException, UserEntity>> loginSocial(
      Map<String, dynamic> data) async {
    return await AuthRemoteDataSource.loginSocial(data);
  }

  @override
  Future<Either<DioException, UserEntity>> getUserProfile() async {
    return await AuthRemoteDataSource.getProfile();
  }

  @override
  Future<Either<DioException, UserEntity>> updateProfile(
      Map<String, dynamic> data) async {
    return await AuthRemoteDataSource.updateProfile(data);
  }

  @override
  Future<Either<DioException, bool>> logout(Map<String, dynamic> data) async {
    return await AuthRemoteDataSource.logout(data);
  }

  @override
  Future<Either<DioException, bool>> deleteAccount() async {
    return await AuthRemoteDataSource.deleteAccount();
  }

  @override
  Future<Either<DioException, bool>> refreshToken(
      Map<String, dynamic> data) async {
    final result = await AuthRemoteDataSource.refreshToken(data);
    return result.fold(
      (l) => Left(l),
      (r) => Right(true),
    );
  }
}
