import 'package:swamiil/features/city/data/models/area_model.dart';
import 'package:swamiil/features/city/data/models/city_model.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  UserModel(
      {required super.id,
      required super.image,
      required super.city,
      required super.area,
      required super.firstName,
      required super.lastName,
      required super.phone,
      required super.email,
      required super.token});

  factory UserModel.fromJson(Map<String, dynamic> json) {
    print(json);

    AreaModel? area;
    CityModel? city;
    if (json.containsKey('area') && json['area'] != null) {
      area = AreaModel.fromJson(json['area']);
      city = CityModel.fromJson(json['area']['city']);
    }

    return UserModel(
        id: json["id"],
        image: json["image"],
        city: city,
        area: area,
        firstName: json["first_name"],
        lastName: json["last_name"],
        phone: json["phone"],
        email: json["email"],
        token: json["token"]);
  }
}
