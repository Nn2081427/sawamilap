import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/core/helper_function/appSecureStore.dart';
import 'package:swamiil/features/user_auth/Data/models/user_model.dart';
import 'package:swamiil/main.dart';

class AuthRemoteDataSource {
  // login
  static Future<Either<DioException, UserModel>> loginSocial(
      Map<String, dynamic> data) async {
    var response = await ApiHandel.getInstance.post('user/social_login', data);
    return response.fold((l) => Left(l), (r) {
      return Right(UserModel.fromJson(r.data['data']));
    });
  }

  // get profile
  static Future<Either<DioException, UserModel>> getProfile() async {
    var response = await ApiHandel.getInstance.get('user/get_profile');
    return response.fold((l) => Left(l), (r) {
      talker.info(r.data['data']);
      return Right(UserModel.fromJson(r.data['data']));
    });
  }

  // update user profile
  static Future<Either<DioException, UserModel>> updateProfile(
      Map<String, dynamic> data) async {
    print('hamza');
    var response =
        await ApiHandel.getInstance.post('user/update_profile', data);
    return response.fold((l) => Left(l), (r) {
      return Right(UserModel.fromJson(r.data['data']));
    });
  }
  

  // logout
  static Future<Either<DioException, bool>> logout(
      Map<String, dynamic> data) async {
    var response = await ApiHandel.getInstance.post('user/logout', data);
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }

  // delete Account
  static Future<Either<DioException, bool>> deleteAccount() async {
    var response = await ApiHandel.getInstance.post('user/delete_account', {});
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }

  // refresh token
  static Future<Either<DioException, bool>> refreshToken(
      Map<String, dynamic> data) async {
    var response = await ApiHandel.getInstance.post('user/refresh_token', data);
    return response.fold((l) => Left(l), (r) {
      AuthSecureStorage.saveAccessToken(r.data['token']);
      ApiHandel.getInstance.updateHeader(r.data['token']);
      return Right(true);
    });
  }
}
