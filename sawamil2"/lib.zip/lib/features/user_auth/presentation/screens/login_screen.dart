import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_container.dart';
import 'package:swamiil/core/widgets/main_layout_page.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/widgets/privacy_widget.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MainLayoutPage(
      child: Scaffold(
        appBar: AppBarWidget(
          title: "Users Login".tr(),
        ),
        extendBodyBehindAppBar: true,
        body: Stack(
          children: [
            Container(
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.center,
                  colors: [const Color(0xFFFFE8DB), Colors.white],
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 18.h,
                    ),
                    Image.asset(
                      Assets.whiteLogoBg,
                      width: 105,
                      height: 105,
                      fit: BoxFit.cover,
                    ),
                    // Text(
                    //   "Save your time and effort and wrap all the scrap metal from your mobile screen."
                    //       .tr(),
                    //   style: Fonts.textBlack18,
                    //   textAlign: TextAlign.center,
                    //   maxLines: 2,
                    // ),
                    SizedBox(
                      height: 10.h,
                    ),
                    CustomContainerWithRow(
                      onTap: () {
                        context
                            .read<AuthCubit>()
                            .showSocialLoginUserType(loginFrom: 'google');
                      },
                      svgAssetPath: Assets.googleIcon,
                      text: "Continue with Google".tr(),
                      backgroundColor: AppColors.textFieldBgColor,
                      textStyle: Fonts.textBlack18.copyWith(fontSize: 16),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    CustomContainerWithRow(
                      svgAssetPath: Assets.appleIcon,
                      text: "Continue With Apple".tr(),
                      onTap: () => context
                          .read<AuthCubit>()
                          .showSocialLoginUserType(loginFrom: 'apple'),
                      backgroundColor: Colors.black,
                      textStyle: Fonts.textBlack18
                          .copyWith(color: Colors.white, fontSize: 16),
                    ),
                    Spacer(),
                    PrivacyWidget(),
                    SizedBox(
                      height: 5.h,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
