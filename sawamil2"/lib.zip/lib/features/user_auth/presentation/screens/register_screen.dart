import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/default_eleveted_button.dart';
import 'package:swamiil/core/widgets/list_text_field.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_state.dart';
class RegisterScreen extends StatelessWidget {
  RegisterScreen({super.key});

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarWidget(
        title: "Users Login".tr(),
      ),
      extendBodyBehindAppBar: true,
      resizeToAvoidBottomInset: true,
      body: BlocBuilder<AuthCubit, AuthState>(
        builder: (context, state) {
          var cubit = context.read<AuthCubit>();
          return Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.center,
                colors: [Color(0xFFFFE8DB), Colors.white],
              ),
            ),
            child: SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    padding: EdgeInsets.only(
                      left: 25,
                      right: 25,
                      bottom: MediaQuery.of(context).viewInsets.bottom,
                    ),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight,
                      ),
                      child: IntrinsicHeight(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 4.h),
                              SizedBox(height: 5.h),
                              Center(
                                child: Image.asset(
                                  Assets.whiteLogoBg,
                                  width: 105,
                                  height: 105,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Text(
                                "Because you are a new user, we need you to fill in the following information."
                                    .tr(),
                                style: Fonts.textBlack18,
                                textAlign: TextAlign.center,
                              ),
                              SizedBox(height: 5.h),
                              ListTextFieldWidget(
                                inputs: cubit.registerInputs,
                                isWrap: true,
                              ),
                              SizedBox(height: 2.h),
                              const SizedBox(height: 15),
                              const SizedBox(height: 25),
                              BlocBuilder<AuthCubit, AuthState>(
                                builder: (context, state) {
                                  return DefaultElevetedButton(
                                    width: double.infinity,
                                    height: 56,
                                    onPressed: () {
                                      if (_formKey.currentState!.validate()) {
                                        context
                                            .read<AuthCubit>()
                                            .userRegester();
                                      }
                                    },
                                    label: "Continue".tr(),
                                    color: AppColors.mainColor,
                                    labelColor: Colors.white,
                                    fontSize: 17,
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
