import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/default_eleveted_button.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/cubit/user_type_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/widgets/user_segment_container.dart';

import '../cubit/auth_state.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => UserTypeCubit(),
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.center,
                  colors: [Color(0xFFFFE8DB), Colors.white],
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    BlocBuilder<UserTypeCubit, UserTypeState>(
                      builder: (context, state) {
                        if (state is UserTypeLoading) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }

                        if (state is UserTypeError) {
                          return Center(
                            child: Text(
                              state.message,
                              style: const TextStyle(color: Colors.red),
                            ),
                          );
                        }

                        if (state is UserTypeLoaded) {
                          return Column(
                            children: List.generate(
                              state.userTypes.length,
                              (index) => UserSegmentContainer(
                                data: state.userTypes[index],
                                onTap: () {
                                  context.read<UserTypeCubit>().setUserType(
                                        state.userTypes[index].key,
                                      );
                                },
                              ),
                            ),
                          );
                        }

                        return const SizedBox.shrink();
                      },
                    ),
                    const SizedBox(height: 40),
                    BlocBuilder<UserTypeCubit, UserTypeState>(
                      builder: (context, state) {
                        final cubit = context.read<UserTypeCubit>();
                        final hasSelection = cubit.hasSelection();

                        return CustomButton(
                          width: double.infinity,
                          height: 60,
                          onTap: hasSelection
                              ? () {
                                  cubit.navigateBasedOnSelection();
                                }
                              : () {},
                          backgroundColor: AppColors.mainColor,
                          child: Text(
                            "Start now".tr(),
                            style: Fonts.textWhite18.copyWith(fontSize: 15),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
