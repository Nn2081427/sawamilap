// user_type_state.dart
part of 'user_type_cubit.dart';

sealed class UserTypeState extends Equatable {
  const UserTypeState();

  @override
  List<Object> get props => [];
}

final class UserTypeInitial extends UserTypeState {}

final class UserTypeLoading extends UserTypeState {}

final class UserTypeLoaded extends UserTypeState {
  final List<UserType> userTypes;

  const UserTypeLoaded({required this.userTypes});

  @override
  List<Object> get props => [userTypes];
}

final class UserTypeError extends UserTypeState {
  final String message;

  const UserTypeError({required this.message});

  @override
  List<Object> get props => [message];
}