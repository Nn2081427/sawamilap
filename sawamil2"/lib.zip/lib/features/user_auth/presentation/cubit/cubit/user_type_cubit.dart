// user_type_cubit.dart
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';
import 'package:swamiil/features/layout/cubit/main_layout_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/screens/login_screen.dart';
import 'package:swamiil/main.dart';

part 'user_type_state.dart';

class UserTypeCubit extends Cubit<UserTypeState> {
  UserTypeCubit() : super(UserTypeInitial()) {
    // Initialize with the default user types
    loadUserTypes();
  }

  // Define the initial user types list as a static constant
  static const List<UserType> _initialUserTypes = [
    UserType(
      title: 'Users entry',
      image: Assets.userIcon,
      isSelected: false,
      key: UserKey.users,
    ),
    UserType(
      title: 'Suppliers\' entry',
      image: Assets.boxIcon,
      isSelected: false,
      key: UserKey.suppliers,
    ),
    UserType(
      title: 'Continue as a guest',
      image: Assets.coffeeIcon,
      isSelected: false,
      key: UserKey.guest,
    ),
  ];

  // Load initial user types
  void loadUserTypes() {
    emit(UserTypeLoading());
    // Simulate loading or just emit the loaded state
    emit(UserTypeLoaded(userTypes: _initialUserTypes));
  }

  // Set user type
  void setUserType(UserKey keyToSelect) {
    final currentState = state;
    if (currentState is UserTypeLoaded) {
      final updatedList = currentState.userTypes.map((type) {
        return type.copyWith(isSelected: type.key == keyToSelect);
      }).toList();
      emit(UserTypeLoaded(userTypes: updatedList));
    }
  }

  // Get selected user type from the current state
  UserType getSelectedUserType() {
    final currentState = state;
    if (currentState is UserTypeLoaded) {
      return currentState.userTypes.firstWhere(
        (e) => e.isSelected,
        orElse: () => UserType.empty(),
      );
    }
    return UserType.empty();
  }

  // Check if any user type is selected
  bool hasSelection() {
    final currentState = state;
    if (currentState is UserTypeLoaded) {
      return currentState.userTypes.any((type) => type.isSelected);
    }
    return false;
  }

  // Navigate based on selected user type
  void navigateBasedOnSelection() {
    if (!hasSelection()) {
      // Handle no selection case - maybe show a toast
      return;
    }

    final selected = getSelectedUserType();

    switch (selected.key) {
      case UserKey.users:
        navP(LoginScreen());
        break;
      case UserKey.suppliers:
        try {
          final authSupplierCubit =
              navigatorKey.currentContext!.read<AuthSupplierCubit>();
          authSupplierCubit.goToLoginPage();
        } catch (e) {
          print('Error accessing AuthSupplierCubit: $e');
        }
        break;
      case UserKey.guest:
        try {
          navigatorKey.currentContext!
              .read<LayoutCubit>()
              .navigateToLayoutScreen();
        } catch (e) {
          print('Error accessing LayoutCubit: $e');
        }
        break;
    }
  }
}

// Enums for user types
enum UserKey { users, suppliers, guest }

// Model for user segment
class UserType extends Equatable {
  final String title;
  final String image;
  final UserKey key;
  final bool isSelected;

  const UserType({
    required this.key,
    required this.title,
    required this.image,
    required this.isSelected,
  });

  factory UserType.empty() => const UserType(
        key: UserKey.guest,
        title: '',
        image: '',
        isSelected: false,
      );

  UserType copyWith({bool? isSelected}) {
    return UserType(
      key: key,
      title: title,
      image: image,
      isSelected: isSelected ?? this.isSelected,
    );
  }

  @override
  List<Object> get props => [title, image, key, isSelected];
}