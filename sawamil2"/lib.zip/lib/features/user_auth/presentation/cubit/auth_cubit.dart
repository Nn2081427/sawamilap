import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:jwt_decoder/jwt_decoder.dart' show JwtDecoder;
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/dialog/drop_down_dialog.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/core/helper_function/appSecureStore.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/helper_function/prefs.dart';
import 'package:swamiil/core/models/text_field_model.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/layout/Presentation/screens/layout_screen.dart';
import 'package:swamiil/features/layout/Presentation/screens/supplier_layout_screen.dart';
import 'package:swamiil/features/layout/cubit/main_layout_cubit.dart';
import 'package:swamiil/features/splash/Presentation/screens/intro_screen.dart';
import 'package:swamiil/features/splash/Presentation/screens/splash_screen.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';
import 'package:swamiil/features/user_auth/Domain/usecases/auth_use_Case.dart';
import 'package:swamiil/features/user_auth/data/repositories/auth_imply_repository.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_state.dart';
import 'package:swamiil/features/user_auth/presentation/screens/login_screen.dart';
import 'package:swamiil/features/user_auth/presentation/screens/register_screen.dart';
import 'package:swamiil/features/user_auth/presentation/screens/users_screen.dart';
import 'package:swamiil/main.dart';

import '../../../auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';

class AuthCubit extends Cubit<AuthState> {
  AuthCubit({required this.authUseCase}) : super(AuthInitial());
  AuthUseCase authUseCase;
  UserEntity? userEntity;
  bool isTermsChecked = true;
  // List<UserTypes> userTypes = [
  //   UserTypes(
  //     title: 'Users entry',
  //     image: Assets.userIcon,
  //     isSelected: false,
  //     key: UserKey.users,
  //   ),
  //   UserTypes(
  //     title: 'Suppliers\' entry',
  //     image: Assets.boxIcon,
  //     isSelected: false,
  //     key: UserKey.suppliers,
  //   ),
  //   UserTypes(
  //     title: 'Continue as a guest',
  //     image: Assets.coffeeIcon,
  //     isSelected: false,
  //     key: UserKey.guest,
  //   ),
  // ];

  Future<void> refreshToken() async {}

  Future<void> getUserInfo({bool fromSplash = true}) async {
    try {
      final result = await authUseCase.getUserProfile();
      result.fold((l) {
        talker.error(l.message ?? "Unknown error");
        if (!fromSplash) {
          showToast(l.message ?? "Unknown error");
        } else {
          AuthSecureStorage.clearAuthData();
          navigateToUsersScreen();
        }
      }, (r) {
        successLogin(userEntity: r);
      });
    } catch (e) {
      talker.info(e);

      if (!fromSplash) {
        showToast("Unknown error");
      } else {
        AuthSecureStorage.clearAuthData();
        navigateToUsersScreen();
      }
    }
  }

  void changeTermsState() {
    isTermsChecked = !isTermsChecked;
    emit(TermsChanged());
  }

  // void setUserType(String val, BuildContext context) {
  //   for (var type in userTypes) {
  //     type.isSelected = (type.title == val);
  //   }
  //   emit(UserTypeSelected());

  //   final selected = userTypes.firstWhere(
  //     (e) => e.isSelected,
  //     orElse: () => UserTypes.empty(),
  //   );

  //   switch (selected.key) {
  //     case UserKey.users:
  //       print("${UserKey.users}");
  //       break;
  //     case UserKey.suppliers:
  //       print("${UserKey.suppliers}");

  //       break;
  //     case UserKey.guest:
  //       print("${UserKey.guest}");

  //       break;
  //   }
  // }

  Future<void> userLogout() async {
    String? token = await FirebaseMessaging.instance.getToken() ?? "123";

    authUseCase.logout({
      "token": token,
    });
    // result.fold((l) {
    //   talker.info("User logout failed: ${l.message}");
    //   showToast(l.message ?? "Unknown error");
    // }, (r) {
    //
    // });
    talker.info("User logged out successfully");
    GoogleSignIn().disconnect();
    _clearUserData();
    navPARU(const OnboardingScreen());
    //  talker.info("Firebase token is null, skipping logout");
  }

  Future<void> userDeleteAccount() async {
    final result = await authUseCase.deleteAccount();

    result.fold((l) {
      showToast(l.message ?? "Unknown error");
    }, (r) {
      _clearUserData();
      navPARU(const OnboardingScreen());
    });
  }

  void _clearUserData() {
    AuthSecureStorage.clearAuthData();
    sharedPreferences.setString("user_type", "guest");
    userEntity = null;
    // for (var element in userTypes) {
    //   element.isSelected = false;
    // }
  }

  // void goToMainLayoutScreen() {
  //   final selected = userTypes.firstWhere(
  //     (e) => e.isSelected,
  //     orElse: () => UserTypes.empty(),
  //   );

  //   switch (selected.key) {
  //     case UserKey.users:
  //       navP(LoginScreen());
  //       break;
  //     case UserKey.suppliers:
  //       final authCubit = Constants.globalContext().read<AuthSupplierCubit>();
  //       authCubit.goToLoginPage();
  //       break;
  //     case UserKey.guest:
  //       Constants.globalContext().read<LayoutCubit>().navigateToLayoutScreen();
  //       break;
  //   }
  // }

  void navigateToUsersScreen() {
    sharedPreferences.setBool('intro', true);
    navPARU(UsersScreen());
  }

  void navigateToRegisterScreen() {
    initializeRegisterInputs();
    navP(RegisterScreen());
  }

  void navigateToLoginScreen() {
    navP(LoginScreen());
  }

  void navigateToSuppliersScreen() {
    navPARU(SupplierLayoutScreen());
  }

  // Form Inputs for Register
  // TextFieldModel phonefield = TextFieldModel(
  //   controller: TextEditingController(),
  //   key: "phone_number",
  //   validator: (value) => null,
  //   hint: "enter your phone number".tr(),
  //   label: "Phone Number".tr(),
  // );

  List<TextFieldModel> registerInputs = [];
  void initializeRegisterInputs() {
    if (registerInputs.isEmpty) {
      registerInputs = [
        TextFieldModel(
          width: 42.w,
          controller: TextEditingController(),
          key: "first_name",
          label: "First Name".tr(),
          hint: "enter your first name".tr(),
        ),
        TextFieldModel(
          width: 42.w,
          label: "Last Name".tr(),
          controller: TextEditingController(),
          key: "last_name",
          hint: "enter your last name".tr(),
        ),
        TextFieldModel(
            width: 42.w,
            controller: TextEditingController(),
            key: "city",
            suffix: Icon(Icons.arrow_drop_down),
            onTap: () {
              showDropDownDialog(
                      navigatorKey.currentContext!.read<CitiesCubit>())
                  .then((value) {
                updateDropDown(value.name, "city");
              });
            },
            label: "Area".tr(),
            hint: "enter your city".tr(),
            readOnly: true),
        TextFieldModel(
            width: 42.w,
            label: "city".tr(),
            suffix: Icon(Icons.arrow_drop_down),
            controller: TextEditingController(),
            onTap: () {
              showDropDownDialog(navigatorKey.currentContext!.read<AreaCubit>())
                  .then((value) {
                updateDropDown(value.name, "area_id");
              });
            },
            key: "area_id",
            hint: "enter your area".tr(),
            readOnly: true),
        TextFieldModel(
          controller: TextEditingController(),
          key: "phone",
          hint: "enter your phone number".tr(),
          label: "Phone Number".tr(),
        )
      ];
      //   emit(InputsUpdated());
    }
  }

  void updateDropDown(String value, String key) {
    registerInputs.firstWhere((e) => e.key == key).controller.text = value;
  }

  Future userRegester() async {
    loading();

    Map<String, dynamic> data = {};

    for (var input in registerInputs) {
      data[input.key!] = input.controller.text;
    }
    data["area_id"] = Constants.globalContext().read<AreaCubit>().value();
    data.remove("city");
    print(data);
    final result = await authUseCase.updateProfile(data);
    navPop();
    result.fold((l) {
      print('hamza');
      showToast(l.message ?? "Unknown error");
    }, (r) {
      if(userEntity?.token!=null){
        AuthSecureStorage.saveAccessToken(userEntity!.token!);
      }
      successLogin(userEntity: r);
    });
  }

  String loginFrom = "google";
  Future showSocialLoginUserType({required String loginFrom}) async {
    print(isTermsChecked);
    if (!isTermsChecked) {
      showToast("accept_term_text".tr());
      return;
    }
    this.loginFrom = loginFrom;
    print(loginFrom);
    if (loginFrom == 'apple') {
      appleLogin();
    } else {
      googleLogin();
    }
  }

  final GoogleSignIn _googleSignIn = GoogleSignIn();
  Future socialLoginButton(
      {bool fromSplash = false,
      bool fromJWT = false,
      required String loginFrom,
      String? appleIdentifier,
      String? firstName,
      String? lastName,
      String? email}) async {
    String token = await FirebaseMessaging.instance.getToken() ?? "123";
    Map<String, dynamic> data = {};
    if (loginFrom == 'apple') {
      // data['firstName'] = firstName;
      // data['lastName'] = lastName;
      if (email != null) {
        data['email'] = email;
      }
      data['apple_identifier'] = appleIdentifier;
    } else {
      data['email'] = _googleSignIn.currentUser!.email;
      data['image'] = _googleSignIn.currentUser!.photoUrl;
      // if (!fromSplash) {
      //   // data['firstName'] = _googleSignIn.currentUser!.displayName;
      //   // data['lastName'] = _googleSignIn.currentUser!.displayName;

      // } else {
      //   data['email'] = sharedPreferences.getString("email")!;
      // }
    }
    data['login_from'] = loginFrom;
    data['token'] = token;
    if (!fromSplash && !fromJWT) loading();
    Either<DioException, UserEntity> login =
        await AuthUseCase(authContractRepository: AuthImplyRepository())
            .loginSocial(data);
    navPop();
    login.fold((l) {
      print(l.message);
      navPop();
    }, (r) async {
      successLogin(userEntity: r);
    });
  }

  void successLogin({required UserEntity userEntity}) {
    this.userEntity = userEntity;

    if (userEntity.token != null) {
      ApiHandel.getInstance.updateHeader(userEntity.token!);
    }
    if (userEntity.firstName == null) {
      print(userEntity);
      navigateToRegisterScreen();
      return;
    } else {
      if (userEntity.token != null) {
        talker.info("user logged in successfully" + userEntity.token!);

        AuthSecureStorage.saveAccessToken(userEntity.token!);
      }
    }
    sharedPreferences.setString("user_type", "user");

    Constants.globalContext().read<LayoutCubit>().navigateToLayoutScreen();
  }

  void googleLogin() async {
    try {
      await _googleSignIn.signIn();
      if (_googleSignIn.currentUser != null) {
        socialLoginButton(loginFrom: 'google');
      }
    } catch (error) {
      print(error);
      // errorSnackBar(title: LanguageProvider.translate("validation", 'register_first'));
    }
  }

  void appleLogin() async {
    try {
      print('hamza');
      String redirectUrl = "${Constants.domainApi}callback_sign_in_with_apple";
      print('hamza1');
      final credential = await SignInWithApple.getAppleIDCredential(
          scopes: [
            AppleIDAuthorizationScopes.email,
            AppleIDAuthorizationScopes.fullName,
          ],
          webAuthenticationOptions: WebAuthenticationOptions(
              clientId: "com.zeroonez.sawamil.user.apple-login",
              redirectUri: Uri.parse(
                redirectUrl,
              )));
      print('hamza2');
      String yourToken = credential.identityToken!;
      Map<String, dynamic> decodedToken =
          JwtDecoder.decode(yourToken); // email, sub
      String email = decodedToken['email'];
      String appleIdentifier = decodedToken['sub'];
      String? firstName;
      String? lastName;
      print('hamza3');
      if (credential.givenName != null) {
        firstName = '${credential.givenName}';
        lastName = '${credential.familyName}';
      } else {
        firstName = decodedToken['email'].toString().split('@').first;
      }
      print('hamza');
      socialLoginButton(
          loginFrom: 'apple',
          appleIdentifier: appleIdentifier,
          firstName: firstName,
          lastName: lastName,
          email: email);
    } catch (error) {
      print(error);
      // errorSnackBar(title: LanguageProvider.translate("validation", 'register_first'));
    }
  }
}

// Enums for user types
// enum UserKey { users, suppliers, guest }

// // Model for user segment
// class UserTypes {
//   String title;
//   String image;
//   UserKey key;
//   bool isSelected;

//   UserTypes({
//     required this.key,
//     required this.title,
//     required this.image,
//     required this.isSelected,
//   });

//   factory UserTypes.empty() => UserTypes(
//         key: UserKey.guest,
//         title: '',
//         image: '',
//         isSelected: false,
//       );
// }
