abstract class AuthState {}

class AuthInitial extends AuthState {}

class NavigteToMainLayoutState extends AuthState {}

class UserTypeSelected extends AuthState {}

class TermsChanged extends AuthState {}

class AuthError extends AuthState {
  final String message;

  AuthError(this.message);
}

class InputUpdated extends AuthState {}

class AuthLoading extends AuthState {}

class AuthSuccess extends AuthState {
  
}
class AuthRegistrationNeeded extends AuthState {}