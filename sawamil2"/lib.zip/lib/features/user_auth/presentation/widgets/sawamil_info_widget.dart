import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/auth_supplier/presentation/screens/supplier_register.dart';
import 'package:swamiil/features/orders/Presentation/widgets/order_details_dialog.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/main.dart';

import '../../../auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';

class SawamilInfoWidget extends StatelessWidget {
  const SawamilInfoWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        InkWell(
          onTap: () {
            context.read<AuthSupplierCubit>().goRegisterPage();
          },
          child: RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              text: "Membership request We are happy to register a number of"
                  .tr(),
              style: Fonts.text16Black.copyWith(fontWeight: FontWeight.bold),
              children: [
                TextSpan(
                  text: " here".tr(),
                  style:
                      Fonts.text16Orange.copyWith(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          height: 5.h,
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LabeledRichText(
              labelKey: "Connect :".tr(),
              value: navigatorKey.currentContext!
                  .read<SettingsCubit>()
                  .settingsEntity!
                  .email,
              labelStyle: Fonts.text16Black.copyWith(
                fontWeight: FontWeight.bold,
              ),
              valueStyle: Fonts.text16Black,
            ),
            SizedBox(
              height: 1.h,
            ),
            LabeledRichText(
              labelKey: "Support :".tr(),
              value: navigatorKey.currentContext!
                  .read<SettingsCubit>()
                  .settingsEntity!
                  .supportEmail,
              labelStyle: Fonts.text16Black.copyWith(
                fontWeight: FontWeight.bold,
              ),
              valueStyle: Fonts.text16Black,
            ),
          ],
        ),
      ],
    );
  }
}
