import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/check_icon_widget.dart';
import 'package:swamiil/core/widgets/checkbox_widget.dart';
import 'package:swamiil/core/widgets/web_view.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_state.dart';

class PrivacyWidget extends StatelessWidget {
  const PrivacyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        BlocBuilder<AuthCubit, AuthState>(
          builder: (context, state) {
            return CheckBoxWidget(
                check: context.read<AuthCubit>().isTermsChecked,
                onChange: (bool value) =>
                    context.read<AuthCubit>().changeTermsState());
          },
        ),
        SizedBox(
          width: 10,
        ),
        Expanded(
          child: RichText(
              text: TextSpan(
            children: [
              TextSpan(
                text: "${"I_confirm_that_I_have_read_and_agree_to_the".tr()} ",
                style: Fonts.text16Black,
              ),
              TextSpan(
                text: "Privacy_Policy".tr(),
                style: Fonts.text16Black.copyWith(color: AppColors.mainColor),
                recognizer: TapGestureRecognizer()
                  ..onTap = () {
                    navP(WebViewPage(
                        title: "Privacy_Policy".tr(),
                        link: context
                            .read<SettingsCubit>()
                            .settingsEntity!
                            .privacyLink));
                  },
              ),
              TextSpan(
                text: " ${"and".tr()} ",
                style: Fonts.text16Black,
                recognizer: TapGestureRecognizer()..onTap = () {},
              ),
              TextSpan(
                text: "Terms_and_Conditions".tr(),
                style: Fonts.text16Black.copyWith(color: AppColors.mainColor),
                recognizer: TapGestureRecognizer()
                  ..onTap = () {
                    navP(WebViewPage(
                        title: "Terms_and_Conditions".tr(),
                        link: context
                            .read<SettingsCubit>()
                            .settingsEntity!
                            .termsLink));
                  },
              )
            ],
          )),
        ),
      ],
    );
  }
}
