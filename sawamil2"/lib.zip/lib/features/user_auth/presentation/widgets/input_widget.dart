import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_drop_button.dart';
import 'package:swamiil/core/widgets/default_text_form_field.dart';

class InputWidget extends StatelessWidget {
  const InputWidget({
    super.key,
    required this.input,
    required this.hintText,
    required this.controller,
    this.isDrop,
  });
  final String input;
  final String hintText;
  final TextEditingController controller;
  final bool? isDrop;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          input,
          style: Fonts.textBlack18,
        ),
        SizedBox(
          height: 10,
        ),
        DefaultTextFormField(hintText: hintText, controller: controller)
      ],
    );
  }
}

class InputWidgetWithDropButton extends StatelessWidget {
  const InputWidgetWithDropButton({
    super.key,
    required this.input,
    required this.text,
  });
  final String input;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          input,
          style: Fonts.textBlack18,
        ),
        SizedBox(
          height: 10,
        ),
        CustomDropDownButton(
          items: [],
          hint: text,
        )
      ],
    );
  }
}
