import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/checkbox_widget.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/cubit/user_type_cubit.dart';

class UserSegmentContainer extends StatelessWidget {
  const UserSegmentContainer({super.key, required this.data,required this.onTap});
  final UserType data;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 1.5.h),
        width: double.infinity,
        decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                  blurRadius: 18,
                  blurStyle: BlurStyle.outer,
                  color: data.isSelected
                      ? AppColors.mainColor.withOpacity(0.4)
                      : Colors.black12)
            ],
            color: data.isSelected ? AppColors.opcityOrangeColor : Colors.white,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
                color: data.isSelected ? AppColors.mainColor : Colors.white,
                width: 1)),
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CheckBoxWidget(
                    check: data.isSelected, size: 15, onChange: (val) {}),
                Spacer(),
                SvgPicture.asset(
                  data.image,
                  width: 48,
                  height: 48,
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              data.title.tr(),
              style: Fonts.text20Orange
                  .copyWith(color: Colors.black, fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: 5,
            )
          ],
        ),
      ),
    );
  }
}
