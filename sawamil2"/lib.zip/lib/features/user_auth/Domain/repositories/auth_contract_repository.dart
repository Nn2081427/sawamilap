import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';

abstract class AuthContractRepository {
  Future<Either<DioException, UserEntity>> loginSocial(Map<String, dynamic> data);
  Future<Either<DioException, UserEntity>> getUserProfile();
  Future<Either<DioException, UserEntity>> updateProfile(
      Map<String, dynamic> data);
  Future<Either<DioException, bool>> logout(Map<String, dynamic> data);
  Future<Either<DioException, bool>> deleteAccount();
  Future<Either<DioException, bool>> refreshToken(Map<String, dynamic> data);
}
