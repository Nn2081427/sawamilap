import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/user_auth/Domain/repositories/auth_contract_repository.dart';

class DeleteAccountUseCase {
  final AuthContractRepository authContractRepository;

  DeleteAccountUseCase({required this.authContractRepository});

  Future<Either<DioException, bool>> call() async {
    return await authContractRepository.deleteAccount();
  }
}
