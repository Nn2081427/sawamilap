import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';
import 'package:swamiil/features/user_auth/Domain/repositories/auth_contract_repository.dart';

class UpdateUserProfileUseCase  {
  final AuthContractRepository authContractRepository;
  UpdateUserProfileUseCase({required this.authContractRepository});
  Future<Either<DioException, UserEntity>> call(Map<String, dynamic> data) async {
    return await authContractRepository.updateProfile(data);
  }
}