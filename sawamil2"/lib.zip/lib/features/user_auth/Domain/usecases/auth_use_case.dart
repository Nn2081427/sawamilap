import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';
import 'package:swamiil/features/user_auth/Domain/repositories/auth_contract_repository.dart';

class AuthUseCase {
  final AuthContractRepository authContractRepository;

  AuthUseCase({required this.authContractRepository});

  Future<Either<DioException, bool>> deleteAccount() async {
    return await authContractRepository.deleteAccount();
  }

  Future<Either<DioException, UserEntity>> getUserProfile() async {
    return await authContractRepository.getUserProfile();
  }

  Future<Either<DioException, bool>> refreshToken(
      {required Map<String, dynamic> data}) async {
    return await authContractRepository.refreshToken(data);
  }

  Future<Either<DioException, bool>> logout(Map<String, dynamic> data) async {
    return await authContractRepository.logout(data);
  }

  Future<Either<DioException, UserEntity>> loginSocial(
      Map<String, dynamic> data) async {
    return await authContractRepository.loginSocial(data);
  }

  Future<Either<DioException, UserEntity>> updateProfile(
      Map<String, dynamic> data) async {
    return await authContractRepository.updateProfile(data);
  }
}
