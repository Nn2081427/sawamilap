import 'package:swamiil/features/city/domain/entities/area_entity.dart';
import 'package:swamiil/features/city/domain/entities/city_entity.dart';

class UserEntity {
  final int id;
  final String? image;
  final CityEntity? city;
  final AreaEntity? area;
  final String? firstName;
  final String? lastName;
  final String? phone;
  final String? email;
  final String? token;

  UserEntity({
    required this.id,
    required this.image,
    required this.city,
    required this.area,
    required this.firstName,
    required this.lastName,
    required this.phone,
    required this.email,
    required this.token,
  });
}
