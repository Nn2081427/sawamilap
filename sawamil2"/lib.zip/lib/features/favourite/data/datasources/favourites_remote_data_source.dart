import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';

import '../../../orders/data/models/order_model.dart';

class FavouritesRemoteDataSource {
  // change favourite
  static Future<Either<DioException, bool>> changeFavourite(
      {required int orderid}) async {
    var response = await ApiHandel.getInstance
        .post('supplier/change_favorite', {'order_id': orderid});
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }

  // get all favourites Orders
  static Future<Either<DioException, List<OrderModel>>>
      getAllFavouritesOrders() async {
    var response =
        await ApiHandel.getInstance.get('supplier/get_favorites_orders');
    List<OrderModel> data = [];
    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        data.add(OrderModel.fromJson(i));
      }
      return Right(data);
    });
  }
}
