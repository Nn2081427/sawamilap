import 'package:dartz/dartz.dart';
import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/favourite/data/datasources/favourites_remote_data_source.dart';
import 'package:swamiil/features/favourite/domain/repositories/favourites_contract_repo.dart';

import '../../../orders/domain/entity/order_entity.dart';

class FavouritesImplyRepo implements FavouritesContractRepo {
  @override
  Future<Either<DioException, bool>> changeFavourite(
      {required int orderid}) async {
    return await FavouritesRemoteDataSource.changeFavourite(orderid: orderid);
  }

  @override
  Future<Either<DioException, List<OrderEntity>>>
      getAllFavouritesOrders() async {
    return await FavouritesRemoteDataSource.getAllFavouritesOrders();
  }
}
