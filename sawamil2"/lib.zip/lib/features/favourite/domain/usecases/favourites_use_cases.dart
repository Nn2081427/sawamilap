import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/favourite/domain/repositories/favourites_contract_repo.dart';

import '../../../orders/domain/entity/order_entity.dart';

class FavouritesUseCases {
  final FavouritesContractRepo repo;

  FavouritesUseCases({required this.repo});
  // change favourite use case
  Future<Either<DioException, bool>> changeFacourite(
      {required int orderid}) async {
    return await repo.changeFavourite(orderid: orderid);
  }

  // get all favourite orders use case
  Future<Either<DioException, List<OrderEntity>>>
      getAllFavouritesOrders() async {
    return await repo.getAllFavouritesOrders();
  }
}
