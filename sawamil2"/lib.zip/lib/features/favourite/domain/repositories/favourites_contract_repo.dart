import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';

import '../../../orders/domain/entity/order_entity.dart';

abstract class FavouritesContractRepo {
  Future<Either<DioException, bool>> changeFavourite({required int orderid});

  Future<Either<DioException, List<OrderEntity>>> getAllFavouritesOrders();
}
