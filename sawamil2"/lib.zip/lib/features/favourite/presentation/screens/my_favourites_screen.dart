import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/favourite/domain/usecases/favourites_use_cases.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_cubit.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_state.dart';
import 'package:swamiil/features/favourite/presentation/widgets/FavouriteSupplierScreenBodyWidget.dart';

class FavouritesScreenSupplier extends StatelessWidget {
  const FavouritesScreenSupplier({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          FavouritesCubit(useCases: getIt.get<FavouritesUseCases>())
            ..getAllFavouritesOrders(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBarWidget(title: "favourite".tr()),
        body: BlocBuilder<FavouritesCubit, FavouritesState>(
          builder: (context, state) {
            var cubit = context.read<FavouritesCubit>();
            if (state is FavouritesLoading) {
              return ShimmerWidget(
                width: double.infinity,
                height: 250,
                numOfShimmer: 2,
                radius: 15,
              );
            } else if (state is FavouritesLoaded) {
              final favorites = state.data;
              if (favorites.isEmpty) {
                return Center(
                    child: Text(
                  "no favourites found".tr(),
                  style: Fonts.text14Black,
                ));
              }
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Column(
                    children: List.generate(
                      favorites.length,
                      (index) => FavouriteSupplierScreenBodyWidget(
                        time: convertDateToStringDMMMY(
                            favorites[index].createdAt),
                        name: favorites[index].user?.firstName ?? "",
                        description: favorites[index].notes ?? "",
                        brandName: favorites[index].brand?.name ?? "",
                        city: favorites[index].user?.city?.name ?? "",
                        area: favorites[index].user?.area?.name ?? "",
                        title: favorites[index].title ?? "",
                        images: favorites[index]
                            .images
                            ?.map((e) => e.image ?? '')
                            .toList(),

                        hidebutton: () => cubit.changeFavourite(
                          orderId: favorites[index].id,
                        ), // adjust as needed
                      ),
                    ),
                  ),
                ),
              );
            } else if (state is FavouritesError) {
              return Center(child: Text(state.message));
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
