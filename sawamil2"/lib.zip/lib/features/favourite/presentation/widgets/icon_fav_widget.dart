import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_cubit.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_state.dart';

class FavouriteIcon extends StatefulWidget {
  final int orderId;
  final bool initialIsFav;

  const FavouriteIcon({
    super.key,
    required this.orderId,
    required this.initialIsFav,
  });

  @override
  State<FavouriteIcon> createState() => _FavouriteIconState();
}

class _FavouriteIconState extends State<FavouriteIcon> {
  late bool isFav;

  @override
  void initState() {
    super.initState();
    isFav = widget.initialIsFav;
  }

  void _toggleFavourite(BuildContext context) async {
    final cubit = context.read<FavouritesCubit>();
    final result = await cubit.changeFavourite(orderId: widget.orderId);
    setState(() {
      isFav = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(
        Icons.favorite,
        color: isFav ? Colors.red : Colors.grey,
      ),
      onPressed: () => _toggleFavourite(context),
    );
  }
}
