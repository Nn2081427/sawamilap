import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/CustomOrderCardWidget.dart';

class FavouriteSupplierScreenBodyWidget extends StatelessWidget {
  const FavouriteSupplierScreenBodyWidget({
    required this.name,
    required this.description,
    required this.brandName,
    required this.city,
    required this.area,
    required this.images,
    required this.time,
    required this.title,
    super.key,
    this.hidebutton,
    this.offerbutton,
  });
  final String name;
  final String description;
  final String brandName;
  final String city;
  final String area;
  final List<String>? images;
  final String time;
  final String title;
  final void Function()? hidebutton;
  final void Function()? offerbutton;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: CustomOrderCardWidget(
        time: time,
        name: name,
        description: description,
        brandName: brandName,
        title: title,
        city: city,
        area: area,
        images: images,
        isFromMyOffer: false,
        isFromFavorite: true,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: CustomButton(
                onTap: hidebutton,
                height: 40,
                borderRadius: BorderRadius.circular(8),
                backgroundColor: AppColors.lightRed,
                child: Center(
                  child: Text(
                    "remove".tr(),
                    style: Fonts.textWhite18
                        .copyWith(color: Colors.black, fontSize: 14),
                  ),
                ),
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: CustomButton(
                onTap: offerbutton,
                height: 40,
                borderRadius: BorderRadius.circular(8),
                backgroundColor: AppColors.mainColor,
                child: Center(
                  child: Text(
                    "submit offer".tr(),
                    style: Fonts.textWhite18.copyWith(fontSize: 14),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
