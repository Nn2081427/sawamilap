
import '../../../orders/domain/entity/order_entity.dart';

abstract class FavouritesState {}

class FavouritesInitial extends FavouritesState {}

class FavouritesLoading extends FavouritesState {}

class FavouritesLoaded extends FavouritesState {
  final List<OrderEntity> data;
  FavouritesLoaded( {required this.data});
}

class FavouritesError extends FavouritesState {
  final String message;
  FavouritesError({required this.message});
}

class FavouriteChanged extends FavouritesState {
  final bool isFavourite;

  FavouriteChanged(this.isFavourite);

  @override
  String toString() => 'FavouriteChanged { isFavourite: $isFavourite }';
}
