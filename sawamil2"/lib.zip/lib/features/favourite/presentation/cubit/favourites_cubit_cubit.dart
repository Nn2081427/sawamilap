import 'package:bloc/bloc.dart';
import 'package:swamiil/features/favourite/domain/usecases/favourites_use_cases.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_state.dart';

class FavouritesCubit extends Cubit<FavouritesState> {
  final FavouritesUseCases useCases;

  FavouritesCubit({required this.useCases}) : super(FavouritesInitial());

  // Get all favourite orders
  Future<void> getAllFavouritesOrders() async {
    emit(FavouritesLoading());
    final result = await useCases.getAllFavouritesOrders();
    result.fold(
      (failure) => emit(FavouritesError(message: '${failure.message}')),
      (orders) => emit(FavouritesLoaded(data: orders)),
    );
  }

  // Change favourite status
  Future<bool> changeFavourite({required int orderId}) async {
    final result = await useCases.changeFacourite(orderid: orderId);
    return result.fold(
      (failure) {
        emit(FavouritesError(message: '${failure.message}'));
        return false; // Default to not favorited on error
      },
      (isFav) {
        emit(FavouriteChanged(isFav));
        return isFav;
      },
    );
  }
}
