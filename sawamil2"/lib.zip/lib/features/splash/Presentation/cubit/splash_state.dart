abstract class SplashState {}

final class SplashInitial extends SplashState {}

final class SplashLoading extends SplashState {}

class SplashForceUpdate extends SplashState {
  final bool mustUpdate;
  SplashForceUpdate(this.mustUpdate);
}
