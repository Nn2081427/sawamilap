import 'dart:async';
import 'dart:math';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/helper_function/appSecureStore.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/screens/users_screen.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/features/splash/Presentation/cubit/splash_state.dart';
import 'package:swamiil/features/splash/Presentation/screens/intro_screen.dart';
import 'package:swamiil/main.dart';

import '../../../../core/helper_function/prefs.dart';
import '../../../suppliers_profile/Presentation/cubits/cubit/supplier_profile_cubit.dart';

class SplashCubit extends Cubit<SplashState> {
  SplashCubit(
      this.citiesCubit, this.authCubit, this.brandsCubit, this.settingsCubit)
      : super(SplashInitial());

  // add cubits for settings , cities, brands,
  final AuthCubit authCubit;
  final CitiesCubit citiesCubit;
  final BrandsCubit brandsCubit;
  final SettingsCubit settingsCubit;

  void navigateToIntroScreen() {
    // After 3 seconds, navigate to the IntroScreen
    Timer(const Duration(seconds: 3), () {
      navigatorKey.currentState?.pushReplacement(
        MaterialPageRoute(builder: (_) => OnboardingScreen()),
      );
    });
  }

  /// navigate from intro screen to users screen
  void navigateToUsersScreen() {
    navP(UsersScreen());
  }

  Future<void> startApp() async {
    emit(SplashLoading());

    await Future.wait([
      citiesCubit.getCities(),
      brandsCubit.getAllBrands(),
      settingsCubit.getSettings(),
    ]);

    final state = settingsCubit.state;
    if (state is SettingsLoaded) {
      final settings = state.settingsEntity;
      final info = await PackageInfo.fromPlatform();
      final currentBuild = int.parse(info.buildNumber);

      if (currentBuild < settings.userVersion) {
        emit(SplashForceUpdate(settings.mustUpdateUser));
        if (settings.mustUpdateUser) return; // Force update required
      }
    }

    final String? token = await AuthSecureStorage.getAccessToken();
    talker.info('User logged in successfully' + token.toString());

    if (token != null) {
      final String? userType = sharedPreferences.getString("user_type");
      if (userType == "user") {
        authCubit.getUserInfo();
      }else{
        Constants.globalContext().read<SupplierProfileCubit>().getSupplierProfile(fromSplash: true);
      }

      // emit(SplashNavigateToHome());
    } else {

      navPARU(OnboardingScreen());
      // emit(SplashNavigateToLogin());
    }
  }
}
