import 'dart:async';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/features/splash/Presentation/cubit/splash_cubit.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Trigger navigation after splash screen
    context.read<SplashCubit>().startApp();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion(
      value: barColor(),
      child: Scaffold(
        backgroundColor: AppColors.mainColor,
        body: Stack(
          children: [
            Center(
              child: Column(
                children: [
                  SizedBox(
                    height: 35.h,
                  ),
                  Image.asset(Assets.logoSplash, width: 135, height: 135),
                  Text(
                    "Sawamil".tr(),
                    style: Fonts.textSplash25,
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Image.asset(
                Assets.dashedSplash,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
