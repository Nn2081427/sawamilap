import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentIndex = 0;

  final List<OnboardingModel> _onboardingData = [
    OnboardingModel(
      title: "كل صامولة ولها مكانها",
      description: "من أكبر ممعة للصفر صامولة، مواصل بحدد لك مكانها",
      image: Assets.onboarding1,
      buttonText: "تحضى",
    ),
    OnboardingModel(
      title: "لا تتردد ولا تحتار، وقارن صح بين الأسعار",
      description:
          "استقبل عروض من تشاليم مختلفين، وقارن بين السعر والجودة بدون ما تنتقل أو تحتار",
      image: Assets.onboarding2,
      buttonText: "تخطي",
    ),
    OnboardingModel(
      title: "جاهز نرسل أول طلب؟",
      description: "علمنا طلبك وذلك مرتاح، وخلي الباقي على صواميل",
      image: Assets.onboarding3,
      buttonText: "إبدأ",
    ),
  ];

  void _nextPage() {
    if (_currentIndex < _onboardingData.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _navigateToAuth();
    }
  }

  void _navigateToAuth() {
    getIt.get<AuthCubit>().navigateToUsersScreen();
  }

  void _skipOnboarding() {
    _navigateToAuth();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: PageView.builder(
          controller: _pageController,
          onPageChanged: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          itemCount: _onboardingData.length,
          itemBuilder: (context, index) {
            return buildOnboardingPage(_onboardingData[index]);
          },
        ),
      ),
    );
  }

  Widget buildOnboardingPage(OnboardingModel data) {
    bool isLastPage = _currentIndex == _onboardingData.length - 1;

    return Column(
      children: [
        Expanded(
          flex: 5,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Hero(
              tag: 'onboarding_image_$_currentIndex',
              child: Image.asset(
                data.image,
                fit: BoxFit.contain,
              ),
            ),
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          padding: EdgeInsets.only(left: 20, right: 20, top: 15, bottom: 2.h),
          decoration: BoxDecoration(
            color: AppColors.mainColor,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _onboardingData.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        height: 12,
                        width: 12,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _currentIndex == index
                              ? Colors.white
                              : Colors.white.withOpacity(0.5),
                          //borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 3.h),
                  // Title
                  SizedBox(
                    width: 80.w,
                    child: Text(
                      data.title,
                      style: Fonts.textWhite18.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 25.sp,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),

                  SizedBox(height: 2.h),

                  // Description
                  SizedBox(
                    width: 60.w,
                    child: Text(
                      data.description,
                      style: Fonts.textWhite18.copyWith(
                        fontSize: 18.sp,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  SizedBox(height: 4.h),
                ],
              ),

              // Bottom section with buttons
              if (isLastPage) ...[
                SizedBox(height: 4.h),
                CustomButton(
                  buttonText: "ابدأ",
                  backgroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  margin: EdgeInsets.symmetric(horizontal: 12.w),
                  width: double.infinity,
                  textStyle: Fonts.textWhite18.copyWith(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                    color: AppColors.mainColor,
                  ),
                  onTap: _navigateToAuth,
                  borderRadius: BorderRadius.circular(60),
                )
              ] else
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: _nextPage,
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          width: 14.w,
                          height: 8.h,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 4,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 7.0),
                              child: Icon(
                                Icons.arrow_back_ios,
                                color: AppColors.mainColor,
                                size: 21.sp,
                              ),
                            ),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: _skipOnboarding,
                        child: Text(
                          "تخطي".tr(),
                          style: Fonts.textWhite18.copyWith(
                            fontSize: 17.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class OnboardingModel {
  final String title;
  final String description;
  final String image;
  final String buttonText;

  OnboardingModel({
    required this.title,
    required this.description,
    required this.image,
    required this.buttonText,
  });
}
