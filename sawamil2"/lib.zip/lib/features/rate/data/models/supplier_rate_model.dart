
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/user_auth/Data/models/user_model.dart';

import '../../domain/entities/supplier_rate_entity.dart';

class SupplierRateModel extends SupplierRateEntity {
  SupplierRateModel({required super.id, required super.rate,
    required super.comment, required super.createdAt, required super.user});


  factory SupplierRateModel.fromJson(Map<String, dynamic> json) {
    UserModel userModel = UserModel.fromJson(json['user']);
    return SupplierRateModel(
      id: json['id'],
      rate: convertDataToNum(json['rate']),
      comment: json['comment'],
      createdAt: DateTime.parse(json['created_at']),
      user: userModel,
    );
  }

}