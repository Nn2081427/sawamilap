import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/rate/data/data_source/rate_remote_data_source.dart';
import 'package:swamiil/features/rate/domain/repos/rate_repo.dart';

import '../models/supplier_rate_model.dart';

class RateRepoImpl extends RateRepo {
  final RateRemoteDataSource rateRemoteDataSource;

  RateRepoImpl({required this.rateRemoteDataSource});
  @override
  Future<Either<DioException, void>> rateSupplier(
      {required int orderId,
      required double rate,
      required String comment}) async {
    return await rateRemoteDataSource.rateSupplier(
        orderId: orderId, rate: rate, comment: comment);
  }

  @override
  Future<Either<DioException, List<SupplierRateModel>>> getSupplierAllRates({required int supplierId, required int pageKey}) async{
    return await rateRemoteDataSource.getSupplierAllRates(supplierId: supplierId, pageKey: pageKey );
  }


}
