import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';

import '../../../../main.dart';
import '../models/supplier_rate_model.dart';

class RateRemoteDataSource {
  final ApiHandel apiHandel;

  RateRemoteDataSource({required this.apiHandel});
  Future<Either<DioException, void>> rateSupplier({
    required int orderId,
    required double rate,
    required String comment,
  }) async {
    return await apiHandel.post("user/create_rate",
        {"order_id": orderId, "rate": rate, "comment": comment});
  }

  Future<Either<DioException, List<SupplierRateModel>>> getSupplierAllRates(
      {required int supplierId, required int pageKey}) async {

    final response = await apiHandel.post('user/get_supplier_rates',
        {"supplier_id": supplierId, "page": pageKey});

    talker.info("Supplier rates response: ${response.toString()}");

    return response.fold(
          (l) => Left(l),
          (r) {
            List<SupplierRateModel> rates = [];
        talker.info("Supplier rates loaded successfully: ${r.data['data']}");

        if (r.data['data'] != null) {
          for (var rate in r.data['data']) {
            rates.add(SupplierRateModel.fromJson(rate));
          }
        }

        return Right(rates);
      },
    );
  }
}
