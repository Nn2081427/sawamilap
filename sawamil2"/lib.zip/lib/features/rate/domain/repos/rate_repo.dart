import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';

import '../entities/supplier_rate_entity.dart';


abstract class RateRepo {
  Future<Either<DioException, void>> rateSupplier(
      {required int orderId, required double rate, required String comment});
  Future<Either<DioException, List<SupplierRateEntity>>> getSupplierAllRates({required int supplierId, required int pageKey});

}
