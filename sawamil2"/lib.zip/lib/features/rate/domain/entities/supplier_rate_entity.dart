import 'package:swamiil/features/user_auth/Domain/entities/user_entity.dart';

class SupplierRateEntity {
  final int id;
  final num rate;
  final String? comment;
  final DateTime? createdAt;
  final UserEntity? user;

  SupplierRateEntity({
    required this.id,
    required this.rate,
    required this.comment,
    required this.createdAt,
    required this.user,
  });
}