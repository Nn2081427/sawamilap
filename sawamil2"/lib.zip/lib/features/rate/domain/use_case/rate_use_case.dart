import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/rate/domain/entities/supplier_rate_entity.dart';
import 'package:swamiil/features/rate/domain/repos/rate_repo.dart';

class RateUseCase {
  final RateRepo rateRepo;

  RateUseCase({required this.rateRepo});

  Future<Either<DioException, void>> rateSupplier(
          {required int orderId,
          required double rate,
          required String comment}) async =>
      await rateRepo.rateSupplier(
          orderId: orderId, rate: rate, comment: comment);

  Future<Either<DioException, List<SupplierRateEntity>>> getSupplierAllRates({required int supplierId, required int pageKey}) async{
    return await rateRepo.getSupplierAllRates(supplierId: supplierId, pageKey: pageKey );
  }
}
