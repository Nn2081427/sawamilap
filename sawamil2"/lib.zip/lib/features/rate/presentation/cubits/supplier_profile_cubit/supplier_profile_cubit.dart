import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/features/auth_supplier/domain/repositries/supplier_auth_repo.dart';
import 'package:swamiil/features/auth_supplier/domain/use_cases/supplier_auth_use_case.dart';
import 'package:swamiil/main.dart';

import '../../../../auth_supplier/domain/entities/supplier_entity.dart';
import '../../../domain/entities/supplier_rate_entity.dart';
import '../../../domain/use_case/rate_use_case.dart';

part 'supplier_profile_state.dart';

class SupplierPublicProfileCubit extends Cubit<SupplierProfileState> {
  SupplierPublicProfileCubit({required this.supplierProfileUseCase})
      : super(SupplierProfileInitial()) {
    _initPagingController();
  }

  final RateUseCase supplierProfileUseCase;

  late PagingController<int, SupplierRateEntity> pagingController;
  int supplierId = 0;

  void _initPagingController() {
    pagingController = PagingController(firstPageKey: 1);

    pagingController.addPageRequestListener((pageKey) {
      loadSupplierRates(pageKey);
    });

    talker.info("PagingController initialized");
  }

  Future<void> getSupplierProfile({required int supplierId}) async {
    talker.info("Supplier profile refreshed" + supplierId.toString());
    if (this.supplierId != supplierId) {
      _resetPagingController();
    }

    this.supplierId = supplierId;
    emit(SupplierProfileLoading());
    Map<String, dynamic> data = {};
    data['supplier_id'] = supplierId;
    final result =
        await SupplierAuthUseCase(supplierRepo: getIt.get<SupplierRepo>())
            .getSupplierPublicProfileById(data);

    result.fold(
      (error) {
        emit(SupplierProfileError(error.message ?? "Unknown error"));
      },
      (supplier) {
        emit(SupplierProfileLoaded(supplier: supplier));
      },
    );
  }

  void _resetPagingController() {
    pagingController.dispose();
    _initPagingController();

    talker.info("PagingController reset");
  }

  Future<void> loadSupplierRates(int pageKey) async {
    try {
      talker.info("Loading supplier rates for page: $pageKey");

      if (pageKey == 1) {
        emit(SupplierRatesLoading());
      }

      final result = await supplierProfileUseCase.getSupplierAllRates(
        supplierId: supplierId,
        pageKey: pageKey,
      );

      if (isClosed) return;

      result.fold(
        (error) {
          pagingController.error = error.message ?? "Unknown error";
          emit(SupplierRatesError(error.message ?? "Unknown error"));
          showToast(error.message ?? "Unknown error");
        },
        (ratesResponse) {
          final isLastPage = ratesResponse.length < 10;

          if (isLastPage) {
            pagingController.appendLastPage(ratesResponse);
          } else {
            pagingController.appendPage(ratesResponse, pageKey + 1);
          }

          emit(SupplierRatesLoaded(supplierRate: ratesResponse));
        },
      );
    } catch (e) {
      if (!isClosed) {
        pagingController.error = e;
        emit(SupplierRatesError(e.toString()));
      }
    }
  }

  Future<void> getSupplierAllRates() async {
    _resetPagingController();

    talker.info("Supplier rates refreshed");
  }

  @override
  Future<void> close() {
    pagingController.dispose();
    return super.close();
  }
}
