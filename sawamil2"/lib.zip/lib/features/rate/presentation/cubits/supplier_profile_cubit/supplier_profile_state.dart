part of 'supplier_profile_cubit.dart';

sealed class SupplierProfileState extends Equatable {
  const SupplierProfileState();

  @override
  List<Object> get props => [];
}

final class SupplierProfileInitial extends SupplierProfileState {}

final class SupplierProfileLoading extends SupplierProfileState {}

final class SupplierProfileLoaded extends SupplierProfileState {
  final SupplierEntity supplier;

  const SupplierProfileLoaded({required this.supplier});

  @override
  List<Object> get props => [supplier];
}

final class SupplierProfileError extends SupplierProfileState {
  final String message;

  const SupplierProfileError(this.message);

  @override
  List<Object> get props => [message];
}

final class SupplierRatesLoading extends SupplierProfileState {}

final class SupplierRatesLoaded extends SupplierProfileState {
  final  List<SupplierRateEntity> supplierRate;
  const SupplierRatesLoaded({required this.supplierRate});
  @override
  List<Object> get props => [supplierRate];
}

final class SupplierRatesError extends SupplierProfileState {
  final String message;
  const SupplierRatesError(this.message);
  @override
  List<Object> get props => [message];
}
