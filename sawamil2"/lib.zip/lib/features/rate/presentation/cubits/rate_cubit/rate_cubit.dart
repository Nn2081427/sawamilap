import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/features/orders/Presentation/cubits/finished_order_cubit/finished_order_cubit.dart';
import 'package:swamiil/features/rate/domain/use_case/rate_use_case.dart';
import 'package:swamiil/main.dart';
part 'rate_state.dart';

class RateCubit extends Cubit<RateState> {
  RateCubit({required this.rateUseCase}) : super(RateInitial());

  final RateUseCase rateUseCase;
  Future<void> rateSupplier({
    required int orderId,
    required double rate,
    required String comment,
  }) async {
    emit(RateSupplierLoadingState());
    final result = await rateUseCase.rateSupplier(
      orderId: orderId,
      rate: rate,
      comment: comment,
    );
    Map data = {};

    result.fold(
      (error) {
        showToast(error.message ?? "Unknown error");
        emit(RateSupplierErrorState());
      },
      (success) {
        navigatorKey.currentContext!
            .read<FinishedOrdersCubit>()
            .pagingController
            .itemList!
            .where((order) => order.id == orderId)
            .first
            .isRated = true;
        navigatorKey.currentContext!
            .read<FinishedOrdersCubit>()
            .updateOrderRating(orderId: orderId);
        //   successDialog(msg: "rate_success".tr(), lottie: Assets.lottieSuccess);
        emit(RateSupplierSuccessState());
      },
    );

    emit(RateSupplierSuccessState());
  }
}
