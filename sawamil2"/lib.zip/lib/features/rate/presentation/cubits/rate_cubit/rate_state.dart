part of 'rate_cubit.dart';

sealed class RateState extends Equatable {
  const RateState();

  @override
  List<Object> get props => [];
}

final class RateInitial extends RateState {}
final class RateSupplierLoadingState extends RateState {}
final class RateSupplierSuccessState extends RateState {}
final class RateSupplierErrorState extends RateState {}
