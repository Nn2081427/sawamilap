// import 'package:dartz/dartz.dart';
// import 'package:dio/dio.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../../../core/constants/constants.dart';
// import '../../../../core/dialog/confirm_dialog.dart';
// import '../../../../core/dialog/snack_bar.dart';
// import '../../../../core/dialog/success_dialog.dart';
// import '../../../../core/helper_function/convert.dart';
// import '../../../../core/helper_function/helper_function.dart';
// import '../../../../core/helper_function/navigation.dart';
// import '../../../../core/models/pagination_class.dart';
// import '../widgets/charge_wallet_widget.dart';

// class WalletProvider extends ChangeNotifier implements PaginationClass {
//   List<OperationEntity>? myOperations = [];
//   Future walletOperations() async {
//     Map<String, dynamic> data = {};
//     data['page'] = pageIndex;
//     Either<DioException, List<OperationEntity>> login = await WalletUseCases(sl()).walletOperations(data);
//     login.fold((l) {
//       showToast("${l.message}");
//     }, (r) async {
//       pageIndex++;
//       myOperations ??= [];
//       myOperations?.addAll(r);
//       if (r.isEmpty) {
//         paginationFinished = true;
//       }
//     });
//     paginationStarted = false;

//     notifyListeners();
//   }

//   void goToWalletPage() {
//     refresh();

//     navP(UserWalletHome());
//   }

//   void refresh() {
//     clear();
//     notifyListeners();
//     Provider.of<AuthProvider>(Constants.globalContext(), listen: false).getProfile();
//     walletOperations();
//   }

//   void showChargeSheet() {
//     showModalBottomSheet(
//       context: Constants.globalContext(),
//       backgroundColor: Colors.white,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(
//           top: Radius.circular(36),
//         ),
//       ),
//       builder: (context) {
//         return ChargeWalletWidget();
//       },
//       // isScrollControlled: true,
//     );
//   }

//   void clear() {
//     myOperations = null;
//     paginationStarted = false;
//     paginationFinished = false;
//     pageIndex = 1;
//   }

//   TextEditingController walletChargeController = TextEditingController();
//   void chargeWallet({required String value}) {
//     AuthProvider authProvider = Provider.of(Constants.globalContext(), listen: false);
//     navP(
//         PaymentOnlinePage(
//           total: convertDataToNum(value),
          
//           type: 'wallet',
//         ), then: (val) {
//       if (val == 'paid') {
//         SettingsProvider userProfileProvider = Provider.of(Constants.globalContext(),listen: false);
//         successDialog();
//         authProvider.userEntity!.wallet = authProvider.userEntity!.wallet! + convertDataToNum(value);
//         authProvider.rebuild();
//         userProfileProvider.getData();
//         notifyListeners();
//       } else if (val == 'filed') {
//         showToast(LanguageProvider.translate('error', 'error'));
//       }
//     });
//   }

//   Future<bool> checkWallet({required num moneyAmount}) async {
//     AuthProvider authProvider = Provider.of(Constants.globalContext(), listen: false);
//     if (moneyAmount > convertDataToDouble(authProvider.userEntity!.wallet)) {
//       showToast(LanguageProvider.translate('error', 'wallet'));
//       await delay(1000);
//       confirmDialog(LanguageProvider.translate('wallet', 'charge_wallet'), LanguageProvider.translate('buttons', 'confirm'), () {
//         navPop();
//         refresh();
//         navP(UserWalletHome(fromHome: false));
//       });
//       return false;
//     } else {
//       return true;
//     }
//   }

//   @override
//   int pageIndex = 1;

//   @override
//   bool paginationFinished = false;

//   @override
//   bool paginationStarted = false;

//   @override
//   void pagination(ScrollController controller) async {
//     controller.addListener(() async {
//       if (controller.position.atEdge && controller.position.pixels > 50) {
//         if (!paginationFinished && !paginationStarted && myOperations != null && myOperations!.isNotEmpty) {
//           paginationStarted = true;
//           notifyListeners();
//           await walletOperations();
//         }
//       }
//     });
//   }
// }
