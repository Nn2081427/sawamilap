import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/text_style.dart';
import 'package:swamiil/core/widgets/text_field.dart';
import '../provider/wallet_provider.dart';

class ChargeWalletWidget extends StatelessWidget {
  ChargeWalletWidget({super.key});
  final TextEditingController walletController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    // WalletProvider walletProvider = Provider.of(context);
    return Material(
      borderRadius: BorderRadius.circular(36),
      color: Colors.white,
      elevation: 5,
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 35.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: Colors.grey.shade200),
              ),
              SizedBox(
                height: 1.h,
              ),
              Text(
                "charge wallet".tr(),
                style: Fonts.text14Black.copyWith(fontWeight: FontWeight.w500),
              ),
              SizedBox(
                height: 2.h,
              ),
              Container(
                width: 100.w,
                height: 0.5.h,
                decoration: BoxDecoration(color: Colors.grey),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                children: [
                  Text("enter value".tr(),
                      style: Fonts.text14Black.copyWith(
                        fontWeight: FontWeight.w500,
                      )),
                ],
              ),
              SizedBox(
                height: 1.h,
              ),
              TextFieldWidget(
                color: const Color(0xffEFF2F2),
                borderColor: Colors.transparent,
                controller: walletController,
                contentPadding: EdgeInsets.all(2.w),
                onChange: (val) {
                  if (num.tryParse(val) == null) {
                    // walletProvider.walletChargeController.clear();
                    showToast('number_error');
                  }
                },
                suffix: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) =>
                          AppColors.gradient.createShader(bounds),
                      blendMode: BlendMode.srcIn,
                      child: Text(
                        "sar",
                        style: TextStyleClass.semiStyle(color: Colors.white)
                            .copyWith(height: 1),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              InkWell(
                onTap: () {
                  FocusScope.of(context).unfocus();
                  // if (walletProvider.walletChargeController.text.isNotEmpty) {
                  //   navPop();
                  //   walletProvider.chargeWallet(
                  //       value: walletProvider.walletChargeController.text);
                  // }
                },
                child: Container(
                  width: 60.w,
                  height: 6.h,
                  decoration: BoxDecoration(
                      gradient: AppColors.gradient,
                      borderRadius: BorderRadius.circular(58.8)),
                  child: Stack(
                    alignment: AlignmentDirectional.bottomEnd,
                    children: [
                      Center(
                        child: Text(
                          "pay".tr(),
                          style: Fonts.textWhite18.copyWith(fontSize: 12),
                        ),
                      ),
                      Container(
                        height: 6.h,
                        width: 6.h,
                        decoration: BoxDecoration(
                            color: Colors.black, shape: BoxShape.circle),
                        child: Center(
                          child: ShaderMask(
                            shaderCallback: (bounds) =>
                                AppColors.gradient.createShader(bounds),
                            blendMode: BlendMode.srcIn,
                            child: Text(
                              "sar".tr(),
                              style:
                                  TextStyleClass.semiStyle(color: Colors.white)
                                      .copyWith(height: 1),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 8.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
