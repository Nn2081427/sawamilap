import 'package:flutter/material.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';

class CustomBottomNavBar extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onItemTapped;
  final bool isSupplier;
  final String? profileImageUrl;

  const CustomBottomNavBar({
    super.key,
    required this.selectedIndex,
    required this.onItemTapped,
    required this.isSupplier,
    this.profileImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    final tabsNames = isSupplier ? supplierTabsNames : userTabsNames;
    final navItems = _buildNavItems(context, tabsNames);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      height: 100,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.2),
            blurRadius: 10,
            spreadRadius: 2,
            offset: const Offset(0, -2),
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: navItems,
      ),
    );
  }

  List<Widget> _buildNavItems(BuildContext context, List<String> tabsNames) {
    final assetName = isSupplier ? supplierAssetsIcons : userAssetsIcons;
    final navItems = <Widget>[];

    for (int index = 0; index < tabsNames.length; index++) {
      final isSelected = index == selectedIndex;
      final isProfileTab = index == tabsNames.length - 1;

      navItems.add(
        Expanded(
          child: _NavBarItem(
            isSelected: isSelected,
            label: tabsNames[index],
            selectedIcon:
                isProfileTab ? null : assetName[index]["selected"] ?? '',
            unselectedIcon:
                isProfileTab ? null : assetName[index]["unselected"] ?? '',
            profileImageUrl: isProfileTab ? profileImageUrl : null,
            onTap: () => onItemTapped(index),
          ),
        ),
      );
    }

    return navItems;
  }
}

class _NavBarItem extends StatelessWidget {
  final bool isSelected;
  final String label;
  final String? selectedIcon;
  final String? unselectedIcon;
  final String? profileImageUrl;
  final VoidCallback onTap;

  const _NavBarItem({
    required this.isSelected,
    required this.label,
    this.selectedIcon,
    this.unselectedIcon,
    this.profileImageUrl,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 9,
            width: 18,
            decoration: BoxDecoration(
              color: isSelected ? AppColors.mainColor : Colors.transparent,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(8),
                bottomRight: Radius.circular(8),
              ),
            ),
          ),
          const SizedBox(height: 15),
          _buildIcon(),
          const SizedBox(height: 12),
          Text(
            label,
            style: Fonts.textSplash14.copyWith(
              color: isSelected ? AppColors.mainColor : Colors.grey,
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIcon() {
    if (profileImageUrl != null) {
      return ClipOval(
        child: Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            border: Border.all(
              color: isSelected ? AppColors.mainColor : Colors.transparent,
              width: 2,
            ),
            shape: BoxShape.circle,
          ),
          child: profileImageUrl!.isNotEmpty
              ? CustomImageCacheProvider(
                  imageUrl: profileImageUrl!,
                  borderRadius: 100,
                  width: 26,
                  height: 26,
                  fit: BoxFit.cover,
                  errorWidget: _buildDefaultProfileIcon(),
                )
              : _buildDefaultProfileIcon(),
        ),
      );
    } else if (selectedIcon != null && unselectedIcon != null) {
      return Image.asset(
        isSelected ? selectedIcon! : unselectedIcon!,
        width: 28,
        height: 28,
      );
    } else {
      return _buildDefaultProfileIcon();
    }
  }

  Widget _buildDefaultProfileIcon() {
    return Icon(
      Icons.person,
      size: 28,
      color: isSelected ? AppColors.mainColor : Colors.grey,
    );
  }
}
