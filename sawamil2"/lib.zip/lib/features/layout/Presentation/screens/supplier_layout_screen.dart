import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/features/layout/Presentation/widgets/custom_button_nav_bar.dart';
import 'package:swamiil/features/home_supplier/presentation/screens/home_supplier_screen.dart';
import 'package:swamiil/features/layout/cubit/main_layout_cubit.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/screens/supplier_profile.dart';

import '../../../offers/Presentation/screens/my_offers_supplier_screen.dart';
import '../../../orders/Presentation/screens/my_clients_screen.dart';

class SupplierLayoutScreen extends StatefulWidget {
  const SupplierLayoutScreen({super.key});

  @override
  State<SupplierLayoutScreen> createState() => _SupplierLayoutScreenState();
}

class _SupplierLayoutScreenState extends State<SupplierLayoutScreen> {
  final List<Widget> _pages = [
    HomeSupplierScreen(),
    MyOffersSupplierScreen(),
    MyClientsScreen(),
    SupplierProfile(),
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: BlocProvider(
        create: (context) => LayoutCubit(),
        child: Scaffold(
          backgroundColor: Colors.white,
          body: BlocBuilder<LayoutCubit, int>(
            builder: (context, currentIndex) {
              return _pages[currentIndex];
            },
          ),
          bottomNavigationBar: BlocBuilder<LayoutCubit, int>(
            builder: (context, currentIndex) {
              return CustomBottomNavBar(
                isSupplier: true,
                selectedIndex: currentIndex,
                onItemTapped: (index) {
                  context.read<LayoutCubit>().changePage(index);
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
