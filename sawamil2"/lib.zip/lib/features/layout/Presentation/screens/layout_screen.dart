import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/features/layout/Presentation/widgets/custom_button_nav_bar.dart';
import 'package:swamiil/features/Home/Presentation/screens/home_screen.dart';
import 'package:swamiil/features/chat/Presentation/screens/chat_screen.dart';
import 'package:swamiil/features/layout/cubit/main_layout_cubit.dart';
import 'package:swamiil/features/orders/Presentation/screens/orders_screen.dart';
import 'package:swamiil/features/profile/Presentation/screens/user_profile_screen.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';

class LayoutScreen extends StatefulWidget {
  const LayoutScreen({super.key});

  @override
  State<LayoutScreen> createState() => _LayoutScreenState();
}

class _LayoutScreenState extends State<LayoutScreen>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // double? lat = sharedPreferences.getDouble('lat');
    // if((sharedPreferences.getBool('are_noti_start')==null)&&lat==null){
    //   sharedPreferences.setBool('are_noti_start', true);
    //   // sharedPreferences.remove('date_time',);
    //   print('_MainPageState.initState start_noti');
    //   PrayTimesProvider.schedulePrayerNotifications();
    // }
    WidgetsBinding.instance.addPostFrameCallback((_) {
//domain?orderId=5&ad_id=3&user_id=5
      // final _appLinks = AppLinks();
      // _appLinks.uriLinkStream.listen((uri) {
      //   print(uri.path);
      //   String payload = jsonEncode(uri.queryParameters);
      //   Map map = jsonDecode(payload);
      //   int id = convertStringToInt(map['id']);
      //   if(uri.path.contains('ad')){
      //     Provider.of<AdDetailsProvider>(Constants.globalContext(),listen: false).goToAdDetailsPage(id);
      //   }else if(uri.path.contains('user')){
      //     Provider.of<AdAdvertiserDetailsProvider>(context,
      //         listen: false)
      //         .goToAdAdvertiserDetailsPage(id);
      //   }
      // });
    });
    // FirebaseMessaging.instance.getInitialMessage().then((event) {
    //   if (event != null) {
    //     if (event.data.isNotEmpty) {
    //       String payload = jsonEncode(event.data);
    //       clickNoti(payload);
    //     }
    //   }
    // });
  }

  final List<Widget> _pages = [
    HomeScreen(),
    OrdersScreen(),
    ChatScreen(),
    UserProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: BlocProvider(
        create: (context) => LayoutCubit(),
        child: Scaffold(
          backgroundColor: Colors.white,
          body: BlocBuilder<LayoutCubit, int>(
            builder: (context, currentIndex) {
              return _pages[currentIndex];
            },
          ),
          bottomNavigationBar: BlocBuilder<LayoutCubit, int>(
            builder: (context, currentIndex) {
              return CustomBottomNavBar(
                isSupplier: false,
                profileImageUrl: context.read<AuthCubit>().userEntity?.image,
                selectedIndex: currentIndex,
                onItemTapped: context.read<LayoutCubit>().changePage,
              );
            },
          ),
        ),
      ),
    );
  }
}
