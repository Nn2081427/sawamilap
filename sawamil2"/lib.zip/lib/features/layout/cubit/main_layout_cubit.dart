import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';
import 'package:swamiil/features/layout/Presentation/screens/layout_screen.dart';

import '../../chat/Presentation/cubits/chat_cubit/chat_cubit.dart';

part 'main_layout_state.dart';

class LayoutCubit extends Cubit<int> {
  LayoutCubit() : super(0);

  void navigateToLayoutScreen() {
    // startSocket();
    changePage(0);
    Constants.globalContext().read<BrandsCubit>().clear();
    navPARU(const LayoutScreen());
  }

  void changePage(int index) {
    if(index==2){
      Constants.globalContext().read<ChatCubit>().loadInitialChats();
    }
    emit(index);
  }
}
// late WebSocketChannel socket;

// WebSocketChannel? socket;
// void startSocket(){
//   if(socket!=null){
//     socket!.sink.close();
//   }
//   socket = WebSocketChannel.connect('wsUrl');
//
//   await socket.ready;
//
//   socket.stream.listen((event) {
//     try {
//       final data = jsonDecode(event);
//       print(data);
//
//       if (data["event"] == "pusher:connection_established") {
//         final subscribeData = {
//           "event": "pusher:subscribe",
//           "data": {"channel": "chat_1"}
//         };
//         socket.sink.add(jsonEncode(subscribeData));
//       }
//       if (data["event"] == "pusher:ping") {
//         final pongResponse = {"event": "pusher:pong"};
//         socket.sink.add(jsonEncode(pongResponse));
//       }
//
//
//
//
//
//
//
//       print(data);
//
//
//       if (data["event"] == "chat" ) {
//         try{
//           Map message = jsonDecode(data['data']);
//           MessageModel messageModel = MessageModel.fromJson(message);
//           MessagesCubit messageProvider = Constants.globalContext().read<MessagesCubit>();
//           bool check = messageProvider.checkMessageOfThisChat(convertStringToInt(message['chat']['id']));
//           print('start_not3');
//           if(check){
//             messageProvider.addOneMessage(messageModel);
//           }else{
//             NotificationLocalClass.showNoti(title: data2.title??"", body: data2.body??"", payload: jsonEncode(payload));
//           }
//
//         }catch(e){
//           print(e);
//         }
//       }
//
//     } catch (e) {
//       print(e);
//     }
//   });
// }
