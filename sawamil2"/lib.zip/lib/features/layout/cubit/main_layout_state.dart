part of 'main_layout_cubit.dart';

sealed class MainLayoutState extends Equatable {
  const MainLayoutState();

  @override
  List<Object> get props => [];
}

final class MainLayoutInitial extends MainLayoutState {}
