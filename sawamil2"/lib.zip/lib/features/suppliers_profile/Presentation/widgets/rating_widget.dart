import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/core/widgets/rating_star_widget.dart';

import '../../../orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import '../../../rate/domain/entities/supplier_rate_entity.dart';

class RatingWidget extends StatelessWidget {
  const RatingWidget({super.key, this.supplierRateEntity});

  final SupplierRateEntity? supplierRateEntity;
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 8,
      ),
      padding: EdgeInsets.all(15),
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.black26,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(10),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageCacheProvider(
                imageUrl: supplierRateEntity?.user?.image ?? '',
                width: 50,
                borderRadius: 50,
                height: 50,
              ),
            
              SizedBox(width: 2.w,),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          "${supplierRateEntity?.user?.firstName ?? ''} ${supplierRateEntity?.user?.lastName ?? ''}",
                          style: Fonts.textBlack18,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Spacer(),
                        Text(
                          supplierRateEntity?.createdAt != null
                              ? DateFormat('yyyy/MM/dd').format(DateTime.parse(
                              supplierRateEntity!.createdAt!.toString()))
                              : '',
                          style: Fonts.textSplash14.copyWith(
                              color: Colors.black.withOpacity(0.6),
                              fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    RatingStarWidget(
                      showText: true,
                      rate: supplierRateEntity?.rate?.toDouble() ?? 0.0,
                      read: true,
                    ),
                  ],
                ),
              ),
            
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Text(
            "Rate".tr(),
            style: Fonts.headTitle20
                .copyWith(fontSize: 20.sp, fontWeight: FontWeight.w500),
          ),
          SizedBox(
            height: 20,
          ),
          ExpandableDescriptionText(description: supplierRateEntity?.comment??"",),
        ],
      ),
    );
  }
}
