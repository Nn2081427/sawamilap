import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/wallet/presentation/widgets/wallet_bottom_widget.dart';

class WalletWidget extends StatelessWidget {
  const WalletWidget({super.key, required this.walletAmount});
  final String walletAmount;

  @override
  Widget build(BuildContext context) {
    return Row(
      // crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          walletAmount,
          style: Fonts.text16Black.copyWith(fontWeight: FontWeight.w600),
        ),
        SizedBox(
          width: 10,
        ),
        Image.asset(
          Assets.currencyIcon,
          color: Colors.black,
          width: 23,
          height: 26,
        ),
        SizedBox(
          width: 23,
        ),
        InkWell(
          onTap: () {
            showChargeSheet(context);
          },
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: AppColors.mainColor, width: 1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: FittedBox(
              child: Text(
                "Rechagrge".tr(),
                style: Fonts.text16Orange.copyWith(
                  fontSize: 12,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
