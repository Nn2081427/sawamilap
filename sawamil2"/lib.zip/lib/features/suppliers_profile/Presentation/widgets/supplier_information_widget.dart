import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/ExpandableBioSection.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/SupplierInfoSelector.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/rating_widget.dart';

import '../../../auth_supplier/domain/entities/supplier_entity.dart';
import '../../../rate/domain/entities/supplier_rate_entity.dart';
import '../../../rate/presentation/cubits/supplier_profile_cubit/supplier_profile_cubit.dart';

class SupplierInformationsWidget extends StatefulWidget {
  const SupplierInformationsWidget({
    super.key,
    this.headTitle1,
    this.headTitle2,
    this.supplierDataEntity,
  });

  final String? headTitle1;
  final String? headTitle2;
  final SupplierEntity? supplierDataEntity;

  @override
  State<SupplierInformationsWidget> createState() =>
      _SupplierInformationsWidgetState();
}

class _SupplierInformationsWidgetState
    extends State<SupplierInformationsWidget> {
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    context.read<SupplierPublicProfileCubit>().loadSupplierRates(1);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SupplierInfoSelector(
          selectedIndex: selectedIndex,
          onIndexChanged: (index) {
            setState(() {
              selectedIndex = index;
            });
          },
        ),
        selectedIndex == 0
            ? ExpandableBioSection(
                bioText: widget.supplierDataEntity?.bio ?? '',
              )
            : Flexible(
                child: _buildReviewsSection(),
              ),
      ],
    );
  }

  Widget _buildReviewsSection() {
    return BlocBuilder<SupplierPublicProfileCubit, SupplierProfileState>(
      buildWhen: (previous, current) {
        return current is SupplierRatesLoading ||
            current is SupplierRatesLoaded ||
            current is SupplierRatesError;
      },
      builder: (context, state) {
        if (state is SupplierRatesLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is SupplierRatesError) {
          return Center(child: Text("Error loading profile"));
        } else if (state is SupplierRatesLoaded) {
          return _buildRatingList();
        }
        return Text(
          "No reviews available",
          style: Fonts.textBlack18,
        );
      },
    );
  }

  Widget _buildRatingList() {
    return PagedListView<int, SupplierRateEntity>(
      pagingController:
          context.read<SupplierPublicProfileCubit>().pagingController,
      builderDelegate: PagedChildBuilderDelegate<SupplierRateEntity>(
        itemBuilder: (context, rate, index) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: RatingWidget(
              supplierRateEntity: rate,
            ),
          );
        },
        firstPageProgressIndicatorBuilder: (_) => const Center(
            child: ShimmerWidget(width: double.infinity, height: 150)),
        newPageProgressIndicatorBuilder: (_) => const Center(
            child: ShimmerWidget(width: double.infinity, height: 150)),
        noItemsFoundIndicatorBuilder: (_) => Center(
          child: EmptyAnimation(
              title: "No reviews available".tr(), gif: Assets.emptyListLottie),
        ),
        noMoreItemsIndicatorBuilder: (_) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Align(
            alignment: Alignment.center,
            child: Center(
              heightFactor: 1,
              child: Text(
                "No more reviews".tr(),
                style: const TextStyle(color: Colors.grey),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
