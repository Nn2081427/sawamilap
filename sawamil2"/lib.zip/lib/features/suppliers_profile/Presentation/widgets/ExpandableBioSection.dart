import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

class ExpandableBioSection extends StatefulWidget {
  final String bioText;

  const ExpandableBioSection({super.key, required this.bioText});

  @override
  State<ExpandableBioSection> createState() => _ExpandableBioSectionState();
}

class _ExpandableBioSectionState extends State<ExpandableBioSection>
    with TickerProviderStateMixin {
  bool _isExpanded = false;
  static const int _maxCollapsedLines = 3;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _toggleExpanded() {
    setState(() {
      _isExpanded = !_isExpanded;
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
    });
  }

  bool _shouldShowExpandButton(String text, BuildContext context) {
    if (text.isEmpty) return false;

    final textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: Fonts.textBlack18.copyWith(
          fontWeight: FontWeight.w500,
          height: 2,
        ),
      ),
      maxLines: _maxCollapsedLines,
      textDirection: Directionality.of(context),
    );
    final containerWidth = MediaQuery.of(context).size.width - 60;
    textPainter.layout(maxWidth: containerWidth);

    return textPainter.didExceedMaxLines;
  }

  @override
  Widget build(BuildContext context) {
    final shouldShowExpandButton =
        _shouldShowExpandButton(widget.bioText, context);

    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(top: 2.h),
      padding: const EdgeInsets.only(left: 15, right: 15, bottom: 20, top: 10),
      decoration: BoxDecoration(
        color: AppColors.textFieldBgColor,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedCrossFade(
              firstChild: Text(
                widget.bioText,
                textAlign: TextAlign.start,
                style: Fonts.textBlack18.copyWith(
                  fontWeight: FontWeight.w500,
                  height: 2,
                ),
                maxLines: _maxCollapsedLines,
                overflow: TextOverflow.ellipsis,
              ),
              secondChild: Text(
                widget.bioText,
                textAlign: TextAlign.start,
                style: Fonts.textBlack18.copyWith(
                  fontWeight: FontWeight.w500,
                  height: 2,
                ),
              ),
              crossFadeState: _isExpanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 300),
            ),
            if (shouldShowExpandButton) ...[
              const SizedBox(height: 8),
              AnimatedBuilder(
                animation: _fadeAnimation,
                builder: (context, child) {
                  return GestureDetector(
                    onTap: _toggleExpanded,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.orange.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _isExpanded ? "See less".tr() : "See more".tr(),
                            style: Fonts.textBlack18.copyWith(
                              color: Colors.orange,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(width: 4),
                          AnimatedRotation(
                            turns: _isExpanded ? 0.5 : 0.0,
                            duration: const Duration(milliseconds: 300),
                            child: Icon(
                              Icons.keyboard_arrow_down,
                              color: Colors.orange,
                              size: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}