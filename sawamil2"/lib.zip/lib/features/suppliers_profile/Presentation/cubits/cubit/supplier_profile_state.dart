
import '../../../../auth_supplier/domain/entities/supplier_entity.dart';

abstract class SupplierProfileState {}

class SupplierProfileInitial extends SupplierProfileState {}

class SupplierProfileLoading extends SupplierProfileState {}

class SupplierProfileLoaded extends SupplierProfileState {
  final SupplierEntity entity;

  SupplierProfileLoaded({required this.entity});
}

class SupplierProfileError extends SupplierProfileState {
  final String message;

  SupplierProfileError({required this.message});
}

class ImageUpdated extends  SupplierProfileState {}


