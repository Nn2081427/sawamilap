import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/dialog/drop_down_dialog.dart';
import 'package:swamiil/core/models/text_field_model.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/auth_supplier/domain/use_cases/supplier_auth_use_case.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_state.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';

import '../../../../../core/dialog/snack_bar.dart';
import '../../../../../core/helper_function/api.dart';
import '../../../../../core/helper_function/appSecureStore.dart';
import '../../../../../core/helper_function/navigation.dart';
import '../../../../../main.dart';
import '../../../../auth_supplier/domain/entities/supplier_entity.dart';
import '../../../../layout/Presentation/screens/supplier_layout_screen.dart';

class SupplierProfileCubit extends Cubit<SupplierProfileState> {
  SupplierProfileCubit({required this.useCase})
      : super(SupplierProfileInitial());

  final SupplierAuthUseCase useCase;

  SupplierEntity? _cachedProfile;
  String? imagePath;

  Future<void> getSupplierProfile(
      {bool showLoading = false, bool fromSplash = false}) async {
    if (_cachedProfile != null) {
      _populateControllers(_cachedProfile!);
      emit(SupplierProfileLoaded(entity: _cachedProfile!));
    }

    // Optionally emit loading state (disabled by default)
    if (showLoading) emit(SupplierProfileLoading());

    final result = await useCase.getSupplierProfile();
    result.fold(
      (l) {
        talker.error(l.message ?? "Unknown error");
        if (!fromSplash) {
          showToast(l.message ?? "Unknown error");
        } else {
          AuthSecureStorage.clearAuthData();
          Constants.globalContext().read<AuthCubit>().navigateToUsersScreen();
        }
        emit(SupplierProfileError(message: l.message!));
      },
      (r) {
        _cachedProfile = r; // Cache the result
        _populateControllers(r);
        emit(SupplierProfileLoaded(entity: r));
        if (fromSplash) {
          navPARU(SupplierLayoutScreen());
        }
      },
    );
  }

  void _populateControllers(SupplierEntity r) {
    supplierPhone.controller.text = r.phone ?? '';
    supplierNameInputs[0].controller.text = r.firstName ?? '';
    supplierNameInputs[1].controller.text = r.lastName ?? '';
    supplierDataInputs[0].controller.text = r.bio ?? '';
    supplierDataInputs[1].controller.text = r.city?.name ?? '';
    supplierDataInputs[2].controller.text = r.area?.name ?? ''; // Added area
  }
  // update supplier profile

  TextFieldModel supplierPhone = TextFieldModel(
    controller: TextEditingController(),
    key: "phone_number",
    contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
    validator: (value) => null,
    image: Assets.editIcon,
    hint: "enter your phone number".tr(),
    label: "Phone Number".tr(),
  );
  List<TextFieldModel> supplierNameInputs = [
    TextFieldModel(
      controller: TextEditingController(),
      key: "first_name",
      width: 45.w,
      label: "First Name".tr(),
      validator: (value) => null,
      hint: "enter your first name".tr(),
    ),
    TextFieldModel(
      label: "Last Name".tr(),
      width: 45.w,
      controller: TextEditingController(),
      key: "last_name",
      validator: (value) => null,
      hint: "enter your last name".tr(),
      labelStyle: Fonts.textBlack18.copyWith(
        color: Colors.grey,
      ),
    ),
  ];
  List<TextFieldModel> supplierDataInputs = [
    TextFieldModel(
      width: double.infinity,
      label: "bio".tr(),
      expands: true,
      maxLength: 3,
      textInputType: TextInputType.multiline,
      contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
      controller: TextEditingController(),
      key: "bio",
      image: Assets.editIcon,
      validator: (value) => null,
      hint: "add_your_bio".tr(),
    ),
    TextFieldModel(
      suffix: Icon(
        Icons.arrow_drop_down,
        color: Colors.black,
      ),
      // onTap will be assigned after construction
      onTap: () {},
      width: double.infinity,
      label: "city".tr(),
      contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
      controller: TextEditingController(),
      key: "city".tr(),
      image: Assets.editIcon,
      validator: (value) => null,
      hint: "enter your city".tr(),
      readOnly: true,
    ),
    TextFieldModel(
      suffix: Icon(
        Icons.arrow_drop_down,
        color: Colors.black,
      ),
      // onTap will be assigned after construction
      onTap: () {
        // navigatorKey.currentContext!.read<CitiesCubit>().cities;
      },
      width: double.infinity,
      label: "area".tr(),
      contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
      controller: TextEditingController(),
      key: "area".tr(),
      image: Assets.editIcon,
      validator: (value) => null,
      hint: "enter area area".tr(),
      readOnly: true,
    ),
  ];

  void updateDropDown(String value, String key) {
    supplierDataInputs.firstWhere((e) => e.key == key).controller.text = value;
  }

  Map<String, dynamic> data = {
    "phone": "",
    "first_name": "",
    "last_name": "",
    "bio": "",
    "city": "",
    "area": "",
  };
  void setImagePath(String path) {
    imagePath = path;
    emit(ImageUpdated());
  }

  Future<void> updateSupplierProfile(Map<String, dynamic> data) async {
    emit(SupplierProfileLoading());
    final result = await useCase.updateSupplierProfile(data);
    result.fold(
      (l) => emit(SupplierProfileError(message: l.message!)),
      (success) async {
        if (true) {
          // Fetch updated profile after success
          final profileResult = await useCase.updateSupplierProfile(data);
          profileResult.fold(
            (l) => emit(SupplierProfileError(message: l.message!)),
            (profile) {
              _cachedProfile = profile;
              _populateControllers(profile);
              emit(SupplierProfileLoaded(entity: profile));
            },
          );
        }
      },
    );
  }
}
