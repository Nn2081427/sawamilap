import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/dialog/report_dialog.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/widgets/web_view.dart';
import 'package:swamiil/features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';
import 'package:swamiil/features/notifications/presentation/screens/notifications_screen.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20settings%20cubit/user_profile_settings_state.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/supplier_settings_cubit/supplier_settings_state.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/screens/clients_rating_screen.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/screens/supplier_profile_info_screen.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/change_password_dialog.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/main.dart';

class SupplierSettingsCubit extends Cubit<SupplierSettingsState> {
  SupplierSettingsCubit() : super(SupplierSettingsState(items: [])) {
    loadISettingstems();
  }
  void loadISettingstems() {
    emit(
      SupplierSettingsState(
        items: [
          ProfileMenuItem(
            iconPath: Assets.notificationsIcon,
            title: "All Notifications".tr(),
            onTap: () {
              navP(NotificationsScreen());
            },
          ),
          ProfileMenuItem(
            iconPath: Assets.walletIcon,
            title: "Account Balance".tr(),
            onTap: () {},
          ),
          ProfileMenuItem(
            iconPath: Assets.profileIcon2,
            title: "Seller Information".tr(),
            onTap: () {
              navP(SupplierProfileInfoScreen());
            },
          ),
          ProfileMenuItem(
            iconPath: Assets.changePassword,
            title: "Change Password".tr(),
            onTap: () {
              // ChangePasswordDialog(
              //   onChangePassword: (current, newPass) async {
              //     // TODO: Implement password change logic and return true/false accordingly
              //     return false;
              //   },
              // );
              confirmDialog(
                  title: "Do you want to change your password ?".tr(),
                  confirm: "continue".tr(),
                  cancel: "cancel".tr(),
                  confirmTap: () {});
            },
          ),
          ProfileMenuItem(
            iconPath: Assets.clientsRating,
            title: "Clients Rating".tr(),
            onTap: () {
              // navP(SupplierPublicProfileView());
              navP(ClientsRatingScreen());
            },
          ),
          ProfileMenuItem(
            iconPath: Assets.whoweareIcon,
            title: "about us".tr(),
            onTap: () {
              navP(WebViewPage(
                  title: "about us".tr(),
                  link: navigatorKey.currentContext!
                      .read<SettingsCubit>()
                      .settingsEntity!
                      .aboutLink));
            },
          ),
          ProfileMenuItem(
              iconPath: Assets.messageIcon,
              title: "Suppliers Support".tr(),
              onTap: () {
                reportDialog(
                    title: "write your suggestion or problem", type: "", id: 0);
              }),
          ProfileMenuItem(
            iconPath: Assets.termsAndConditionsIcon,
            title: "Terms and Conditions in Sawamil".tr(),
            onTap: () {
              navP(WebViewPage(
                title: "terms and conditions".tr(),
                link: navigatorKey.currentContext!
                    .read<SettingsCubit>()
                    .settingsEntity!
                    .termsLink,
              ));
            },
          ),
          ProfileMenuItem(
            iconPath: Assets.logoutIcon,
            title: "Log out".tr(),
            onTap: () {
              confirmDialog(
                title: "Do You want to log out ?".tr(),
                confirm: "yes, log out".tr(),
                cancel: "cancel".tr(),
                confirmTap: () {
                  getIt.get<AuthSupplierCubit>().logout();
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
