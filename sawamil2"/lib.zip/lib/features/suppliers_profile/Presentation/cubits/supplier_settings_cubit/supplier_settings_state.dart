import 'package:flutter/material.dart';
import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20settings%20cubit/user_profile_settings_state.dart';

class SupplierSettingsState {
  final List<ProfileMenuItem> items;

  const SupplierSettingsState({required this.items});
}
