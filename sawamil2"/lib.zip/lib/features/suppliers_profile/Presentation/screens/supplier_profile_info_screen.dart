import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/widgets/CustomScreen.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/list_text_field.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/auth_supplier/domain/entities/supplier_entity.dart';
import 'package:swamiil/features/profile/Presentation/widgets/ProfileImage.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_cubit.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_state.dart';

class SupplierProfileInfoScreen extends StatelessWidget {
  const SupplierProfileInfoScreen({super.key, this.supplierEntity});
  final SupplierEntity? supplierEntity;

  @override
  Widget build(BuildContext context) {
    return CustomScreen(
      appBar: AppBarWidget(title: "personal_info".tr()),
      body: BlocBuilder<SupplierProfileCubit, SupplierProfileState>(
          builder: (context, state) {
        final cubit = context.read<SupplierProfileCubit>();

        if (state is SupplierProfileLoading) {
          return const Center(
              child: ShimmerWidget(
            width: double.infinity,
            height: 250,
            numOfShimmer: 1,
            radius: 15,
          ));
        } else if (state is SupplierProfileError) {
          return Center(child: Text(state.message));
        } else if (state is SupplierProfileLoaded) {
          var entitiy = state.entity;
          return SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 5.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: ProfileImage(
                    onImagePicked: (path) {
                      cubit.setImagePath(path);
                    },
                    imageUrl: entitiy.image,
                  ),
                ),
                SizedBox(height: 3.h),
                ListTextFieldWidget(inputs: [cubit.supplierPhone]),
                SizedBox(height: 1.h),
                ListTextFieldWidget(
                  inputs: cubit.supplierNameInputs,
                  isWrap: true,
                ),
                SizedBox(height: 1.h),
                ListTextFieldWidget(inputs: cubit.supplierDataInputs),
                SizedBox(height: 3.h),
                CustomButton(
                    backgroundColor: AppColors.mainColor,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    borderRadius: BorderRadius.circular(8),
                    buttonText: "save_changes".tr(),
                    width: double.infinity,
                    onTap: () {
                      final data = {
                        "firstName":
                            cubit.supplierNameInputs[0].controller.text,
                        "lastName": cubit.supplierNameInputs[1].controller.text,
                        "email": cubit.supplierDataInputs[0].controller.text,
                        "address": cubit.supplierDataInputs[1].controller.text,
                        "bio": cubit.supplierDataInputs[2].controller.text,
                        "area": cubit.supplierDataInputs[2].controller.text,
                      };
                      cubit.updateSupplierProfile(data);
                    }),
              ],
            ),
          );
        }
        // Always return a widget if none of the above conditions are met
        return const SizedBox.shrink();
      }),
    );
  }
}
