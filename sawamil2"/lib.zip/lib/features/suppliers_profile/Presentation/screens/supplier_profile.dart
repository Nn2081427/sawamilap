import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/auth_supplier/domain/use_cases/supplier_auth_use_case.dart';
import 'package:swamiil/features/profile/Presentation/widgets/SettingsListTile.dart';
import 'package:swamiil/features/profile/Presentation/widgets/user_profile_widget.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_cubit.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_state.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/custom_switcher_widget.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/wallet_widget.dart';

import '../cubits/supplier_settings_cubit/supplier_settings_cubit.dart';
import '../cubits/supplier_settings_cubit/supplier_settings_state.dart';

class SupplierProfile extends StatefulWidget {
  const SupplierProfile({super.key});

  @override
  State<SupplierProfile> createState() => _SupplierProfileState();
}

class _SupplierProfileState extends State<SupplierProfile> {
  bool isSwitched = false;

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => SupplierSettingsCubit(),
        ),
        BlocProvider(
          create: (context) => SupplierProfileCubit(
            useCase: getIt.get<SupplierAuthUseCase>(),
          )..getSupplierProfile(),
        ),
      ],
      child: Scaffold(
        body: BlocBuilder<SupplierProfileCubit, SupplierProfileState>(
          builder: (context, state) {
            if (state is SupplierProfileLoading ||
                state is SupplierProfileInitial) {
              // 🔄 Show loading shimmer instead of white screen
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Column(
                  children: const [
                    SizedBox(height: 50),
                    ShimmerWidget(
                      height: 100,
                      width: double.infinity,
                      radius: 15,
                      numOfShimmer: 1,
                    ),
                    SizedBox(height: 20),
                    ShimmerWidget(
                      height: 250,
                      width: double.infinity,
                      radius: 15,
                      numOfShimmer: 1,
                    ),
                  ],
                ),
              );
            } else if (state is SupplierProfileError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Text(
                    state.message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              );
            } else if (state is SupplierProfileLoaded) {
              final supplier = state.entity;
              return SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 7.h),
                    Center(
                      child: UserProfileWidget(
                        isUser: false,
                        supplierEntity: supplier,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    BlocBuilder<SupplierSettingsCubit, SupplierSettingsState>(
                      builder: (context, state) {
                        return Column(
                          children: state.items.asMap().entries.map((entry) {
                            int index = entry.key;
                            var item = entry.value;

                            Widget? trailing;
                            if (index == 0) {
                              trailing = CustomSwitcher(
                                value: isSwitched,
                                onChanged: (bool value) {
                                  setState(() {
                                    isSwitched = value;
                                  });
                                },
                              );
                            } else if (index == 1) {
                              trailing = WalletWidget(
                                walletAmount: supplier.wallet.toString(),
                              );
                            }

                            return Padding(
                              padding: EdgeInsets.only(bottom: 0.5.h),
                              child: SettingsListTile(
                                iconPath: item.iconPath,
                                title: item.title,
                                onTap: item.onTap,
                                textColor: item.textColor,
                                trailing: trailing,
                              ),
                            );
                          }).toList(),
                        );
                      },
                    ),
                  ],
                ),
              );
            }

            // In case something unexpected happens
            return const Center(child: Text("Unexpected state"));
          },
        ),
      ),
    );
  }
}
