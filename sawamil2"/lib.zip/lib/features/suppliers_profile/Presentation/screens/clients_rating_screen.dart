import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/rating_widget.dart';

class ClientsRatingScreen extends StatelessWidget {
  const ClientsRatingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBarWidget(
          title: "Clients Rating".tr(),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10),
          child: ListView(
            children: List.generate(
              10,
              (index) => RatingWidget(),
            ),
          ),
        ));
  }
}
