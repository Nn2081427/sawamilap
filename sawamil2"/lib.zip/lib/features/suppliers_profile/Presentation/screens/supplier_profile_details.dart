import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/supplier_information_widget.dart';
import 'package:swamiil/features/profile/Presentation/widgets/user_profile_widget.dart';

import '../../../auth_supplier/domain/entities/supplier_entity.dart';

class SupplierProfileDetails extends StatelessWidget {
  const SupplierProfileDetails({super.key, required this.supplierEntity});
  final SupplierEntity supplierEntity;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 7.h),
            Center(
              child: UserProfileWidget(
                isUser: false,
                supplierEntity: supplierEntity,
              ),
            ),
            SizedBox(height: 5.h),
            Expanded(child: SupplierInformationsWidget()),
          ],
        ),
      ),
    );
  }
}
