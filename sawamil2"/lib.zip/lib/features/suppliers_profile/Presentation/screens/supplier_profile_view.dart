import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/widgets/supplier_information_widget.dart';
import 'package:swamiil/features/profile/Presentation/widgets/user_profile_widget.dart';
import 'package:swamiil/main.dart';

import '../../../rate/presentation/cubits/supplier_profile_cubit/supplier_profile_cubit.dart';

class SupplierPublicProfileView extends StatefulWidget {
  const SupplierPublicProfileView({super.key});

  @override
  State<SupplierPublicProfileView> createState() =>
      _SupplierPublicProfileViewState();
}

class _SupplierPublicProfileViewState extends State<SupplierPublicProfileView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SupplierPublicProfileCubit>().getSupplierAllRates();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBarWidget(title: ""),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: BlocBuilder<SupplierPublicProfileCubit, SupplierProfileState>(
          buildWhen: (previous, current) {
            if (current is SupplierProfileLoading) {
              return true;
            } else if (current is SupplierProfileLoaded) {
              return true;
            } else if (current is SupplierProfileError) {
              return true;
            }
            return false;
          },
          builder: (context, state) {
            if (state is SupplierProfileLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is SupplierProfileError) {
              talker.error(state.message);
              return Center(child: Text("Error loading profile"));
            } else if (state is SupplierProfileLoaded) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 5),
                  Center(
                      child: UserProfileWidget(
                          supplierEntity: state.supplier,
                          isUser: false,
                          showEmail: false)),
                  const SizedBox(height: 30),
                  Expanded(
                      child: SupplierInformationsWidget(
                    supplierDataEntity: state.supplier,
                  )),
                ],
              );
            }
            return SizedBox();
          },
        ),
      ),
    );
  }
}
