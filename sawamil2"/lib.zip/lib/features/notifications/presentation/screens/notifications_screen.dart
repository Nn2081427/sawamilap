import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/features/notifications/presentation/widgets/CustomNotificationItem.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion(
      value: barColor(),
      child: SafeArea(
        top: true,
        bottom: false,
        child: Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBarWidget(title: "notifications".tr()),
            body: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Text(
                    //   "all_notifications".tr(),
                    //   style:
                    //       Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
                    // ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Container(
                        width: double.infinity,
                        //  margin: const EdgeInsets.all(10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1),
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          children: List.generate(
                            10,
                            (index) => CustomNotificationItem(),
                          ),
                        ))
                  ],
                ),
              ),
            )),
      ),
    );
  }
}
