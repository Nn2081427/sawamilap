import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

class CustomNotificationItem extends StatelessWidget {
  const CustomNotificationItem({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "تم إنجاز طلبك الخاص بتويوتا كورلا 2015 توجه لصفحة الطلبات المنتهية لتقييم البائع     ",
          style: Fonts.text14Black.copyWith(fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 1.5.h,
        ),
        Row(
          children: [
            Spacer(),
            Icon(
              FontAwesomeIcons.clock,
              color: Colors.grey,
              size: 18,
            ),
            SizedBox(
              width: 1.5.w,
            ),
            Text(
              "03:00 AM",
              style: Fonts.text14Black.copyWith(
                  fontWeight: FontWeight.w500,
                  color: Colors.black.withOpacity(0.6)),
            ),
          ],
        ),
        SizedBox(
          height: 1.h,
        ),
        Divider(
          thickness: 1,
          color: Colors.grey.shade300.withOpacity(0.6),
          endIndent: 20,
          indent: 20,
        )
      ],
    );
  }
}
