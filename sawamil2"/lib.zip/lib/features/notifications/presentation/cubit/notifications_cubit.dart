import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/notifications/presentation/screens/notifications_screen.dart';

part 'notifications_state.dart';

class NotificationsCubit extends Cubit<NotificationsState> {
  NotificationsCubit() : super(NotificationsInitial());

  void navigateToNotifications() {
    navP(NotificationsScreen());
  }
}
