import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/prefs.dart';
import '../../../../core/helper_function/api.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';

class ChatRemoteDataSources {
  static Future<Either<DioException, List<ChatModel>>> getAllChats() async {

    var response = await ApiHandel.getInstance.get('user/get_chats');

    return response.fold((l) => Left(l), (r) {
      List<ChatModel> chats = [];
      r.data['data'].forEach((v) => chats.add(ChatModel.fromJson(v)));
      return Right(chats);
    });
  }

  static Future<Either<DioException, List<ChatModel>>> getCurrentChats() async {

    var response = await ApiHandel.getInstance.get('user/get_current_chats');

    return response.fold((l) => Left(l), (r) {
      List<ChatModel> chats = [];
      r.data['data'].forEach((v) => chats.add(ChatModel.fromJson(v)));
      return Right(chats);
    });
  }

  static Future<Either<DioException, ChatModel>> getChatDetails(
      Map<String, dynamic> data) async {
    String isUser = sharedPreferences.getString('user_type')=='user'?"user":"supplier";
    var response =
        await ApiHandel.getInstance.post('$isUser/get_chat_details', data);
    return response.fold((l) => Left(l), (r) {
      return Right(ChatModel.fromJson(r.data['data']));
    });
  }

  static Future<Either<DioException, bool>> createMessage(
      dynamic data) async {
    String isUser = sharedPreferences.getString('user_type')=='user'?"user":"supplier";
    var response =
        await ApiHandel.getInstance.post('$isUser/create_message', data);
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }



}
