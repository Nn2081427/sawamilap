import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/auth_supplier/data/models/supplier_model.dart';
import 'package:swamiil/features/chat/data/models/message_model.dart';

import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';

import '../../../user_auth/Data/models/user_model.dart';

class ChatModel extends ChatEntity {
  ChatModel({required super.id, required super.orderId,
    required super.userId, required super.supplierId,
    required super.createdAt, required super.lastMessage,
    required super.unReadCount, required super.user, required super.supplier, required super.messages});

  factory ChatModel.fromJson(Map<String, dynamic> data) {
    MessageModel? messageModel;
    if(data.containsKey('last_message') && data['last_message'] != null){
      messageModel = MessageModel.fromJson(data['last_message']);
    }
    List<MessageModel> messages = [];
    if(data.containsKey('messages')&&data['messages']!=null){
      for(var i in data['messages']){
        messages.add(MessageModel.fromJson(i));
      }
    }
    UserModel? userModel;
    if(data.containsKey('user') && data['user'] != null){
      userModel = UserModel.fromJson(data['user']);
    }
    SupplierModel? supplierEntity;
    if(data.containsKey('supplier') && data['supplier'] != null){
      supplierEntity = SupplierModel.fromJson(data['supplier']);
    }
    return ChatModel(
      id: convertStringToInt(data['id']),
      orderId: convertStringToInt(data['order_id']),
      userId: convertStringToInt(data['user_id']),
      supplierId: convertStringToInt(data['supplier_id']),
      createdAt: _parseDateTime(data['created_at']),
      lastMessage: messageModel,
      unReadCount: convertStringToInt(data['un_read_count']),
      user: userModel,
      messages: messages,
      supplier: supplierEntity,
    );
  }

  static DateTime _parseDateTime(dynamic value) {
    if (value == null || value is! String || value.isEmpty) {
      return DateTime.now();
    }
    return DateTime.tryParse(value) ?? DateTime.now();
  }
}
