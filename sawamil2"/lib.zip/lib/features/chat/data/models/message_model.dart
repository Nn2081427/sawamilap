// message_model.dart
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/chat/domain/entity/message_entity.dart';

class MessageModel extends MessageEntity {
  MessageModel({
    required super.id,
    required super.date,
    required super.type,
    required super.message,
    required super.chatId,
    required super.isFile,
    required super.sender,
  });

  factory MessageModel.fromJson(Map data) {
    return MessageModel(
      id: data['id'],
      sender: data['sender'],
      date: DateTime.parse(data['created_at']),
      isFile: false,
      type: data['type'],
      message: data['message'],
      chatId: convertStringToInt(data['chat_id']),
    );
  }
}
