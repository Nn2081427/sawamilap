import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/chat/data/data_source/ChatRemoteDataSources.dart';
import 'package:swamiil/features/chat/domain/repos/chat_repository.dart';
import '../models/chat_model.dart';
import '../models/message_model.dart';

class ChatRepositoryImpl implements ChatRepository {
  @override
  Future<Either<DioException, bool>> createMessage(
      dynamic data) async {
    return await ChatRemoteDataSources.createMessage(data);
  }

  @override
  Future<Either<DioException, ChatModel>> getChatDetails(
      Map<String, dynamic> data) async {
    return await ChatRemoteDataSources.getChatDetails(data);
  }



  @override
  Future<Either<DioException, List<ChatModel>>> getAllChats() async {
    return await ChatRemoteDataSources.getAllChats();
  }

  @override
  Future<Either<DioException, List<ChatModel>>> getCurrentChats() {
    return ChatRemoteDataSources.getCurrentChats();
  }
}
