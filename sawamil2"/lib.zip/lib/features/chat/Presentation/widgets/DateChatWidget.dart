// date_chat_widget.dart
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/features/chat/domain/entity/message_entity.dart';

class DateChatWidget extends StatelessWidget {
  const DateChatWidget({super.key, required this.messageEntity});
  final MessageEntity messageEntity;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: Colors.grey.shade200,
      ),
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 0.5.h),
      margin: EdgeInsets.symmetric(vertical: 1.h),
      child: Text(
        messageEntity.date.toString().split(' ').first,
        style: TextStyle(fontSize: 10.sp, color: Colors.black),
      ),
    );
  }
}
