import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/chat/Presentation/cubits/chat_cubit/chat_cubit.dart';
import 'package:swamiil/features/chat/Presentation/screens/chat_screen.dart';
import 'package:swamiil/features/chat/Presentation/widgets/ChatItemWidget.dart';
import 'package:swamiil/features/chat/Presentation/widgets/ChatSectionTitleWidget.dart';
import 'package:swamiil/features/chat/Presentation/widgets/EmptyChatWidget.dart';

class ChatLastChatsSectionWidget extends StatefulWidget {
  final ChatsLoadedState state;

  const ChatLastChatsSectionWidget({required this.state});

  @override
  State<ChatLastChatsSectionWidget> createState() => _ChatLastChatsSectionWidgetState();
}

class _ChatLastChatsSectionWidgetState extends State<ChatLastChatsSectionWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ChatSectionTitleWidget(title: "Last Chats".tr()),
        const SizedBox(height: 10),
        if (widget.state.isAllChatsLoading)
          Center(
            child: ShimmerWidget(
              width: double.infinity,
              height: 10.h,
              numOfShimmer: 5,
            ),
          )
        else if (widget.state.allChatsError != null)
          Text(widget.state.allChatsError!)
        else if (widget.state.allChats.isEmpty)
          const EmptyChatWidget()
        else
          ...widget.state.allChats
              .map((chat) => ChatItemWidget(chat: chat, isActive: false))
              .toList(),
      ],
    );
  }
}
