import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';

class ChatMessageWidget extends StatelessWidget {
  const ChatMessageWidget({
    super.key,
    required this.isActive,
    required this.imagePath,
    required this.message,
    required this.userName,
    required this.dateText,
    required this.chatEntity,
  });

  final bool isActive;
  final String imagePath;
  final String userName;
  final String message;
  final String dateText;
  final ChatEntity chatEntity;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: isActive ? AppColors.opcityOrange : AppColors.textFieldBgColor,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomImageCacheProvider(
                  borderRadius: 50, imageUrl: imagePath, width: 55, height: 55),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    userName,
                    style: Fonts.textBlack18
                        .copyWith(fontSize: 15, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    height: 3,
                  ),
                  if (chatEntity.lastMessage?.type == 'text')
                    SizedBox(
                      width: 45.w,
                      child: Text(
                        message,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: Fonts.textSplash14.copyWith(
                          color: Colors.grey,
                          fontWeight: FontWeight.w500,
                          fontSize: 13,
                        ),
                      ),
                    )
                  else if (chatEntity.lastMessage?.type == 'image')
                    Row(
                      children: [
                        Text(
                          "تم ارسال مرفق",
                          style: Fonts.textSplash14.copyWith(
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    )
                  else
                    Text(
                      "لا يوجد رسائل",
                      style: Fonts.textSplash14.copyWith(
                        color: Colors.grey,
                        fontWeight: FontWeight.w500,
                        fontSize: 13,
                      ),
                    ),
                ],
              ),
            ],
          ),
          Spacer(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              chatEntity.lastMessage != null
                  ? Align(
                      alignment: Alignment.topRight,
                      child: Text(
                        getDiffTime(chatEntity.lastMessage!.date!),
                        style: Fonts.textSplash14.copyWith(
                          color: Colors.grey,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    )
                  : Container(),
              if (isActive) const SizedBox(height: 10),
              if (isActive)
                if (chatEntity.unReadCount != 0)
                  Container(
                    width: 22,
                    height: 22,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    decoration: BoxDecoration(
                        color: Colors.orangeAccent, shape: BoxShape.circle),
                    child: Center(
                      child: Text(
                        chatEntity.unReadCount.toString(),
                        style: Fonts.textSplash14.copyWith(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
            ],
          )
        ],
      ),
    );
  }
}
