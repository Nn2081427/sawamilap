import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/utilies/ImagePickerUtil.dart';
import 'package:swamiil/core/widgets/img_preview_widget.dart';
import 'package:swamiil/core/widgets/text_field.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';
import 'package:swamiil/main.dart';
import 'dart:io';

import '../../../../core/helper_function/prefs.dart';

class SendMessageWidget extends StatefulWidget {
  const SendMessageWidget({super.key, this.chatEntity});
  final ChatEntity? chatEntity;
  @override
  State<SendMessageWidget> createState() => _SendMessageWidgetState();
}

class _SendMessageWidgetState extends State<SendMessageWidget> {
  final TextEditingController _textController = TextEditingController();
  // bool _isSending = false;
  XFile? _selectedImage;
  String? _imagePath;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  // Future<void> _pickImage() async {
  //   if (_textController.text.isNotEmpty) {
  //     _textController.clear();
  //   }
  //
  //   final result = await ImagePickerUtil.showImageSourcePicker(
  //     context: context,
  //     imageQuality: 70,
  //   );
  //
  //   if (result != null) {
  //     setState(() {
  //       _selectedImage = result.xFile;
  //       _imagePath = result.path;
  //     });
  //   }
  // }

  // void _clearSelectedImage() {
  //   setState(() {
  //     _selectedImage = null;
  //     _imagePath = null;
  //   });
  // }

  void _sendMessage() {
    //  if (_isSending) return;

    // if (_selectedImage != null && _imagePath != null) {
    //   talker.info('Sending image: $_imagePath');
    //   context.read<MessagesCubit>().sendImageMessage(
    //       chatId: context.read<MessagesCubit>().currentChat!.id,
    //       imageFile: _selectedImage!);
    //
    //   // Clear the selected image after sending
    //   _clearSelectedImage();
    //   return;
    // }

    // Otherwise, try to send text
    final text = _textController.text.trim();
    talker.info('Sending text: $text');
    if (text.isNotEmpty) {
      talker.info('Sending message: $text');
      String isUser = sharedPreferences.getString('user_type')=='user'?"user":"supplier";
      context.read<MessagesCubit>().sendMessage({
        "message": text,
        "chat_id": context.read<MessagesCubit>().currentChat!.id,
        "type": "text",
        "sender": isUser,
      });
      _textController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<MessagesCubit, MessagesState>(
      listener: (context, state) {
        if (state is MessageSent) {
          //      setState(() => _isSending = false);
        } else if (state is MessageError) {
          //   setState(() => _isSending = false);
        }
      },
      child: Column(
        children: [
          // if (_selectedImage != null)
          //   Container(
          //     padding: EdgeInsets.symmetric(vertical: 0.8.h, horizontal: 2.w),
          //     color: Colors.grey[100],
          //     child: Row(
          //       children: [
          //         Expanded(
          //           child: Stack(
          //             alignment: Alignment.topRight,
          //             children: [
          //               Container(
          //                 height: 15.h,
          //                 decoration: BoxDecoration(
          //                   borderRadius: BorderRadius.circular(8),
          //                   image: DecorationImage(
          //                     image: FileImage(File(_selectedImage!.path)),
          //                     fit: BoxFit.cover,
          //                   ),
          //                 ),
          //               ),
          //               GestureDetector(
          //                 onTap: _clearSelectedImage,
          //                 child: Container(
          //                   margin: EdgeInsets.all(4),
          //                   padding: EdgeInsets.all(4),
          //                   decoration: BoxDecoration(
          //                     color: Colors.black.withOpacity(0.6),
          //                     shape: BoxShape.circle,
          //                   ),
          //                   child: Icon(
          //                     Icons.close,
          //                     color: Colors.white,
          //                     size: 16,
          //                   ),
          //                 ),
          //               ),
          //             ],
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          Container(
            padding: EdgeInsets.symmetric(vertical: 0.8.h, horizontal: 2.w),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 1,
                  blurRadius: 3,
                  offset: const Offset(0, -1),
                ),
              ],
            ),
            child: SafeArea(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(
                      Icons.attachment,
                      color: _selectedImage != null
                          ? Theme.of(context).primaryColor
                          : Colors.grey,
                    ),
                    //   onPressed: _isSending ? null : _pickImage,
                    onPressed: ()async{
                      final imageResult = await ImagePickerUtil.showImageSourcePicker(
                        context: context,
                        onLoading: (_) {},
                      );
                      if(imageResult!=null){
                        navP(ImagePreviewWidget(showSendButton: true,img: XFile(imageResult!.path),));
                      }

                    },
                  ),
                  Expanded(
                    child: TextFieldWidget(
                      controller: _textController,
                      hintText: _selectedImage != null
                          ? "Can't type when image is selected"
                          : "type_a_message".tr(),
                      //    readOnly: _isSending || _selectedImage != null,
                      maxLines: 4,
                      minLines: 1,
                      onFieldSubmitted: (text) =>
                          _selectedImage == null ? _sendMessage() : null,
                      onChange: (text) {},
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      // color: _isSending
                      //     ? Colors.grey.shade300
                      //     : Theme.of(context).primaryColor,
                      borderRadius: BorderRadius.circular(25),
                    ),
                    child: IconButton(
                      icon:
                          // _isSending
                          //     ? const SizedBox(
                          //         width: 20,
                          //         height: 20,
                          //         child: CircularProgressIndicator(
                          //           strokeWidth: 2,
                          //           valueColor:
                          //               AlwaysStoppedAnimation<Color>(Colors.white),
                          //         ),
                          //       )
                          //     :
                          const Icon(
                        Icons.send,
                        color: Colors.white,
                      ),
                      onPressed: _selectedImage == null ||
                              _textController.text.trim().isEmpty
                          ? _sendMessage
                          : null,
                      // onPressed: _isSending
                      //     ? null
                      //     : (_selectedImage != null ||
                      //             _textController.text.trim().isNotEmpty)
                      //         ? _sendMessage
                      //         : null,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
