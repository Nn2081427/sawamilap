import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';

class EmptyChatWidget extends StatelessWidget {
  const EmptyChatWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          EmptyAnimation(
            height: 10.h,
            width: double.infinity,
            title: "",
            gif: Assets.emptyListLottie,
          ),
          SizedBox(height: 3.h),
          Text(
            "no_previous_chats".tr(),
            style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
