
import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/font_style.dart';

class ChatSectionTitleWidget extends StatelessWidget {
  final String title;

  const ChatSectionTitleWidget({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
    );
  }
}