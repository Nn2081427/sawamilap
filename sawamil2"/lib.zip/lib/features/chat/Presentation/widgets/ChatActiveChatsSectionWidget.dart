import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/chat/Presentation/cubits/chat_cubit/chat_cubit.dart';
import 'package:swamiil/features/chat/Presentation/screens/chat_screen.dart';
import 'package:swamiil/features/chat/Presentation/widgets/ChatItemWidget.dart';
import 'package:swamiil/features/chat/Presentation/widgets/ChatSectionTitleWidget.dart';

class ChatActiveChatsSectionWidget extends StatefulWidget {
  final ChatsLoadedState state;

  const ChatActiveChatsSectionWidget({required this.state});

  @override
  State<ChatActiveChatsSectionWidget> createState() => _ChatActiveChatsSectionWidgetState();
}

class _ChatActiveChatsSectionWidgetState extends State<ChatActiveChatsSectionWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ChatSectionTitleWidget(title: "Active Chats".tr()),
        const SizedBox(height: 10),
        if (widget.state.isCurrentChatsLoading)
          Center(child: ShimmerWidget(width: double.infinity, height: 10.h))
        else if (widget.state.currentChatsError != null)
          Text(widget.state.currentChatsError!)
        else if (widget.state.currentChats.isEmpty)
          const SizedBox.shrink()
        else
          ...widget.state.currentChats
              .map((chat) => ChatItemWidget(chat: chat, isActive: true))
              .toList(),
      ],
    );
  }
}
