// message_widget.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/ImagesPreviewWidget.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/core/widgets/img_preview_widget.dart';
import 'package:swamiil/features/chat/Presentation/cubits/chat_cubit/chat_cubit.dart';
import 'package:swamiil/features/chat/domain/entity/message_entity.dart';

class MessageWidget extends StatelessWidget {
  const MessageWidget({super.key, required this.messageEntity});
  final MessageEntity messageEntity;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 1.h),
      //margin: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(1.w),
      ),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Row(
            mainAxisAlignment: messageEntity.fromMe()
                ? MainAxisAlignment.start
                : MainAxisAlignment.end,
            children: [
              // messageEntity.fromMe()
              //     ? CustomImageCacheProvider(
              //         imageUrl:
              //             context.read<ChatCubit>().currentChat!.user!.image!,
              //         width: 12.w,
              //         borderRadius: 50,
              //         height: 12.w)
              //     : const SizedBox.shrink(),
              SizedBox(
                width: 2.w,
              ),
              Container(
                padding: EdgeInsets.only(bottom: 1.h),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: messageEntity.fromMe()
                      ? MainAxisAlignment.start
                      : MainAxisAlignment.end,
                  children: [
                    if (messageEntity.type == 'text')
                      Center(
                        child: Container(
                          constraints: BoxConstraints(
                            maxWidth: 65.w,
                            minWidth: 20.w,
                          ),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(2.w),
                            color: messageEntity.fromMe()
                                ? Colors.grey.shade100
                                : AppColors.mainColor,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              messageEntity.message,
                              style: messageEntity.fromMe()
                                  ? Fonts.textBlack18
                                  : Fonts.textWhite18,
                            ),
                          ),
                        ),
                      ),
                    if (messageEntity.type == 'image')
                      Row(
                        mainAxisAlignment: messageEntity.fromMe()
                            ? MainAxisAlignment.start
                            : MainAxisAlignment.end,
                        children: [
                          InkWell(
                            onTap: () {
                              navP(ImagesPreviewWidget(images: [
                                messageEntity.finalImage,
                              ]));
                            },
                            child: Hero(
                              tag: messageEntity.message,
                              child: CustomImageCacheProvider(
                                imageUrl: messageEntity.finalImage,
                                width: 60.w,
                                height: 60.w,
                                borderRadius: 15,
                              ),
                            ),
                            // child: Container(
                            //   constraints: BoxConstraints(
                            //     maxWidth: 60.w,
                            //     maxHeight: 22.h,
                            //   ),
                            //   decoration: BoxDecoration(
                            //     image: DecorationImage(
                            //       image: NetworkImage(messageEntity.message),
                            //       fit: BoxFit.cover,
                            //     ),
                            //   ),
                            // ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
