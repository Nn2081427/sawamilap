// messages_widget.dart
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/Presentation/widgets/MessageWidget.dart';

import 'DateChatWidget.dart';

class MessagesWidget extends StatelessWidget {
  const MessagesWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MessagesCubit, MessagesState>(
      builder: (context, state) {
        if (state is! ChatLoaded) return Container();

        return Expanded(
          child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              reverse: true,
              itemCount: state.chat.messages.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  child: Column(
                    children: [
                      if ((index == state.chat.messages.length - 1))
                        DateChatWidget(
                            messageEntity: state.chat.messages[index]),
                      MessageWidget(messageEntity: state.chat.messages[index]),
                      Padding(
                        padding: EdgeInsets.only(right: 14.w, left: 8.w),
                        child: Align(
                            alignment: state.chat.messages[index].fromMe()
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Text(
                                getDiffTime(state.chat.messages[index].date),
                                style: Fonts.text14Black.copyWith(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w400,
                                    color: Colors.grey.shade600))),
                      ),
                      if (((index != 0 &&
                          ((state.chat.messages[index].date
                                  .toLocal()
                                  .toString()
                                  .split(' ')
                                  .first)) !=
                              (state.chat.messages[index - 1].date
                                  .toLocal()
                                  .toString()
                                  .split(' ')
                                  .first))))
                        DateChatWidget(
                            messageEntity: state.chat.messages[index - 1]),
                      // Row(
                      //   mainAxisAlignment: state.chat.messages[index].fromMe()
                      //       ? MainAxisAlignment.start
                      //       : MainAxisAlignment.start,
                      //   children: [
                      //     Text(convertDateToStringHMS(
                      //         state.chat.messages[index].date)),
                      //   ],
                      // ),
                    ],
                  ),
                );
                // state.chat.messages.map((message) {

                // }).toList();
              }),
        );
      },
    );
  }
}
