import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/Presentation/widgets/chat_message_widget.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';

class ChatItemWidget extends StatefulWidget {
  final ChatEntity chat;
  final bool isActive;

  const ChatItemWidget({required this.chat, required this.isActive});

  @override
  State<ChatItemWidget> createState() => _ChatItemWidgetState();
}

class _ChatItemWidgetState extends State<ChatItemWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: GestureDetector(
        onTap: () => context.read<MessagesCubit>().goToMessagePage(widget.chat.orderId),
        child: ChatMessageWidget(
          chatEntity: widget.chat,
          isActive: widget.isActive,
          userName: "${widget.chat.supplier?.firstName ?? ""} ${widget.chat.supplier?.lastName ?? ""}",
          message: widget.chat.lastMessage?.message ?? 
              (widget.isActive ? "" : 'no_messages_yet'.tr()),
          imagePath: widget.chat.supplier?.image ?? 
              (widget.isActive ? Assets.chatUser1 : ""),
          dateText: 'Recently',
        ),
      ),
    );
  }
}
