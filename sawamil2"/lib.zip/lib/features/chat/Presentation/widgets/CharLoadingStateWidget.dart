import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/features/chat/Presentation/widgets/ChatSectionTitleWidget.dart';

class CharLoadingStateWidget extends StatefulWidget {
  const CharLoadingStateWidget({super.key});

  @override
  State<CharLoadingStateWidget> createState() => _CharLoadingStateWidgetState();
}

class _CharLoadingStateWidgetState extends State<CharLoadingStateWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 30),
          ChatSectionTitleWidget(title: "Active Chats".tr()),
          const SizedBox(height: 10),
          const Center(child: CircularProgressIndicator()),
          SizedBox(height: 5.h),
          ChatSectionTitleWidget(title: "Last Chats".tr()),
          const SizedBox(height: 10),
          const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}