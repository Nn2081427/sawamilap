import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/core/widgets/CustomImageCacheProvider.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/Presentation/widgets/MessagesWidget.dart';
import 'package:swamiil/features/chat/Presentation/widgets/SendMessageWidget.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';
import 'package:swamiil/features/rate/presentation/cubits/supplier_profile_cubit/supplier_profile_cubit.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/screens/supplier_profile_view.dart';
import 'package:swamiil/main.dart';

import '../widgets/ShimmerMessageWidget.dart';

class MessageScreen extends StatelessWidget {
  const MessageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocListener<MessagesCubit, MessagesState>(
      listener: (context, state) {
        if (state is ChatError) {
          showToast(state.message);
        } else if (state is MessageError) {
          showToast(state.message);
        } else if (state is MessageSent) {}
      },
      child: BlocBuilder<MessagesCubit, MessagesState>(
        builder: (context, state) {
          return AnnotatedRegion(
            value: lightBarColor(),
            child: SafeArea(
              top: true,
              bottom: false,
              child: Scaffold(
                body: _buildBody(state, context),
              ),
            ),
          );
        },
      ),
    );
  }
}

Widget _buildBody(MessagesState state, BuildContext context) {
  var chatEntity = context.read<MessagesCubit>().currentChat;

  if (state is ChatInitial || state is ChatLoading) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 5.h),
      child: SingleChildScrollView(
        child: Column(
          children: List.generate(
              12,
              (index) => ShimmerMessageWidget(
                    isMe: index % 2 == 0,
                  )),
        ),
      ),
    );
  } else if (state is ChatError) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(state.message),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              context.read<MessagesCubit>().loadChatDetails();
            },
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  } else if (state is ChatLoaded || state is ChatInitial) {
    return Column(
      children: [
        MessageScreenHeaderWidget(chatEntity: chatEntity),
        Expanded(
          child: Column(
            children: [
              SizedBox(height: 1.h),
              const MessagesWidget(),
            ],
          ),
        ),
        if (state is MessageSending)
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: LinearProgressIndicator(),
          ),
        SendMessageWidget(
          chatEntity: context.read<MessagesCubit>().currentChat,
        ),
      ],
    );
  }

  // Handle other states like ChatsLoadedState if needed
  return SizedBox();
}

class MessageScreenHeaderWidget extends StatelessWidget {
  const MessageScreenHeaderWidget({
    super.key,
    required this.chatEntity,
  });

  final ChatEntity? chatEntity;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 5.w, vertical: 1.2.h),
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.5.h),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () {
              navPop();
            },
            icon: const Icon(
              Icons.arrow_back_ios,
            ),
            iconSize: 20.sp,
          ),
          GestureDetector(
            onTap: () {
              context.read<SupplierPublicProfileCubit>().getSupplierProfile(
                  supplierId: chatEntity?.supplier?.id ?? 0);
              navP(SupplierPublicProfileView());
            },
            child: CustomImageCacheProvider(
              imageUrl: chatEntity?.supplier?.image ?? "",
              width: 14.w,
              height: 14.w,
              borderRadius: 50,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              style: Fonts.text16Black,
              "${chatEntity!.supplier?.firstName ?? ""} ${chatEntity?.supplier?.lastName ?? ""}"
                      .trim()
                      .isNotEmpty
                  ? "${chatEntity?.supplier?.firstName ?? ""} ${chatEntity?.supplier?.lastName ?? ""}"
                  : 'Chat',
            ),
          ),
        ],
      ),
    );
  }
}
