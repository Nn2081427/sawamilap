import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/features/chat/Presentation/cubits/chat_cubit/chat_cubit.dart';
import 'package:swamiil/features/chat/Presentation/widgets/CharLoadingStateWidget.dart';

import '../../../../core/widgets/pull_to_refresh_widget.dart';
import '../widgets/ChatActiveChatsSectionWidget.dart'
    show ChatActiveChatsSectionWidget;
import '../widgets/ChatLastChatsSectionWidget.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      bottom: false,
      child: Scaffold(
        appBar: AppBarWidget(title: "Chats".tr()),
        body: BlocBuilder<ChatCubit, ChatState>(
          buildWhen: (previous, current) => current is ChatsLoadedState,
          builder: (context, state) {
            if (state is! ChatsLoadedState) {
              return const CharLoadingStateWidget();
            }

            return Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: SmartRefresher(
                controller: _refreshController,
                header: CustomRefreshHeader(height: 15.h),
                onRefresh: () {
                  context.read<ChatCubit>().loadInitialChats();
                  _refreshController.refreshCompleted();
                },
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      state.currentChats.isNotEmpty
                          ? ChatActiveChatsSectionWidget(state: state)
                          : const SizedBox.shrink(),
                      SizedBox(height: 5.h),
                      ChatLastChatsSectionWidget(state: state),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
