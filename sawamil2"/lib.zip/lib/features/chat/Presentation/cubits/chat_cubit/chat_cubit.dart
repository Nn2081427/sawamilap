


import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';
import 'package:swamiil/features/chat/domain/use_case/chat_use_case.dart';
part 'chat_state.dart';

class ChatCubit extends Cubit<ChatState> {
  final ChatUseCase chatUseCase;

  List<ChatEntity> allChats = [];
  List<ChatEntity> currentChats = [];
  ChatEntity? currentChat;

  ChatCubit(this.chatUseCase) : super(ChatInitial());

  Future<void> loadInitialChats() async {
    emit(const ChatsLoadedState(
      isCurrentChatsLoading: true,
      isAllChatsLoading: true,
    ));

    // Load both concurrently
    await Future.wait([
      getCurrentChats(),
      getAllChats(),
    ]);
  }

  Future<void> getCurrentChats() async {
    if (state is! ChatsLoadedState) {
      emit(GetCurrentChatsLoading());
    } else {
      emit((state as ChatsLoadedState).copyWith(isCurrentChatsLoading: true));
    }

    try {
      final result = await chatUseCase.getCurrentChats();
      result.fold(
        (failure) {
          if (state is ChatsLoadedState) {
            emit((state as ChatsLoadedState).copyWith(
              isCurrentChatsLoading: false,
              currentChatsError:
                  failure.message ?? 'Failed to load current chats',
            ));
          } else {
            emit(GetCurrentChatsError(
                failure.message ?? 'Failed to load current chats'));
          }
        },
        (chat) {
          currentChats = chat;
          if (state is ChatsLoadedState) {
            emit((state as ChatsLoadedState).copyWith(
              isCurrentChatsLoading: false,
              currentChats: chat,
              currentChatsError: null,
            ));
          } else {
            emit(GetCurrentChatsSuccess(chat));
          }
        },
      );
    } catch (e) {
      if (state is ChatsLoadedState) {
        emit((state as ChatsLoadedState).copyWith(
          isCurrentChatsLoading: false,
          currentChatsError: 'An error occurred',
        ));
      } else {
        emit(GetCurrentChatsError('An error occurred'));
      }
    }
  }

  Future<void> getAllChats() async {
    // If we're not in ChatsLoadedState, emit individual states for backward compatibility
    if (state is! ChatsLoadedState) {
      emit(GetAllChatsLoading());
    } else {
      emit((state as ChatsLoadedState).copyWith(isAllChatsLoading: true));
    }

    try {
      final result = await chatUseCase.getAllChats();
      result.fold(
        (failure) {
          if (state is ChatsLoadedState) {
            emit((state as ChatsLoadedState).copyWith(
              isAllChatsLoading: false,
              allChatsError: failure.message ?? 'Failed to load all chats',
            ));
          } else {
            emit(GetAllChatsError(
                failure.message ?? 'Failed to load all chats'));
          }
        },
        (chat) {
          allChats = chat;
          if (state is ChatsLoadedState) {
            emit((state as ChatsLoadedState).copyWith(
              isAllChatsLoading: false,
              allChats: chat,
              allChatsError: null,
            ));
          } else {
            emit(GetAllChatsSuccess(chat));
          }
        },
      );
    } catch (e) {
      if (state is ChatsLoadedState) {
        emit((state as ChatsLoadedState).copyWith(
          isAllChatsLoading: false,
          allChatsError: 'An error occurred',
        ));
      } else {
        emit(GetAllChatsError('An error occurred'));
      }
    }
  }

  // Helper method to navigate to a specific chat
}
