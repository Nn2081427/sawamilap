// chat_state.dart
part of 'chat_cubit.dart';

abstract class ChatState extends Equatable {
  const ChatState();

  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {}

class ChatLoading extends ChatState {}



// Individual states for backward compatibility
class GetCurrentChatsLoading extends ChatState {}

class GetCurrentChatsSuccess extends ChatState {
  final List<ChatEntity> chatList;
  const GetCurrentChatsSuccess(this.chatList);

  @override
  List<Object> get props => [chatList];
}

class GetCurrentChatsError extends ChatState {
  final String message;
  const GetCurrentChatsError(this.message);

  @override
  List<Object> get props => [message];
}

class GetAllChatsLoading extends ChatState {}

class GetAllChatsSuccess extends ChatState {
  final List<ChatEntity> chatList;
  const GetAllChatsSuccess(this.chatList);

  @override
  List<Object> get props => [chatList];
}

class GetAllChatsError extends ChatState {
  final String message;
  const GetAllChatsError(this.message);

  @override
  List<Object> get props => [message];
}

// Combined state for managing both chat lists
class ChatsLoadedState extends ChatState {
  final List<ChatEntity> currentChats;
  final List<ChatEntity> allChats;
  final bool isCurrentChatsLoading;
  final bool isAllChatsLoading;
  final String? currentChatsError;
  final String? allChatsError;

  const ChatsLoadedState({
    this.currentChats = const [],
    this.allChats = const [],
    this.isCurrentChatsLoading = false,
    this.isAllChatsLoading = false,
    this.currentChatsError,
    this.allChatsError,
  });

  ChatsLoadedState copyWith({
    List<ChatEntity>? currentChats,
    List<ChatEntity>? allChats,
    bool? isCurrentChatsLoading,
    bool? isAllChatsLoading,
    String? currentChatsError,
    String? allChatsError,
  }) {
    return ChatsLoadedState(
      currentChats: currentChats ?? this.currentChats,
      allChats: allChats ?? this.allChats,
      isCurrentChatsLoading:
          isCurrentChatsLoading ?? this.isCurrentChatsLoading,
      isAllChatsLoading: isAllChatsLoading ?? this.isAllChatsLoading,
      currentChatsError: currentChatsError ?? this.currentChatsError,
      allChatsError: allChatsError ?? this.allChatsError,
    );
  }

  @override
  List<Object?> get props => [
        currentChats,
        allChats,
        isCurrentChatsLoading,
        isAllChatsLoading,
        currentChatsError,
        allChatsError,
      ];
}
