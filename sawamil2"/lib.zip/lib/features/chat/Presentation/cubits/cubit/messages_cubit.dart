import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:equatable/equatable.dart';
import 'package:share_plus/share_plus.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/chat/Presentation/screens/message_screen.dart';
import 'package:swamiil/features/chat/data/models/message_model.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';
import 'package:swamiil/features/chat/domain/entity/message_entity.dart';
import 'package:swamiil/features/chat/domain/use_case/chat_use_case.dart';
import 'package:swamiil/main.dart';

import '../../../../../core/helper_function/prefs.dart';

part 'messages_state.dart';

class MessagesCubit extends Cubit<MessagesState> {
  MessagesCubit({required this.chatUseCase}) : super(MessagesInitial());
  final ChatUseCase chatUseCase;

  ChatEntity? currentChat;
  int? orderId;

  Future<void> loadChatDetails({int? orderIdNoti}) async {
    emit(ChatLoading());
    try {
      if (orderIdNoti != null) {
        orderId = orderIdNoti;
      }
      Map<String, dynamic> data = {};
      data['order_id'] = orderId;
      final result = await chatUseCase.getChatDetails(data);
      result.fold(
        (failure) => emit(ChatError(failure.message ?? 'Failed to load chat')),
        (chat) {
          talker.info('Chat loaded successfully${chat.id}');
          currentChat = chat;
          emit(ChatLoaded(chat));
        },
      );
    } catch (e) {
      emit(ChatError('An error occurred'));
    }
  }

  Future<void> sendImageMessage({
    required XFile imageFile,
    required int chatId,
  }) async {
    if (currentChat == null) return;

    emit(MessageSending());
    try {
      talker.info('Sending image: ${imageFile.path}');
      String isUser = sharedPreferences.getString('user_type') == 'user'
          ? "user"
          : "supplier";
      Map<String, dynamic> formData = {
        'chat_id': chatId,
        'type': 'image',
        'sender': isUser,
        'message': await MultipartFile.fromFile(
          imageFile.path,
        ),
      };
      talker.info('Uploading image: ${imageFile.path}');
      MessageModel messageModel = MessageModel(
        chatId: chatId,
        type: 'image',
        sender: isUser,
        id: 0,
        date: DateTime.now(),
        message: imageFile.path,
        isFile: true,
      );
      currentChat!.messages.insert(0, messageModel);
      emit(MessageSent(messageModel));
      emit(ChatLoaded(currentChat!));

      formData.entries.forEach((element) {
        talker.info('${element.key}: ${element.value}');
      });
      final result = await chatUseCase.createMessage(formData);

      result.fold(
        (failure) {
          // navPop();

          talker.error('Failed to send image: ${failure.message}');
          emit(MessageError(failure.message ?? 'Failed to send image'));
        },
        (message) {
          talker.info('Image sent successfully');
        },
      );
    } catch (e) {
      navPop();
      talker.error('Error sending image: $e');
      emit(MessageError('An error occurred while sending image'));
    }
  }

  Future<void> sendMessage(Map<String, dynamic> data) async {
    if (currentChat == null) return;

//    emit(MessageSending());
    try {
      talker.info('Sending message: ${data["message"]}');
      String isUser = sharedPreferences.getString('user_type') == 'user'
          ? "user"
          : "supplier";
      MessageModel messageModel = MessageModel(
        chatId: currentChat!.id,
        type: 'text',
        sender: isUser,
        id: 0,
        date: DateTime.now(),
        message: data['message'],
        isFile: false,
      );
      currentChat!.messages.insert(0, messageModel);
      emit(MessageSent(messageModel));
      emit(ChatLoaded(currentChat!));
      final result = await chatUseCase.createMessage(data);
      result.fold(
        (failure) {
          navPop();
          emit(MessageError(failure.message ?? 'Failed to send message'));
        },
        (message) {
          talker.info('Message sent successfully' + message.toString());
        },
      );
    } catch (e) {
      navPop();
      emit(MessageError('An error occurred'));
    }
  }

  // Helper method to navigate to a specific chat
  void goToMessagePage(int orderId) {
    currentChat = null;
    this.orderId = orderId;
    loadChatDetails();
    navP(MessageScreen(),then: (val){
      currentChat = null;
    });
  }

  bool checkMessageOfThisChat(int chatId) {
    return currentChat?.id==chatId;
  }

  void addOneMessage(MessageModel messageModel) {
    currentChat!.messages.insert(0, messageModel);
    emit(MessageSent(messageModel));
    emit(ChatLoaded(currentChat!));
  }
}
