part of 'messages_cubit.dart';

sealed class MessagesState extends Equatable {
  const MessagesState();

  @override
  List<Object> get props => [];
}

final class MessagesInitial extends MessagesState {}

final class ChatInitial extends MessagesState {}
final class ChatLoading extends MessagesState {}

final class ChatLoaded extends MessagesState {
  final ChatEntity chat;
  const ChatLoaded(this.chat);
  @override
  List<Object> get props => [chat];
}

final class ChatError extends MessagesState {
  final String message;
  const ChatError(this.message);
  @override
  List<Object> get props => [message];
}

final class MessageSent extends MessagesState {
  final MessageEntity message;
  const MessageSent(this.message);
  @override
  List<Object> get props => [message];
}

final class MessageSending extends MessagesState {}

final class MessageError extends MessagesState {
  final String message;
  const MessageError(this.message);
  @override
  List<Object> get props => [message];
}
