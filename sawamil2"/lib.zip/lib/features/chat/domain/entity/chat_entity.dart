import 'package:swamiil/features/chat/domain/entity/message_entity.dart';
import '../../../auth_supplier/domain/entities/supplier_entity.dart';
import '../../../user_auth/Domain/entities/user_entity.dart';

class ChatEntity {
  int id;
  int orderId;
  int userId;
  int supplierId;
  DateTime createdAt;
  MessageEntity? lastMessage;
  int unReadCount;
  UserEntity? user;
  SupplierEntity? supplier;
  List<MessageEntity> messages;

  ChatEntity({
    required this.id,
    required this.orderId,
    required this.userId,
    required this.supplierId,
    required this.createdAt,
    required this.lastMessage,
    required this.unReadCount,
    required this.user,
    required this.supplier,
    required this.messages,
  });
}
