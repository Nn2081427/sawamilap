// message_entity.dart
import 'package:equatable/equatable.dart';
import 'package:image_picker/image_picker.dart';

import '../../../../core/helper_function/prefs.dart';

class MessageEntity extends Equatable {
  final int id;
  final int chatId;
  final String type;
  final String message;
  final String? sender;
  final DateTime date;
  final bool isFile;

  const MessageEntity({
    required this.id,
    required this.date,
    required this.type,
    required this.message,
    required this.isFile,
    required this.sender,
    required this.chatId,
  });

  @override
  List<Object?> get props => [id, type, sender, message, chatId];

  bool fromMe() {
    String isUser = sharedPreferences.getString('user_type') == 'user'
        ? "user"
        : "supplier";
    return sender != isUser;
  }

  dynamic finalImage() {
    return isFile ? XFile(message) : message;
  }
}
