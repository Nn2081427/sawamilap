import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';
import 'package:swamiil/features/chat/domain/entity/message_entity.dart';


abstract class ChatRepository {
  Future<Either<DioException, ChatEntity>> getChatDetails(Map<String, dynamic> data);
  Future<Either<DioException, bool>> createMessage(Map<String, dynamic> data);
  Future<Either<DioException, List<ChatEntity>>> getAllChats();
    Future<Either<DioException, List<ChatEntity>>> getCurrentChats();

}