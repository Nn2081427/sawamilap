import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/chat/domain/entity/chat_entity.dart';
import 'package:swamiil/features/chat/domain/repos/chat_repository.dart';

class ChatUseCase {
  final ChatRepository repository;

  ChatUseCase({required this.repository});


  Future<Either<DioException, bool>> createMessage(
      dynamic data) async {
    return await repository.createMessage(data);
  }


  Future<Either<DioException, ChatEntity>> getChatDetails(
      Map<String, dynamic> data) async {
    return await repository.getChatDetails(data);
  }




  Future<Either<DioException, List<ChatEntity>>> getAllChats() async {
    return await repository.getAllChats();
  }


  Future<Either<DioException, List<ChatEntity>>> getCurrentChats() {
    return repository.getCurrentChats();
  }
}
