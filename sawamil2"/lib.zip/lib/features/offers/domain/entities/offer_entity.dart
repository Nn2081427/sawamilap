
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

import '../../../auth_supplier/domain/entities/supplier_entity.dart';



class OfferEntity {
  int? id;
  int? orderId;
  double price;
  String notes;
  int? supplierId;
  SupplierEntity? supplier;
  OrderEntity? orderEntity;

  OfferEntity({
    required this.id,
    required this.orderId,
    required this.price,
    required this.notes,
    required this.supplierId,
    required this.supplier,
    required this.orderEntity,
  });
}


