import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';

abstract class OffersRepo {
  Future<Either<DioException, List<OfferEntity>>> getOrderOffers(
      {required int orderId, required int pageKey});

  Future<Either<DioException, void>> acceptedOffers({required int offerId});

  Future<Either<DioException, void>> rejectedOffers({required int offerId});
  Future<Either<DioException, bool>> createOffer({
    required int orderId,
    required int price,
    required String description,
  });

  // get all offers
  Future<Either<DioException, List<OfferEntity>>> getAllOffers({
    required int pageKey,
  });
  // delete offer
  Future<Either<DioException, bool>> deleteOffer({
    required int offerId,
  });
}
