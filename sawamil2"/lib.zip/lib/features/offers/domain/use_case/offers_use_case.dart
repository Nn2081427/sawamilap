import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/offers/domain/repos/offer_repo.dart';

class OffersUseCase {
  final OffersRepo offersRepo;

  OffersUseCase({required this.offersRepo});

  Future<Either<DioException, List<OfferEntity>>> getOrderOffers(
      {required int orderId, required int pageKey}) {
    return offersRepo.getOrderOffers(orderId: orderId, pageKey: pageKey);
  }

  Future<Either<DioException, void>> acceptedOffers({required int offerId}) {
    return offersRepo.acceptedOffers(offerId: offerId);
  }

  Future<Either<DioException, void>> rejectedOffers({required int offerId}) {
    return offersRepo.rejectedOffers(offerId: offerId);
  }
  Future<Either<DioException, bool>> createOffer({
    required int orderId,
    required int price,
    required String description,
  }) async {
    return await offersRepo.createOffer(
      orderId: orderId,
      price: price,
      description: description,
    );
  }

  // get all offers
  Future<Either<DioException, List<OfferEntity>>> getAllOffers({required int pageKey}) async {
    return await offersRepo.getAllOffers(pageKey: pageKey);
  }

  // delete offer
  Future<Either<DioException, bool>> deleteOffer({
    required int offerId,
  }) async {
    return await offersRepo.deleteOffer(offerId: offerId);
  }
}
