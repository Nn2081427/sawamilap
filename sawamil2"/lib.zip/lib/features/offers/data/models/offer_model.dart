

import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/auth_supplier/data/models/supplier_model.dart';
import 'package:swamiil/features/orders/data/models/order_model.dart';

import '../../domain/entities/offer_entity.dart';

class OfferModel extends OfferEntity {
  OfferModel({required super.id, required super.orderId,
    required super.price, required super.notes,
    required super.supplierId, required super.supplier, required super.orderEntity});

  factory OfferModel.fromJson(Map<String, dynamic> json) {
    print(json);
    SupplierModel? supplierModel;
    if(json.containsKey('supplier')&&json['supplier']!=null){
      supplierModel = SupplierModel.fromJson(json['supplier']);
    }
    OrderModel? orderModel;
    if(json.containsKey('order')&&json['order']!=null){
      orderModel = OrderModel.fromJson(json['order']);
    }

    return OfferModel(
      id: json['id'],
      orderId: json['order_id'],
      price: convertDataToDouble(json['price']),
      notes: json['notes'],
      supplierId: json['supplier_id'],
      supplier: supplierModel,
      orderEntity: orderModel,
    );
  }

}

