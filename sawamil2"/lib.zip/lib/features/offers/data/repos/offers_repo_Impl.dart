import 'package:dartz/dartz.dart';
import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/offers/data/data_source/offers_remote_data_source.dart';
import 'package:swamiil/features/offers/data/models/offer_model.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/offers/domain/repos/offer_repo.dart';

import '../data_source/offers_remote_data_source.dart';

class OffersRepoImpl extends OffersRepo {
  final OffersRemoteDataSource offersRemoteDataSource;
  OffersRepoImpl(this.offersRemoteDataSource);

  @override
  Future<Either<DioException, List<OfferModel>>> getOrderOffers(
      {required int orderId, required int pageKey}) {
    return offersRemoteDataSource.getOrderOffers(orderId: orderId, pageKey: pageKey);
  }
  
  @override
  Future<Either<DioException, void>> acceptedOffers({required int offerId}) {
    return offersRemoteDataSource.acceptedOffers(offerId: offerId);
  }
  
  @override
  Future<Either<DioException, void>> rejectedOffers({required int offerId}) {
    return offersRemoteDataSource.rejectedOffers(offerId: offerId);
  }




  @override
  Future<Either<DioException, bool>> createOffer({
    required int orderId,
    required int price,
    required String description,
  }) async {
    return await offersRemoteDataSource.createOrder(
        orderId: orderId, price: price, description: description);
  }

  @override
  Future<Either<DioException, List<OfferModel>>> getAllOffers({required int pageKey}) async {
    return await offersRemoteDataSource.getAllOffers(pageKey: pageKey);
  }

  @override
  Future<Either<DioException, bool>> deleteOffer({required int offerId}) async {
    return await offersRemoteDataSource.deleteOffer(offerId: offerId);
  }
}
