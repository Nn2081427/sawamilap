import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';

import '../models/offer_model.dart';

class OffersRemoteDataSource {
  final ApiHandel apiHandel;
  OffersRemoteDataSource({required this.apiHandel});
  // create offers

  Future<Either<DioException, bool>> createOrder({
    required int orderId,
    required int price,
    required String description,
  }) async {
    var response = await apiHandel.post("supplier/create_offer",
        {"order_id": orderId, "price": price, "notes": description});
    return response.fold((l) => Left(l), (r) => Right(true));
  }

  // get All offers
  Future<Either<DioException, List<OfferModel>>> getAllOffers(
      {required int pageKey}) async {
    var response = await apiHandel.get(
      "supplier/get_offers",
      {
        "page": pageKey,
        //  "skip": 2,
      },
    );
    List<OfferModel> data = [];
    return response.fold((l) => Left(l), (r) {
      for (var i in r.data['data']) {
        data.add(OfferModel.fromJson(i));
      }
      return Right(data);
    });
  }

  // delete offer
  Future<Either<DioException, bool>> deleteOffer({required int offerId}) async {
    var response =
        await apiHandel.post("supplier/delete_offer", {"offer_id": offerId});
    return response.fold((l) => Left(l), (r) => Right(true));
  }

  Future<Either<DioException, List<OfferModel>>> getOrderOffers(
      {required int orderId, required int pageKey}) async {
    var response = await apiHandel
        .post('user/get_order_offers', {"order_id": orderId, "page": pageKey});
    return response.fold((l) => Left(l), (r) {
      List<OfferModel> data = [];
      for (var i in r.data['data']) {
        data.add(OfferModel.fromJson(i));
      }
      return Right(data);
    });
  }

  Future<Either<DioException, void>> acceptedOffers(
      {required int offerId}) async {
    var response = await apiHandel.post('user/accept_offer', {
      "offer_id": offerId,
    });
    return response.fold((l) => Left(l), (r) {
      return Right(null);
    });
  }

  Future<Either<DioException, void>> rejectedOffers(
      {required int offerId}) async {
    var response = await apiHandel.post('user/refuse_offer', {
      "offer_id": offerId,
    });
    return response.fold((l) => Left(l), (r) {
      return Right(null);
    });
  }
}
