

import '../../../domain/entities/offer_entity.dart';

class SupplierOffersState {}
  
class SupplierOffersInitial extends SupplierOffersState {}

class SupplierOffersLoading extends SupplierOffersState {}

class SupplierOffersError extends SupplierOffersState {
  final String message;
  SupplierOffersError({required this.message});
}

class SupplierOffersLoaded extends SupplierOffersState {
  final List<OfferEntity> offersList;
  SupplierOffersLoaded({ required this.offersList});
}
