import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/features/offers/Presentation/cubits/supplier_offers_cubit/supplier_offers_state.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/offers/domain/use_case/offers_use_case.dart';

class SupplierOffersCubit extends Cubit<SupplierOffersState> {
  SupplierOffersCubit({required this.useCases})
      : super(SupplierOffersInitial()) {
    pagingController.addPageRequestListener(_loadPage);
  }

  final OffersUseCase useCases;

  final PagingController<int, OfferEntity> pagingController =
      PagingController(firstPageKey: 1);

  List<OfferEntity> _offers = [];

  bool _isDisposed = false;

  Future<void> _loadPage(int pageKey) async {
    if (_isDisposed) return;
    emit(SupplierOffersLoading());

    final result = await useCases.getAllOffers(pageKey: pageKey);

    if (_isDisposed) return;

    result.fold(
      (failure) {
        if (!_isDisposed) {
          pagingController.error = failure.message ?? 'Unknown error';
        }
        emit(SupplierOffersError(message: failure.message ?? 'Unknown error'));
      },
      (offers) {
        const pageSize = 10;
        final isLastPage = offers.length < pageSize;

        if (!_isDisposed) {
          if (isLastPage) {
            pagingController.appendLastPage(offers);
          } else {
            pagingController.appendPage(offers, pageKey + 1);
          }
        }

        _offers = pagingController.itemList ?? [];
        emit(SupplierOffersLoaded(offersList: _offers));
      },
    );
  }

  void refresh() {
    if (_isDisposed) return;
    emit(SupplierOffersInitial());
    if (!_isDisposed) {
      pagingController.refresh();
    }
  }

  void initialize() {
    if (pagingController.itemList?.isEmpty != false) {
      if (!_isDisposed) {
        pagingController.refresh();
      }
    }
  }

  Future<void> createOffer({
    required int orderId,
    required int price,
    required String description,
  }) async {
    if (_isDisposed) return;

    final result = await useCases.createOffer(
      orderId: orderId,
      price: price,
      description: description,
    );

    if (_isDisposed) return;

    result.fold(
      (failure) {
        emit(SupplierOffersError(message: failure.message ?? 'Error'));
        showToast(failure.message ?? 'Error');
        emit(SupplierOffersLoaded(offersList: _offers));
      },
      (success) {
        refresh();
      },
    );
  }

  Future<void> deleteOffer({required int offerId}) async {
    if (_isDisposed) return;
    emit(SupplierOffersLoading());

    final result = await useCases.deleteOffer(offerId: offerId);

    if (_isDisposed) return;

    result.fold(
      (failure) {
        emit(SupplierOffersError(message: failure.message ?? 'Failed to delete offer'));
        emit(SupplierOffersLoaded(offersList: _offers));
      },
      (success) {
        _offers = List.from(_offers)..removeWhere((offer) => offer.id == offerId);

        if (!_isDisposed) {
          pagingController.itemList = _offers;
        }
        emit(SupplierOffersLoaded(offersList: _offers));
      },
    );
  }

  @override
  Future<void> close() {
    _isDisposed = true;
    pagingController.dispose();
    return super.close();
  }
}
