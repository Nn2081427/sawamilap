import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import 'package:swamiil/features/offers/domain/use_case/offers_use_case.dart';
import 'package:swamiil/features/orders/Presentation/cubits/new_order_cubit/new_order_cubit.dart';
import 'package:swamiil/main.dart';

part 'offers_state.dart';

class OffersCubit extends Cubit<OffersState> {
  OffersCubit({required this.offersUseCase}) : super(OffersInitial()) {
    pagingController.addPageRequestListener((pageKey) {
      print('hamza00');
      _loadOffers(pageKey);
    });
  }

  final OffersUseCase offersUseCase;
  final PagingController<int, OfferEntity> pagingController =
      PagingController(firstPageKey: 1);
  int? currentOrderId;
  int offersCount = 0;
  Future<void> _loadOffers(int pageKey) async {
    print('hamza0');
    if (currentOrderId == null) return;
    print('hamza1');
    try {
      emit(OffersLoadingState());
      final result = await offersUseCase.getOrderOffers(
        orderId: currentOrderId!,
        pageKey: pageKey,
      );
      print('hamza2');
      result.fold(
        (failure) {
          print('hamza3');
          print(failure);
          pagingController.error = failure.message ?? "Unknown error";
          emit(OffersErrorState());
          showToast(failure.message ?? "Unknown error");
        },
        (offers) {
          print('hamza4');
          final pageSize = 10;
          final isLastPage = offers.length < pageSize;

          if (isLastPage) {
            pagingController.appendLastPage(offers);
          } else {
            pagingController.appendPage(offers, pageKey + 1);
          }
          offersCount = offers.length;

          // length of list == offers.first.total
          emit(OffersLoadedState(offers));
        },
      );
    } catch (e) {
      print(e);
      pagingController.error = e.toString();
      emit(OffersErrorState());
      showToast("An error occurred");
    }
  }

  Future<void> getOrderOffers({required int orderId}) async {
    currentOrderId = orderId;
    print('hamza-1');
    _loadOffers(1);
    pagingController.refresh();
  }

  Future<void> acceptedOffers({required int offerId}) async {
    emit(OffersAcceptLoadingState());
    loading();
    final result = await offersUseCase.acceptedOffers(offerId: offerId);
    navPop();

    result.fold(
      (l) {
        showToast(l.message ?? "Unknown error");
        emit(OffersAcceptErrorState());
      },
      (success) {
        navigatorKey.currentContext!
            .read<NewOrderCubit>()
            .updateNewOrderWhenAccepted();
        successDialog(msg: "offer_accepted".tr(), lottie: Assets.lottieSuccess);

        pagingController.itemList?.removeWhere((offer) => offer.id == offerId);
        emit(OffersLoadedState(pagingController.itemList ?? []));
      },
    );
  }

  Future<void> rejectedOffers({required int offerId}) async {
    emit(OffersRejectLoadingState());
    loading();
    final result = await offersUseCase.rejectedOffers(offerId: offerId);
    navPop();

    result.fold(
      (l) {
        showToast(l.message ?? "Unknown error");
        emit(OffersRejectErrorState());
      },
      (success) {
        navigatorKey.currentContext!
            .read<NewOrderCubit>()
            .updateNewOrderWhenRejected();
              successDialog(msg: "offer_rejected".tr(), lottie: Assets.lottieSuccess);

        pagingController.itemList?.removeWhere((offer) => offer.id == offerId);
        emit(OffersLoadedState(pagingController.itemList ?? []));
      },
    );
  }

  @override
  Future<void> close() {
    pagingController.dispose();
    return super.close();
  }
}
