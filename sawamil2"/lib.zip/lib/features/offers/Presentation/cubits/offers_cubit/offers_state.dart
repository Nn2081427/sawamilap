part of 'offers_cubit.dart';

abstract class OffersState extends Equatable {
  const OffersState();

  @override
  List<Object> get props => [];
}

class OffersInitial extends OffersState {}

class OffersLoadingState extends OffersState {}

class OffersLoadedState extends OffersState {
  final List<OfferEntity> offers;

  const OffersLoadedState(this.offers);

  @override
  List<Object> get props => [offers];
}

class OffersErrorState extends OffersState {}

class OffersAcceptLoadingState extends OffersState {}

class OffersAcceptErrorState extends OffersState {}

class OffersRejectLoadingState extends OffersState {}

class OffersRejectErrorState extends OffersState {}