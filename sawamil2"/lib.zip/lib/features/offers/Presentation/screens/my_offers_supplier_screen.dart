import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:sizer/sizer.dart';

import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/CustomOrderCardWidget.dart';
import 'package:swamiil/features/offers/domain/entities/offer_entity.dart';
import '../cubits/supplier_offers_cubit/supplier_offers_cubit.dart';
import '../cubits/supplier_offers_cubit/supplier_offers_state.dart';

class MyOffersSupplierScreen extends StatefulWidget {
  const MyOffersSupplierScreen({super.key});

  @override
  State<MyOffersSupplierScreen> createState() => _MyOffersSupplierScreenState();
}

class _MyOffersSupplierScreenState extends State<MyOffersSupplierScreen> {
  late final SupplierOffersCubit cubit;

  @override
  void initState() {
    super.initState();
    cubit = getIt.get<SupplierOffersCubit>();
    cubit.initialize();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: cubit,
      child: Scaffold(
        appBar: AppBarWidget(title: "My Offers".tr()),
        backgroundColor: Colors.white,
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: BlocBuilder<SupplierOffersCubit, SupplierOffersState>(
            builder: (context, state) {
              return RefreshIndicator(
                color: AppColors.mainColor,
                onRefresh: () async => cubit.refresh(),
                child: PagedListView<int, OfferEntity>(
                  pagingController: cubit.pagingController,
                  builderDelegate: PagedChildBuilderDelegate<OfferEntity>(
                    itemBuilder: (context, offer, index) {
                      final order = offer.orderEntity;

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: CustomOrderCardWidget(
                          
                          title: order?.title ?? "",
                          name: order?.user?.firstName ?? "",
                          description: order?.notes ?? "",
                          city: order?.user?.city?.name ?? "",
                          area: order?.user?.area?.name ?? "",
                          numOfOffers: order?.offerNumbers?.toString() ?? "",
                          images: order?.images?.isNotEmpty == true
                              ? [order!.images!.first.image ?? ""]
                              : [],
                          time: convertDateToStringDMMMY(order!.createdAt),
                          brandName: order?.brand?.name ?? "",
                          brandModelName: order?.brandModel?.name ?? "",
                          isFromMyOffer: true,
                          showImageTitle: false,
                          isFromFavorite: false,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "${offer.price} ${"SAR".tr()}",
                                style: Fonts.textWhite18.copyWith(
                                  fontSize: 20,
                                  color: AppColors.mainColor,
                                ),
                              ),
                              SizedBox(width: 10),
                              CustomButton(
                                onTap: () {
                                  final offerId = offer.id;
                                  if (offerId == null) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          "Invalid offer ID".tr(),
                                          style: Fonts.textWhite18,
                                        ),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                    return;
                                  }

                                  confirmDialog(
                                    title: "Do you want to withdraw this offer?"
                                        .tr(),
                                    confirm: "withdraw".tr(),
                                    cancel: "cancel".tr(),
                                    confirmTap: () async {
                                      await cubit.deleteOffer(offerId: offerId);
                                      cubit.refresh();
                                    },
                                  );
                                },
                                height: 40,
                                width: 40.w,
                                padding: EdgeInsets.symmetric(horizontal: 8.w),
                                borderRadius: BorderRadius.circular(8),
                                backgroundColor: AppColors.mainColor,
                                child: Center(
                                  child: Text(
                                    "withdraw".tr(),
                                    style: Fonts.textWhite18
                                        .copyWith(fontSize: 14),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                    noItemsFoundIndicatorBuilder: (_) => Center(
                      child: EmptyAnimation(
                        title: "No offers yet".tr(),
                        gif: Assets.emptyLottie,
                      ),
                    ),
                    noMoreItemsIndicatorBuilder: (_) => Padding(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      child: Center(
                        child: Text(
                          "no more offers".tr(),
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    ),
                    firstPageProgressIndicatorBuilder: (_) => Column(
                      children: const [
                        ShimmerWidget(
                          height: 100,
                          width: double.infinity,
                          radius: 15,
                          numOfShimmer: 1,
                        ),
                        ShimmerWidget(
                          height: 250,
                          width: double.infinity,
                          radius: 15,
                          numOfShimmer: 1,
                        ),
                      ],
                    ),
                    firstPageErrorIndicatorBuilder: (_) => Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("Error loading offers".tr()),
                          SizedBox(height: 16),
                          CustomButton(
                            backgroundColor: AppColors.mainColor,
                            textStyle: Fonts.textWhite18,
                            padding: EdgeInsets.symmetric(vertical: 1.5.h),
                            margin: EdgeInsets.symmetric(horizontal: 5.w),
                            onTap: () => cubit.pagingController.refresh(),
                            buttonText: "Retry".tr(),
                          ),
                        ],
                      ),
                    ),
                    newPageProgressIndicatorBuilder: (_) => const ShimmerWidget(
                      height: 100,
                      width: double.infinity,
                      radius: 15,
                      numOfShimmer: 1,
                    ),
                    newPageErrorIndicatorBuilder: (_) => Padding(
                      padding: const EdgeInsets.all(16),
                      child: Center(
                        child: CustomButton(
                          backgroundColor: AppColors.mainColor,
                          textStyle: Fonts.textWhite18,
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          margin: EdgeInsets.symmetric(horizontal: 5.w),
                          onTap: () =>
                              cubit.pagingController.retryLastFailedRequest(),
                          buttonText: "Retry".tr(),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
