import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomProfileContainerWidget.dart';
import 'package:swamiil/features/orders/Presentation/widgets/NewOrderButtonWidget.dart';
import 'package:swamiil/features/orders/Presentation/widgets/WaitingOrderButtonsWidget.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';
import '../../domain/entities/offer_entity.dart';

class OfferWidget extends StatelessWidget {
  const OfferWidget({
    super.key,
    required this.isRestrictedScreen,
    required this.offerEntity,
    this.firstButtonTap,
    this.secondButtonTap,
    this.showPrice = true,
    this.orderEntity,
    // this.image,
    // this.name,
    // this.city,
  });
  final bool isRestrictedScreen;
  final OfferEntity offerEntity;
  final void Function()? firstButtonTap;
  final void Function()? secondButtonTap;
  final bool? showPrice;
  final OrderEntity? orderEntity;
  // final String? image,name,city;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: isRestrictedScreen ? null : EdgeInsets.all(10),
      width: double.infinity,
      decoration: isRestrictedScreen
          ? null
          : BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.grey.shade400),
            ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: isRestrictedScreen ? null : EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isRestrictedScreen
                  ? null
                  : AppColors.lightGrey.withOpacity(0.5),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomProfileContainerWidget(
              supplierId: offerEntity.supplierId!,
              name: offerEntity.supplier?.name,
              image: offerEntity.supplier?.image,
              city: offerEntity.supplier?.city?.name,
              price: showPrice! ? offerEntity.price : null,
            ),
          ),
          SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.lightGrey.withOpacity(0.5),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ExpandableDescriptionText(description: offerEntity.notes),
          ),
          SizedBox(height: 15),
          !isRestrictedScreen
              ? NewOrderButtonWidget(
                  offerEntity: offerEntity,
                  ignoreOfferOnTap: firstButtonTap,
                  acceptOfferOnTap: secondButtonTap)
              : WaitingOrderButtonsWidget(
                  offerEntity: offerEntity,
                  orderEntity: orderEntity,
                  ignoreOfferOnTap: firstButtonTap,
                  acceptOfferOnTap: secondButtonTap),
        ],
      ),
    );
  }
}
