import 'package:swamiil/features/city/domain/entities/area_entity.dart';
import 'package:swamiil/features/city/domain/entities/city_entity.dart';

class SupplierEntity{
  int id;
  String? firstName;
  String? lastName;

  String? image;
  String? nationalId;
  int? areaId;
  String? bio;
  String? phone;
  double? wallet;
  String? token;
  CityEntity? city;
  AreaEntity? area;
  bool notifications;

  SupplierEntity({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.nationalId,
    required this.areaId,
    required this.bio,
    required this.phone,
    required this.wallet,
    required this.token,
    required this.city,
    required this.area,
    required this.image,
    required this.notifications,
  });

  get name => "$firstName $lastName";

}
