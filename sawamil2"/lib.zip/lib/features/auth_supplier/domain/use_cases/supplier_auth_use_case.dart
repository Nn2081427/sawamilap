import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/auth_supplier/domain/entities/supplier_entity.dart';
import 'package:swamiil/features/auth_supplier/domain/repositries/supplier_auth_repo.dart';

class SupplierAuthUseCase {
  final SupplierRepo supplierRepo;

  SupplierAuthUseCase({required this.supplierRepo});

  Future<Either<DioException, SupplierEntity>> supplierLogin(
      {Map<String, dynamic>? data}) async {
    return await supplierRepo.supplierLogin(data: data);
  }

  Future<Either<DioException, bool>> registerSupplier(
    Map<String, dynamic> data,
  ) async {
    return await supplierRepo.registerSupplier(
      data,
    );
  }

  Future<Either<DioException, bool>> supplierUpdatePassword(
      Map<String, dynamic> data) async {
    return await supplierRepo.supplierUpdatePassword(data);
  }

  Future<Either<DioException, bool>> supplierLogout(
      {required Map<String, dynamic> data}) async {
    return await supplierRepo.supplierLogout(data: data);
  }

  Future<Either<DioException, String>> supplierRefreshToken(
      Map<String, dynamic> data) async {
    return await supplierRepo.supplierRefreshToken(data);
  }

  Future<Either<DioException, SupplierEntity>> updateSupplierProfile(
      Map<String, dynamic> data) async {
    return await supplierRepo.updateSupplierProfile(data);
  }

  Future<Either<DioException, SupplierEntity>> getSupplierProfile() async {
    return await supplierRepo.getSupplierProfile();
  }

  Future<Either<DioException, SupplierEntity>> getSupplierPublicProfileById(
      Map<String, dynamic> data) async {
    return await supplierRepo.getSupplierPublicProfileById(data);
  }
}
