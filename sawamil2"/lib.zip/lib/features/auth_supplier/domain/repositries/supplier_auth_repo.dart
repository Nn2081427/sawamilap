import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/auth_supplier/domain/entities/supplier_entity.dart';

abstract class SupplierRepo {
  Future<Either<DioException, SupplierEntity>> supplierLogin({Map<String, dynamic>? data});
  Future<Either<DioException, bool>> registerSupplier(Map<String, dynamic> data,);
  Future<Either<DioException,SupplierEntity>> getSupplierProfile();
  Future<Either<DioException, bool>> supplierLogout({Map<String, dynamic> data});
  Future<Either<DioException, bool>> supplierUpdatePassword(Map<String, dynamic> data);
  Future<Either<DioException, String >> supplierRefreshToken(Map<String, dynamic> data);
  Future<Either<DioException, SupplierEntity>> updateSupplierProfile(Map<String, dynamic> data);
  Future<Either<DioException, SupplierEntity>> getSupplierPublicProfileById(Map<String, dynamic> data);




}
