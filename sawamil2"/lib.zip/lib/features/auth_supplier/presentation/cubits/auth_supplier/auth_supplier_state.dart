part of 'auth_supplier_cubit.dart';

sealed class AuthSupplierState extends Equatable {
  const AuthSupplierState();

  @override
  List<Object> get props => [];
}

final class AuthSupplierInitial extends AuthSupplierState {}

class ObscureTextToggled extends AuthSupplierState {}

class InputsUpdated extends AuthSupplierState {}

class ImageUpdated extends AuthSupplierState {}

class AuthSupplierLoading extends AuthSupplierState {}


class AuthSupplierSuccess extends AuthSupplierState {}