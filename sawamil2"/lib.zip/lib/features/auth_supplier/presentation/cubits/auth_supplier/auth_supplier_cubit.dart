import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/dialog/drop_down_dialog.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/dialog/success_dialog.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/core/helper_function/appSecureStore.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/models/text_field_model.dart';
import 'package:swamiil/features/auth_supplier/domain/entities/supplier_entity.dart';
import 'package:swamiil/features/auth_supplier/domain/use_cases/supplier_auth_use_case.dart';
import 'package:swamiil/features/auth_supplier/presentation/screens/supplier_register.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/layout/Presentation/screens/supplier_layout_screen.dart';
import 'package:swamiil/features/user_auth/presentation/screens/users_screen.dart';
import 'package:swamiil/main.dart';

import '../../screens/suppliers_login.dart';

part 'auth_supplier_state.dart';

class AuthSupplierCubit extends Cubit<AuthSupplierState> {
  AuthSupplierCubit({
    required this.supplierAuthUseCase,
  }) : super(AuthSupplierInitial());

  final SupplierAuthUseCase supplierAuthUseCase;
  bool isObsecure = true;
  String? imagePath;
  SupplierEntity? supplierEntity;
  List<TextFieldModel> suppliersInputs = [];
  List<TextFieldModel> suppliersRegetserInputs = [];
  void initializeSuppliersRegetserInputs() {
    suppliersRegetserInputs = [
      TextFieldModel(
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthSupplierCubit>()
                .supplierEntity
                ?.id
                .toString()),
        key: "national_id",
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        validator: (value) => null,
        hint: "enter your ID".tr(),
        label: "ID Number".tr(),
        readOnly: true,
      ),
      TextFieldModel(
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthSupplierCubit>()
                .supplierEntity
                ?.firstName),
        key: "first_name",
        width: 45.w,
        label: "First Name".tr(),
        hint: "enter your first name".tr(),
      ),
      TextFieldModel(
        label: "Last Name".tr(),
        width: 45.w,
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthSupplierCubit>()
                .supplierEntity
                ?.lastName),
        key: "last_name",
        hint: "enter your last name".tr(),
      ),
      TextFieldModel(
        width: double.infinity,
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        controller: TextEditingController(
          text: navigatorKey.currentContext!
              .read<AuthSupplierCubit>()
              .supplierEntity
              ?.city
              ?.name,
        ),
        key: "area_id",
        label: "Area".tr(),
        onTap: () {
          showDropDownDialog(
            navigatorKey.currentContext!.read<CitiesCubit>(),
          ).then((selectedCity) {
            updateDropDown(selectedCity?.name ?? "", "area_id");
          });
        },
        readOnly: true,
        suffix: Icon(
          Icons.arrow_drop_down,
          color: Colors.black,
        ),
        validator: (value) => null,
        hint: "enter your city".tr(),
      ),
      TextFieldModel(
        width: double.infinity,
        suffix: Icon(
          Icons.arrow_drop_down,
          color: Colors.black,
        ),
        onTap: () {
          showDropDownDialog(
            navigatorKey.currentContext!.read<AreaCubit>(),
          ).then((selectedArea) {
            updateDropDown(selectedArea?.name ?? "", "city");
          });
        },
        label: "city".tr(),
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthSupplierCubit>()
                .supplierEntity
                ?.area
                ?.name),
        key: "city",
        readOnly: true,
        validator: (value) => null,
        hint: "enter your city".tr(),
      ),
      TextFieldModel(
        controller: TextEditingController(
            text: navigatorKey.currentContext!
                .read<AuthSupplierCubit>()
                .supplierEntity
                ?.phone),
        key: "phone",
        contentPadding: EdgeInsets.symmetric(vertical: 2.5.h, horizontal: 4.w),
        hint: "enter your phone number".tr(),
        label: "Phone Number".tr(),
      ),
    ];
  }

  void initializeSuppliersInputs() {
    if (suppliersInputs.isEmpty) {
      suppliersInputs = [
        TextFieldModel(
          width: double.infinity,
          controller: TextEditingController(),
          key: "national_id",
          textInputType: TextInputType.number,
          label: "ID Number".tr(),
          hint: "enter your ID".tr(),
        ),
        TextFieldModel(
          width: double.infinity,
          label: "Password".tr(),
          controller: TextEditingController(),
          key: "password",
          hint: "enter your password".tr(),
          suffix: IconButton(
            onPressed: toggleObscureText,
            icon: Icon(
              isObsecure ? Icons.visibility_off : Icons.visibility,
            ),
          ),
          obscureText: isObsecure,
        ),
      ];
      emit(InputsUpdated());
    }
  }

  void updateDropDown(String value, String key) {
    suppliersInputs.firstWhere((e) => e.key == key).controller.text = value;
  }

  void updateVis() {
    suppliersInputs.firstWhere((e) => e.key == 'password').obscureText =
        isObsecure;
  }

  void toggleObscureText() {
    isObsecure = !isObsecure;

    // Update login password field if it exists
    final loginPasswordIndex =
        suppliersInputs.indexWhere((e) => e.key == 'password');
    if (loginPasswordIndex != -1) {
      suppliersInputs[loginPasswordIndex] =
          suppliersInputs[loginPasswordIndex].copyWith(
        obscureText: isObsecure,
        suffix: IconButton(
          onPressed: toggleObscureText,
          icon: Icon(isObsecure ? Icons.visibility_off : Icons.visibility),
        ),
      );
    }

    // Update register password field if it exists
    final registerPasswordIndex =
        suppliersRegetserInputs.indexWhere((e) => e.key == 'password');
    if (registerPasswordIndex != -1) {
      suppliersRegetserInputs[registerPasswordIndex] =
          suppliersRegetserInputs[registerPasswordIndex].copyWith(
        obscureText: isObsecure,
        suffix: IconButton(
          onPressed: toggleObscureText,
          icon: Icon(isObsecure ? Icons.visibility_off : Icons.visibility),
        ),
      );
    }

    emit(ObscureTextToggled());
  }

  void setImagePath(String path) {
    imagePath = path;
    emit(ImageUpdated());
  }

  Future<void> supplierLogin() async {
    Map<String, dynamic> data = {};
    for (var element in suppliersInputs) {
      data[element.key!] = element.controller.text;
    }
    final result = await supplierAuthUseCase.supplierLogin(data: data);

    result.fold((l) {
      showToast(l.message ?? "Unknown error");
    }, (r) {
      AuthSecureStorage.saveAccessToken(r.token!);
      ApiHandel.getInstance.updateHeader(r.token!);
      navPARU(SupplierLayoutScreen());
    });
  }

  Future<void> supplierRegister() async {
    emit(AuthSupplierLoading());
    Map<String, dynamic> data = {};

    suppliersRegetserInputs.forEach((element) {
      data[element.key!] = element.controller.text;
    });
    data["area_id"] = Constants.globalContext().read<AreaCubit>().value();
    data.remove('city');

    if (imagePath == null) {
      showToast("Please select an image");
      emit(AuthSupplierInitial());
      return;
    }

    loading();
    data['image'] = await MultipartFile.fromFile(imagePath!);
    final result = await supplierAuthUseCase.registerSupplier(
      data,
    );
    navPop();
    result.fold(
      (failure) {
        showToast(failure.message ?? "Unknown error");
        emit(AuthSupplierInitial());
      },
      (_) {
        successDialog(
            msg: "account_created_successfully".tr(),
            lottie: Assets.lottieSuccess,
            then: () {
              navPop();
            });
        //  navPARU(SupplierLayoutScreen());
        emit(AuthSupplierInitial());
      },
    );
  }

  Future<void> logout() async {
    emit(AuthSupplierLoading());
    final token = await AuthSecureStorage.getAccessToken();
    final result =
        await supplierAuthUseCase.supplierLogout(data: {"token": token});

    result.fold(
      (failure) {
        showToast(failure.message ?? "Unknown error");
        emit(AuthSupplierInitial());
      },
      (_) {
        navP(UsersScreen());
        emit(AuthSupplierInitial());
      },
    );
  }

  void goToLoginPage() {
    initializeSuppliersInputs();
    navP(SuppliersLogin());
  }

  void goRegisterPage() {
    initializeSuppliersRegetserInputs();

    navP(SupplierRegister());
  }
}
