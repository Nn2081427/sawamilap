import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/widgets/CustomScreen.dart';
import 'package:swamiil/core/widgets/app_bar_widget.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/list_text_field.dart';
import 'package:swamiil/features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';
import 'package:swamiil/features/profile/Presentation/widgets/ProfileImage.dart';
import 'package:swamiil/features/user_auth/presentation/widgets/privacy_widget.dart';

class SupplierRegister extends StatefulWidget {
  const SupplierRegister({super.key});

  @override
  State<SupplierRegister> createState() => _SupplierRegisterState();
}

class _SupplierRegisterState extends State<SupplierRegister> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return CustomScreen(
      appBar: AppBarWidget(title: "create_account_supplier".tr()),
      body: BlocListener<AuthSupplierCubit, AuthSupplierState>(
        listener: (context, state) {},
        child: BlocBuilder<AuthSupplierCubit, AuthSupplierState>(
          builder: (context, state) {
            var cubit = context.read<AuthSupplierCubit>();
            return SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 5.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: ProfileImage(
                          isAuthScreen: true,
                          onImagePicked: (path) => cubit.setImagePath(path),
                        ),
                      ),
                      SizedBox(height: 3.h),
                      if (cubit.suppliersInputs.isEmpty)
                        Center(
                          child: Text(
                            "No input fields available",
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ListTextFieldWidget(
                        inputs: cubit.suppliersRegetserInputs,
                        isWrap: true,
                      ),
                      SizedBox(height: 2.h),
                      CustomButton(
                        backgroundColor: AppColors.mainColor,
                        onTap: () {
                          if (_formKey.currentState!.validate()) {
                            cubit.supplierRegister();
                          }
                        },
                        padding: EdgeInsets.symmetric(vertical: 12),
                        borderRadius: BorderRadius.circular(8),
                        buttonText: "create_account".tr(),
                        width: double.infinity,
                      ),
                      SizedBox(height: 5.h),
                      PrivacyWidget(),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
