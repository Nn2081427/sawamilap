import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/default_eleveted_button.dart';
import 'package:swamiil/core/widgets/list_text_field.dart';
import 'package:swamiil/core/widgets/main_layout_page.dart';
import 'package:swamiil/core/widgets/svg_widget.dart';
import 'package:swamiil/features/user_auth/presentation/widgets/sawamil_info_widget.dart';
import 'package:swamiil/features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';

class SuppliersLogin extends StatefulWidget {
  const SuppliersLogin({super.key});

  @override
  State<SuppliersLogin> createState() => _SuppliersLoginState();
}

class _SuppliersLoginState extends State<SuppliersLogin> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<AuthSupplierCubit, AuthSupplierState>(
        builder: (context, state) {
          var cubit = context.read<AuthSupplierCubit>();
          return MainLayoutPage(
            child: SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    padding: EdgeInsets.only(
                      left: 25,
                      right: 25,
                      bottom: MediaQuery.of(context).viewInsets.bottom,
                    ),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight,
                      ),
                      child: IntrinsicHeight(
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 6.h),
                              Stack(
                                alignment: Alignment.center,
                                children: [
                                  Center(
                                    child: Text(
                                      "Suppliers Login".tr(),
                                      style: Fonts.text20Orange
                                          .copyWith(color: Colors.black),
                                    ),
                                  ),
                                  Positioned(
                                    right: 0,
                                    child: GestureDetector(
                                      onTap: () {
                                        Navigator.pop(
                                            context); // Optional: Go back on tap
                                      },
                                      child: SvgPicture.asset(
                                        Assets.arrowBack,
                                        height: 24,
                                        width: 24,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              SizedBox(height: 15.h),
                              // Debug message - can be removed in production
                              if (cubit.suppliersInputs.isEmpty)
                                Center(
                                  child: Text(
                                    "No input fields available",
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ListTextFieldWidget(
                                inputs: cubit.suppliersInputs,
                                isWrap: false,
                              ),
                              const SizedBox(height: 8),

                              SizedBox(height: 10.h),
                              CustomButton(
                                width: double.infinity,
                                height: 56,
                                onTap: () {
                                  if (_formKey.currentState!.validate()) {
                                    context
                                        .read<AuthSupplierCubit>()
                                        .supplierLogin();
                                  }
                                },
                                buttonText: "Continue".tr(),
                                textStyle:
                                    Fonts.textWhite18.copyWith(fontSize: 16),
                                backgroundColor: AppColors.mainColor,
                                borderRadius: BorderRadius.circular(15),
                              ),

                              SizedBox(height: 10.h),
                              Center(child: const SawamilInfoWidget()),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
