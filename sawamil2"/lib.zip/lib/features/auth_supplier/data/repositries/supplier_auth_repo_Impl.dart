import 'package:dartz/dartz.dart';
import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/auth_supplier/data/data_source/supplier_auth_remote_data_source.dart';
import 'package:swamiil/features/auth_supplier/data/models/supplier_model.dart';
import 'package:swamiil/features/auth_supplier/domain/repositries/supplier_auth_repo.dart';

class SupplierRepoImpl extends SupplierRepo {
  @override
  Future<Either<DioException, SupplierModel>> supplierLogin(
      {Map<String, dynamic>? data}) async {
    return await SupplierAuthRemoteDataSource.supplierLogin(data: data);
  }

  @override
  Future<Either<DioException, bool>> registerSupplier(
      Map<String, dynamic> data,) async {
    return await SupplierAuthRemoteDataSource.registerSupplier(data,);
  }

  @override
  Future<Either<DioException, bool>> supplierUpdatePassword(
      Map<String, dynamic> data) async {
    return await SupplierAuthRemoteDataSource.supplierUpdatePassword(data);
  }

  @override
  Future<Either<DioException, bool>> supplierLogout(
      {Map<String, dynamic>? data}) async {
    return await SupplierAuthRemoteDataSource.supplierLogout(data!);
  }

  @override
  Future<Either<DioException, String>> supplierRefreshToken(
      Map<String, dynamic> data) async {
    return await SupplierAuthRemoteDataSource.supplierRefreshToken(data);
  }

  @override
  Future<Either<DioException, SupplierModel>> updateSupplierProfile(
      Map<String, dynamic> data) async {
    return await SupplierAuthRemoteDataSource.updateSupplierProfile(data);
  }

  @override
  Future<Either<DioException, SupplierModel>> getSupplierProfile() async {
    return await SupplierAuthRemoteDataSource.getSupplierProfile();
  }

  @override
  Future<Either<DioException, SupplierModel>> getSupplierPublicProfileById(Map<String, dynamic> data) async{
    return await SupplierAuthRemoteDataSource.getSupplierPublicProfileById(data);
  }
}
