import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/features/auth_supplier/data/models/supplier_model.dart';
import 'package:swamiil/main.dart';

class SupplierAuthRemoteDataSource {
  final ApiHandel apiHandel;

  SupplierAuthRemoteDataSource({required this.apiHandel});

  // supplier login
  static Future<Either<DioException, SupplierModel>> supplierLogin(
      {Map<String, dynamic>? data}) async {
    try {
      var response = await ApiHandel.getInstance.post('supplier/login', data!);
      return response.fold((l) => Left(l), (r) {
        try {
          return Right(SupplierModel.fromJson(r.data['data']));
        } catch (e) {
          return Left(DioException(
            requestOptions: RequestOptions(path: 'supplier/login'),
            message: "Parsing Error: ${e.toString()}",
          ));
        }
      });
    } catch (e) {
      return Left(DioException(
        requestOptions: RequestOptions(path: 'supplier/login'),
        message: "Unexpected Error: ${e.toString()}",
      ));
    }
  }

  static Future<Either<DioException, bool>> registerSupplier(
      Map<String, dynamic> data) async {
    var response = await ApiHandel.getInstance.post('supplier/register', data);
    return response.fold((l) => Left(l), (r) {
      return Right(true);
    });
  }

  // supplier register
  /// get supplier profile
  static Future<Either<DioException, SupplierModel>>
      getSupplierProfile() async {
    var response = await ApiHandel.getInstance.get('supplier/get_profile');
    return response.fold((l) => Left(l), (r) {
      return Right(SupplierModel.fromJson(r.data['data']));
    });
  }

  // supplier update profile
  static Future<Either<DioException, SupplierModel>> updateSupplierProfile(
      Map<String, dynamic> data) async {
    var response =
        await ApiHandel.getInstance.post('supplier/update_profile', data);
    return response.fold((l) => Left(l), (r) {
      return Right(SupplierModel.fromJson(r.data['data']));
    });
  }

  // supplier update password
  static Future<Either<DioException, bool>> supplierUpdatePassword(
      Map<String, dynamic> data) async {
    var response =
        await ApiHandel.getInstance.post('supplier/update_password', data);
    return response.fold((l) => Left(l), (r) {
      return const Right(true);
    });
  }

  // supplier logOut
  static Future<Either<DioException, bool>> supplierLogout(
      Map<String, dynamic> data) async {
    var response = await ApiHandel.getInstance.post('supplier/logout', data);
    return response.fold((l) => Left(l), (r) {
      return const Right(true);
    });
  }

  // supplier refresh token
  static Future<Either<DioException, String>> supplierRefreshToken(
      Map<String, dynamic> data) async {
    var response =
        await ApiHandel.getInstance.post('supplier/refresh_token', data);
    return response.fold((l) => Left(l), (r) {
      return Right(r.data['data']['token']);
    });
  }

  static Future<Either<DioException, SupplierModel>>
      getSupplierPublicProfileById(Map<String, dynamic> data) async {
    talker.info("in getSupplierPublicProfileById remote");
    var response =
        await ApiHandel.getInstance.post('user/get_supplier', data);

    return response.fold(
      (l) => Left(l),
      (r) => Right(SupplierModel.fromJson(r.data['data'])),
    );
  }
}
