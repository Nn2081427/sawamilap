import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/city/data/models/area_model.dart';
import 'package:swamiil/features/city/data/models/city_model.dart';

import '../../domain/entities/supplier_entity.dart';

class SupplierModel extends SupplierEntity {
  SupplierModel(
      {required super.id,
      required super.firstName,
      required super.lastName,
      required super.nationalId,
      required super.areaId,
      required super.bio,
      required super.phone,
      required super.wallet,
      required super.token,
      required super.city,
      required super.area,
      required super.notifications,
      required super.image});

  factory SupplierModel.fromJson(Map<String, dynamic> json) {
    AreaModel? area;
    CityModel? city;

    if (json.containsKey('area') && json['area'] != null) {
      area = AreaModel.fromJson(json['area']);
      city = CityModel.fromJson(json['area']['city']);
    }

    return SupplierModel(
      id: json['id'],
      image: json['image'],
      firstName: json['first_name'],
      lastName: json['last_name'],
      nationalId: json['national_id'],
      areaId: json['area_id'],
      bio: json['bio'],
      phone: json['phone'],
      wallet: convertDataToDouble(json['wallet']),
      token: json['token'],
      city: city,
      area: area,
      notifications: convertDataToBool(json['notifications']),
    );
  }
}
