import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/empty_animation.dart';
import 'package:swamiil/core/widgets/main_layout_page.dart';
import 'package:swamiil/core/widgets/shimmer_widget.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/AppBarHomeSupplierWidget.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/HomeSupplierScreenBodyWidget.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/SearchBarWidget.dart';
import 'package:swamiil/features/offers/Presentation/cubits/supplier_offers_cubit/supplier_offers_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/supplier_cubit/supplier_orders_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/supplier_cubit/supplier_orders_state.dart';
import 'package:swamiil/features/orders/domain/entity/order_entity.dart';

class HomeSupplierScreen extends StatelessWidget {
  const HomeSupplierScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
              getIt.get<SupplierOrdersCubit>()..getSupplierNewOrders(),
        ),
        BlocProvider(
          create: (context) => SupplierOffersCubit(useCases: getIt.get()),
        ),
      ],
      child: Scaffold(
        body: Stack(
          children: [
            MainLayoutPage(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 6.h),
                    const AppBarHomeSupplierWidget(),
                    const SearchBarWidget(),
                    SizedBox(height: 1.5.h),
                    Text(
                      "all_orders".tr(),
                      style: Fonts.text16Orange.copyWith(
                        color: Colors.black,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Expanded(
                      child:
                          BlocBuilder<SupplierOrdersCubit, SupplierOrdersState>(
                        builder: (context, state) {
                          final cubit = context.read<SupplierOrdersCubit>();
                          return RefreshIndicator(
                            color: AppColors.mainColor,
                            onRefresh: () async {
                              cubit.newOrdersPagingController.refresh();
                            },
                            child: PagedListView<int, OrderEntity>(
                              pagingController: cubit.newOrdersPagingController,
                              builderDelegate:
                                  PagedChildBuilderDelegate<OrderEntity>(
                                itemBuilder: (context, order, index) {
                                  return HomeSupplierScreenBodyWidget(
                                    title: order.title ?? "",
                                    year: order.year ?? "",
                                    appliedOffer: order.appliedOffer ?? false,
                                    orderId: order.id ?? 0,
                                    time: convertDateToStringDMMMY(
                                        order.createdAt),
                                    city: order.user?.city?.name ?? "",
                                    area: order.user?.area?.name ?? "",
                                    name: order.user?.firstName ?? "",
                                    description: order.notes ?? "",
                                    brandName: order.brand?.name ?? "",
                                    brandModelName:
                                        order.brandModel?.name ?? "",
                                    images: order.images
                                            ?.where((img) => img.image != null)
                                            .map((img) => img.image!)
                                            .toList() ??
                                        [],
                                    numOfOffers: order.offerNumbers.toString(),
                                    onToggleAppliedOffer: () {
                                      context
                                          .read<SupplierOrdersCubit>()
                                          .toggleAndRefresh(order.id!);
                                    },
                                  );
                                },
                                firstPageProgressIndicatorBuilder: (_) =>
                                    Column(
                                  children: [
                                    const ShimmerWidget(
                                      height: 100,
                                      width: double.infinity,
                                      radius: 15,
                                      numOfShimmer: 1,
                                    ),
                                    const ShimmerWidget(
                                      height: 250,
                                      width: double.infinity,
                                      radius: 15,
                                      numOfShimmer: 1,
                                    ),
                                  ],
                                ),
                                newPageProgressIndicatorBuilder: (_) =>
                                    const ShimmerWidget(
                                  height: 100,
                                  width: double.infinity,
                                  radius: 15,
                                  numOfShimmer: 1,
                                ),
                                noItemsFoundIndicatorBuilder: (context) =>
                                    const EmptyAnimation(
                                  title: "No Orders Found",
                                  gif: Assets.emptyLottie,
                                ),
                                noMoreItemsIndicatorBuilder: (_) => Padding(
                                  padding: EdgeInsets.symmetric(vertical: 2.h),
                                  child: Center(
                                    child: Text(
                                      "no more orders".tr(),
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                  ),
                                ),
                                firstPageErrorIndicatorBuilder: (_) => Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Error loading orders".tr()),
                                      SizedBox(height: 16),
                                      CustomButton(
                                        backgroundColor: AppColors.mainColor,
                                        textStyle: Fonts.textWhite18,
                                        padding: EdgeInsets.symmetric(
                                            vertical: 1.5.h),
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 5.w),
                                        onTap: () => cubit
                                            .newOrdersPagingController
                                            .refresh(),
                                        buttonText: "Retry".tr(),
                                      ),
                                    ],
                                  ),
                                ),
                                newPageErrorIndicatorBuilder: (_) => Padding(
                                  padding: EdgeInsets.all(16),
                                  child: Center(
                                    child: CustomButton(
                                      backgroundColor: AppColors.mainColor,
                                      textStyle: Fonts.textWhite18,
                                      padding:
                                          EdgeInsets.symmetric(vertical: 1.5.h),
                                      margin:
                                          EdgeInsets.symmetric(horizontal: 5.w),
                                      onTap: () => cubit
                                          .newOrdersPagingController
                                          .retryLastFailedRequest(),
                                      buttonText: "Retry".tr(),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
