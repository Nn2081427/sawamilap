import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/models/favorite_class.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/features/Home/Presentation/widgets/upload_image_widget.dart';
import 'package:swamiil/features/favourite/domain/usecases/favourites_use_cases.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_cubit.dart';
import 'package:swamiil/features/favourite/presentation/widgets/icon_fav_widget.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/InfoRowWidget.dart';
import 'package:swamiil/features/orders/Presentation/widgets/CustomCarNameAndDescription.dart';

import '../../../../core/constants/assets.dart';
import '../../../../core/theme/font_style.dart';
import '../../../../core/widgets/favorite_button_widget.dart';

class CustomOrderCardWidget extends StatefulWidget {
  const CustomOrderCardWidget({
    super.key,
    required this.isFromFavorite,
    required this.isFromMyOffer,
    this.child,
    this.showImageTitle = true,
    this.name,
    this.brandName,
    this.description,
    this.city,
    this.area,
    this.images,
    this.numOfOffers,
    this.time,
    this.orderId,
    this.brandModelName,
    this.appliedOffer,
    this.year,
    this.title,
  });

  final bool isFromFavorite;
  final bool isFromMyOffer;
  final Widget? child;
  final bool? showImageTitle;
  final String? name;
  final String? brandName;
  final String? brandModelName;
  final String? description;
  final String? city;
  final String? area;
  final List<String>? images;
  final String? numOfOffers;
  final String? time;
  final int? orderId;
  final bool? appliedOffer;
  final String? year;
  final String? title;

  @override
  State<CustomOrderCardWidget> createState() => _CustomOrderCardWidgetState();
}

class _CustomOrderCardWidgetState extends State<CustomOrderCardWidget> {
  late bool isFavorite;

  @override
  void initState() {
    super.initState();
    isFavorite = widget.isFromFavorite; // initialize favorite state
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          FavouritesCubit(useCases: getIt.get<FavouritesUseCases>()),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey.shade200, width: 1),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 6,
                vertical: widget.isFromMyOffer == true ? 10 : 0,
              ),
              decoration: BoxDecoration(
                color: AppColors.textFieldBgColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 2,
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            SvgPicture.asset(Assets.personIcon,
                                width: 20, height: 20),
                            SizedBox(width: 8),
                            Text(
                              widget.name ?? "",
                              style: Fonts.text16Orange.copyWith(
                                color: Colors.black,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      if (widget.isFromMyOffer)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xffC0EFD5),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Text(
                            "تم ارسال عرضك",
                            style: Fonts.text16Orange.copyWith(
                              color: Colors.green,
                              fontWeight: FontWeight.w500,
                              fontSize: 14.sp,
                            ),
                          ),
                        )
                      else
                        FavouriteIcon(
                          orderId: widget.orderId ?? 0,
                          initialIsFav: isFavorite,
                        ),
                    ],
                  ),
                  SizedBox(
                    height: 4,
                  ),
                  InfoRowWidget(
                    city: widget.city ?? "",
                    area: widget.area ?? "",
                    numOfOffers: widget.numOfOffers ?? "",
                    time: widget.time ?? "",
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    widget.title ?? "",
                    style: Fonts.text16Orange.copyWith(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (widget.description != null &&
                      widget.description!.trim().isNotEmpty) ...[
                    SizedBox(height: 1.h),
                    ExpandableDescriptionText(
                      description: widget.description ?? "",
                    ),
                    SizedBox(
                      height: 2.h,
                    ),
                  ],
                  if (!widget.isFromFavorite &&
                      widget.images != null &&
                      widget.images!.isNotEmpty) ...[
                    SizedBox(height: 2.h),
                    UploadImageWidget(
                      title: "",
                      isRestrictedScreen: !widget.showImageTitle!,
                      weight: FontWeight.w500,
                      images: widget.images,
                    ),
                    SizedBox(height: 2.h),
                  ],
                ],
              ),
            ),
            SizedBox(
              height: 13,
            ),
            widget.child ?? const SizedBox(),
          ],
        ),
      ),
    );
  }
}
