import 'package:flutter/material.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/home_supplier/presentation/screens/home_supplier_screen.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/InfoItemWidget.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/SeparatorWidget.dart';

class InfoRowWidget extends StatelessWidget {
  const InfoRowWidget(
      {super.key,
      required this.city,
      required this.area,
      required this.numOfOffers,
      required this.time});
  final String city;
  final String area;
  final String numOfOffers;
  final String time;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        InfoItemWidget(
          icon: Assets.locationOutlinedIcon,
          text: "$city - $area",
        ),
        SeparatorWidget(),
        InfoItemWidget(
          icon: Assets.timerIcon,
          text: time,
        ),
        SeparatorWidget(),
        InfoItemWidget(
          icon: Assets.offersIcon,
          text: "$numOfOffers عروض",
        ),
      ],
    );
  }
}
