import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/text_style.dart';
import 'package:swamiil/core/widgets/text_field.dart';

class SearchBarWidget extends StatelessWidget {
  const SearchBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return TextFieldWidget(
      color: Colors.white,
      height: 6.h,
      suffix: IconButton(
          onPressed: () {}, icon: SvgPicture.asset(Assets.filterIcon)),
      controller: TextEditingController(),
      borderColor: Colors.grey.shade300,
      width: double.infinity,
      borderRadius: 10,
      prefix: Padding(
          padding: EdgeInsets.all(15.0),
          child: SvgPicture.asset(Assets.serachIcon)),
      hintText: "Search...".tr(),
      hintStyle: Fonts.text16Black,
    );
  }
}
