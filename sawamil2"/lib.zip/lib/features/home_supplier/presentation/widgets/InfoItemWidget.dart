import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

class InfoItemWidget extends StatelessWidget {
  final String icon;
  final String text;

  const InfoItemWidget({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SvgPicture.asset(
          icon,
          width: 5.w,
          height: 2.h,
        ),
        SizedBox(width: 1.w),
        Text(
          text,
          style: Fonts.text16Orange.copyWith(
            color: Colors.black.withOpacity(0.6),
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
