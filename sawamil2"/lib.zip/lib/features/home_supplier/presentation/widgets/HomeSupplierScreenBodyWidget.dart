import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/dialog/confirm_dialog.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/home_supplier/presentation/widgets/CustomOrderCardWidget.dart';
import 'package:swamiil/features/offers/Presentation/cubits/supplier_offers_cubit/supplier_offers_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/supplier_cubit/supplier_orders_cubit.dart';

class HomeSupplierScreenBodyWidget extends StatelessWidget {
  const HomeSupplierScreenBodyWidget({
    super.key,
    required this.name,
    required this.description,
    required this.brandName,
    required this.brandModelName,
    required this.city,
    required this.area,
    required this.images,
    required this.numOfOffers,
    required this.orderId,
    required this.time,
    required this.appliedOffer,
    required this.year,
    required this.title,
    this.onToggleAppliedOffer,
  });

  final String name;
  final String description;
  final String brandName;
  final String brandModelName;
  final String city;
  final String area;
  final List<String>? images;
  final String numOfOffers;
  final int orderId;
  final String time;
  final bool appliedOffer;
  final String year;
   final String title;
    final VoidCallback? onToggleAppliedOffer;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<SupplierOrdersCubit>();

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: CustomOrderCardWidget(
        orderId: orderId,
        images: images,
        name: name,
        description: description,
        brandName: brandName,
        brandModelName: brandModelName,
        city: city,
        area: area,
        time: time,
        title: title,
        numOfOffers: numOfOffers,
        appliedOffer: appliedOffer,
        isFromMyOffer: false,
        isFromFavorite: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Hide order button
            Expanded(
              child: CustomButton(
                onTap: () {
                  confirmDialog(
                    title:
                        "Do you want to hide this order ? \n this order not shown after hide"
                            .tr(),
                    confirm: "hide order".tr(),
                    cancel: "cancel".tr(),
                    confirmTap: () {
                      cubit.hideOrder(orderId: orderId);
                    },
                  );
                },
                height: 40,
                borderRadius: BorderRadius.circular(8),
                backgroundColor: AppColors.lightRed,
                child: Center(
                  child: Text(
                    "hide".tr(),
                    style: Fonts.textWhite18
                        .copyWith(color: Colors.black, fontSize: 14),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),

            // Send Offer button
            Expanded(
              child: CustomButton(
                onTap: appliedOffer
                    ? null
                    : () {
                        final descriptionController = TextEditingController();
                        final priceController = TextEditingController();

                        confirmDialog(
                          isSendOffer: true,
                          title: "send offer to this order".tr(),
                          confirm: "send".tr(),
                          cancel: "ignore".tr(),
                          descriptionController: descriptionController,
                          priceController: priceController,
                          confirmTap: () {
                            final description =
                                descriptionController.text.trim();
                            final price =
                                int.tryParse(priceController.text.trim()) ?? 0;

                            context.read<SupplierOffersCubit>().createOffer(
                                  orderId: orderId,
                                  description: description,
                                  price: price,
                                );
                            cubit.toggleAndRefresh(orderId);

                            printDebug(
                              "Creating offer for order $orderId with description: $description and price: $price",
                            );
                          },
                        );
                      },
                height: 40,
                borderRadius: BorderRadius.circular(8),
                backgroundColor:
                    appliedOffer ? Colors.green : AppColors.mainColor,
                child: Center(
                  child: Text(
                    appliedOffer ? "offer sent".tr() : "submit_offer".tr(),
                    style: Fonts.textWhite18.copyWith(fontSize: 14),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
