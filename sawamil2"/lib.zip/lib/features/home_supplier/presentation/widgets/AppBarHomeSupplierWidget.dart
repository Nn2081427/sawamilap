import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/favourite/presentation/screens/my_favourites_screen.dart';
import 'package:swamiil/features/notifications/presentation/screens/notifications_screen.dart';

class AppBarHomeSupplierWidget extends StatelessWidget {
  const AppBarHomeSupplierWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          "browse_orders".tr(),
          style: Fonts.text16Orange
              .copyWith(color: Colors.black, fontWeight: FontWeight.w500),
        ),
        Spacer(),
        Container(
          width: 45,
          height: 45,
          padding: const EdgeInsets.all(8),
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              side: BorderSide(
                width: 2,
                color: Colors.grey.shade300,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            shadows: [
              BoxShadow(
                color: Color(0x0F000000),
                blurRadius: 100,
                offset: Offset(0, 0),
                spreadRadius: 0,
              )
            ],
          ),
          child: GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => NotificationsScreen()),
            ),
            child: SvgPicture.asset(
              Assets.notificationsIcon,
              width: 24,
              height: 24,
              fit: BoxFit.contain,
            ),
          ),
        ),
        SizedBox(width: 2.w),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => FavouritesScreenSupplier()),
          ),
          child: Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey.shade300, width: 1.5),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Text(
                  "favorite".tr(),
                  style: Fonts.text16Orange.copyWith(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                SizedBox(width: 8),
                Icon(
                  FontAwesomeIcons.solidHeart,
                  color: Colors.red,
                  size: 18.sp,
                ),
              ],
            ),
          ),
        )
      ],
    );
  }
}
