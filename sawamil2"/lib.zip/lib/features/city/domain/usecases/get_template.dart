import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/city/domain/entities/area_entity.dart';

import '../entities/city_entity.dart';
import '../repositories/template_repository.dart';

class CityUseCase {
  final CityRepository repository;
  CityUseCase({required this.repository});

  Future<Either<DioException, List<AreaEntity>>> getAllArea( {required int cityId}) async {
    return await repository.getAllArea( cityId: cityId);
  }

  Future<Either<DioException, List<CityEntity>>> getAllCities() async {
    return await repository.getAllCities();
  }
}
