class CityEntity {
  final String name;
  final int id;
  CityEntity({required this.name, required this.id});
}
