import 'package:swamiil/features/city/domain/entities/city_entity.dart';

class AreaEntity {
  final int id;
  final String name;
  final CityEntity? city;
  AreaEntity({required this.id, required this.name,required this.city});
}
