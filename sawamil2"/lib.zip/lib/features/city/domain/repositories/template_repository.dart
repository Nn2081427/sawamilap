
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/features/city/domain/entities/area_entity.dart';
import 'package:swamiil/features/city/domain/entities/city_entity.dart';

abstract class CityRepository {
  Future<Either<DioException, List<CityEntity>>> getAllCities();

  Future<Either<DioException, List<AreaEntity>>> getAllArea(
      {required int cityId});
}
