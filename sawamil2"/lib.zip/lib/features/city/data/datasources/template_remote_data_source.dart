
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/features/city/data/models/area_model.dart';
import 'package:swamiil/features/city/data/models/city_model.dart';

class CityRemoteDataSource {
  static Future<Either<DioException, List<CityModel>>> getCities() async {
    var response = await ApiHandel.getInstance.get('get_cities');
    return response.fold((l) => Left(l), (r) {
      List<CityModel> list = [];
      for (var i in r.data['data']) {
        list.add(CityModel.fromJson(i));
      }
      return Right(list);
    });
  }

  static Future<Either<DioException, List<AreaModel>>> getAreas(
      {required int cityId}) async {
    var response =
        await ApiHandel.getInstance.post('get_area_city', {'city_id': cityId});
    return response.fold((l) => Left(l), (r) {
      List<AreaModel> list = [];
      for (var i in r.data['data']) {
        list.add(AreaModel.fromJson(i));
      }
      return Right(list);
    });
  }
}
