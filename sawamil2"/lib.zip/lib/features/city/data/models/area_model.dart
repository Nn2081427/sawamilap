import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/city/data/models/city_model.dart';
import 'package:swamiil/features/city/domain/entities/area_entity.dart';

class AreaModel extends AreaEntity {
  AreaModel({required super.name, required super.id, required super.city});

  factory AreaModel.fromJson(Map<String, dynamic> json) {
    return AreaModel(
        name: json['name'],
        id: convertStringToInt(json['id']),
        city: json['city'] != null ? CityModel.fromJson(json['city']) : null);
  }
}
