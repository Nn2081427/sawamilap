import 'package:swamiil/core/helper_function/convert.dart';
import 'package:swamiil/features/city/domain/entities/city_entity.dart';

class CityModel extends CityEntity {
  CityModel({required super.name, required super.id});

  factory CityModel.fromJson(Map<String, dynamic> json) {
    return CityModel(name: json['name'], id: convertStringToInt(json['id']));
  }
}
