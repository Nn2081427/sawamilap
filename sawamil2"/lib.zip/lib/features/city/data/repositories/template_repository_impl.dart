import 'package:dartz/dartz.dart';

import 'package:dio/src/dio_exception.dart';
import 'package:swamiil/features/city/data/datasources/template_remote_data_source.dart';

import 'package:swamiil/features/city/domain/entities/area_entity.dart';

import 'package:swamiil/features/city/domain/entities/city_entity.dart';

import '../../domain/repositories/template_repository.dart';

class CityRepositoryImpl implements CityRepository {
  @override
  Future<Either<DioException, List<AreaEntity>>> getAllArea(
      {required int cityId}) async {
    return await CityRemoteDataSource.getAreas(cityId: cityId);
  }

  @override
  Future<Either<DioException, List<CityEntity>>> getAllCities() async {
    return await CityRemoteDataSource.getCities();
  }
}
