part of 'cities_cubit.dart';

sealed class CitiesState extends Equatable {
  const CitiesState();

  @override
  List<Object> get props => [];
}

final class CitiesInitial extends CitiesState {}

class CitiesLoading extends CitiesState {}

class CitiesLoaded extends CitiesState {}

class CitiesError extends CitiesState {
  final String message;

  const CitiesError(this.message);

  @override
  List<Object> get props => [message];
}

class CitySelected extends CitiesState {
  final CityEntity? selectedCity;

  const CitySelected(this.selectedCity);
}
