import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/models/drop_down_class.dart';
import 'package:swamiil/features/city/domain/entities/city_entity.dart';
import 'package:swamiil/features/city/domain/usecases/get_template.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';

part 'cities_state.dart';

class CitiesCubit extends Cubit<CitiesState>
    implements DropDownClass<CityEntity> {
  CitiesCubit({required this.useCase}) : super(CitiesInitial());

  final CityUseCase useCase;
  List<CityEntity> cities = [];
  CityEntity? selectedCity;
  Function(int)? onCitySelected;

  Future<void> getCities() async {
    emit(CitiesLoading());
    cities.clear();

    var response = await useCase.getAllCities();
    response.fold((failure) {
      emit(CitiesError(failure.message ?? "Error loading cities"));
    }, (citiesList) {
      cities = citiesList;
      emit(CitiesLoaded());
    });
  }

  void setOnCitySelectedCallback(Function(int) callback) {
    onCitySelected = callback;
  }

  @override
  String displayedName() {
    return selectedCity?.name ?? 'Select_City'.tr();
  }

  @override
  String displayedOptionName(CityEntity type) {
    return type.name;
  }

  @override
  Widget? displayedOptionWidget(CityEntity type) {
    return null;
  }

  @override
  Widget? displayedWidget() {
    return null;
  }

  @override
  List<CityEntity> list() {
    return cities;
  }

  @override
  Future onTap(CityEntity? data) async {
    selectedCity = data;

    Constants.globalContext().read<AreaCubit>().getAreas(data?.id ?? 1);
    emit(CitySelected(data));

    if (onCitySelected != null && data != null) {
      onCitySelected!(data.id);
    }

    return Future.value();
  }

  @override
  CityEntity? selected() {
    return selectedCity;
  }

  @override
  dynamic value() {
    return selectedCity?.id;
  }
}
