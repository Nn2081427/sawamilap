part of 'area_cubit.dart';

abstract class AreaState  {
  const AreaState();

  // @override
  // List<Object?> get coords => [];
}

class AreaInitial extends AreaState {}

class AreasLoading extends AreaState {}

class AreasLoaded extends AreaState {}

class AreasError extends AreaState {
  final String message;

  const AreasError(this.message);

  @override
  List<Object?> get props => [message];
}

class AreaSelected extends AreaState {
  final AreaEntity? selectedArea;

  const AreaSelected(this.selectedArea);

  @override
  List<Object?> get props => [selectedArea];
}