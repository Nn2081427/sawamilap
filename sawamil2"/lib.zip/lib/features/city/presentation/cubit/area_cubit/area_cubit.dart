import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/models/drop_down_class.dart';
import 'package:swamiil/features/city/domain/entities/area_entity.dart';
import 'package:swamiil/features/city/domain/entities/city_entity.dart';
import 'package:swamiil/features/city/domain/usecases/get_template.dart';
import 'package:swamiil/main.dart';

part 'area_state.dart';

class AreaCubit extends Cubit<AreaState> implements DropDownClass<AreaEntity> {
  AreaCubit({required this.useCase}) : super(AreaInitial());
  final CityUseCase useCase;
  List<AreaEntity> areas = [];
  AreaEntity? selectedArea;

  Future<void> getAreas(int cityId) async {
    talker.info("getAreas" + cityId.toString());
    emit(AreasLoading());
    areas.clear();

    var response = await useCase.getAllArea(cityId: cityId);
    response.fold((failure) {
      emit(AreasError(failure.message ?? "Error loading areas"));
    }, (areasList) {
      areas = areasList;
      emit(AreasLoaded());
    });
  }

  @override
  String displayedName() {
    return selectedArea?.name ?? 'Select_Area'.tr();
  }

  @override
  String displayedOptionName(AreaEntity type) {
    return type.name;
  }

  @override
  Widget? displayedOptionWidget(AreaEntity type) {
    return null;
  }

  @override
  Widget? displayedWidget() {
    return null;
  }

  @override
  List<AreaEntity> list() {
    return areas;
  }

  @override
  Future onTap(AreaEntity? data) async {
    selectedArea = data;
    emit(AreaSelected(data));
    return Future.value();
  }

  @override
  AreaEntity? selected() {
    return selectedArea;
  }

  @override
  dynamic value() {
    return selectedArea?.id;
  }
}
