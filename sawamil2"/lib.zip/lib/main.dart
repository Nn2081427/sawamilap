import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:niddler_dart/niddler_dart.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/bloc_observer.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/core/helper_function/dependency_injection.dart';
import 'package:swamiil/core/helper_function/prefs.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/features/Home/Presentation/cubits/date_picker_cubit/date_picker_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/Home/Presentation/cubits/upload%20images%20cubit/upload_images_cubit.dart';
import 'package:swamiil/features/Home/data/data_source/home_remote_data_source.dart';
import 'package:swamiil/features/Home/data/repos/home_repo_Impl.dart';
import 'package:swamiil/features/Home/domain/use_case/home_use_case.dart';
import 'package:swamiil/features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20cubit/brands_cubit.dart';
import 'package:swamiil/features/chat/Presentation/cubits/chat_cubit/chat_cubit.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/data/repos/chat_repository_impl.dart';
import 'package:swamiil/features/chat/domain/use_case/chat_use_case.dart';
import 'package:swamiil/features/city/data/repositories/template_repository_impl.dart';
import 'package:swamiil/features/city/domain/usecases/get_template.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/city/presentation/cubit/cities_cubit.dart';
import 'package:swamiil/features/favourite/presentation/cubit/favourites_cubit_cubit.dart';
import 'package:swamiil/features/layout/cubit/main_layout_cubit.dart';
import 'package:swamiil/features/offers/Presentation/cubits/offers_cubit/offers_cubit.dart';
import 'package:swamiil/features/offers/Presentation/cubits/supplier_offers_cubit/supplier_offers_cubit.dart';
import 'package:swamiil/features/offers/domain/use_case/offers_use_case.dart';
import 'package:swamiil/features/orders/Presentation/cubits/finished_order_cubit/finished_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/new_order_cubit/new_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_cubit.dart';
import 'package:swamiil/features/orders/domain/use_case/order_use_case.dart';
import 'package:swamiil/features/profile/Data/repositries/settings_repo_Impl.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/features/profile/Presentation/cubits/user%20profile%20cubit/user_profile_cubit.dart';
import 'package:swamiil/features/profile/domain/usecases/settings_use_case.dart';
import 'package:swamiil/features/rate/data/data_source/rate_remote_data_source.dart';
import 'package:swamiil/features/rate/data/repos/rate_repo_Impl.dart';
import 'package:swamiil/features/rate/domain/use_case/rate_use_case.dart';
import 'package:swamiil/features/rate/presentation/cubits/rate_cubit/rate_cubit.dart';
import 'package:swamiil/features/rate/presentation/cubits/supplier_profile_cubit/supplier_profile_cubit.dart';
import 'package:swamiil/features/splash/Presentation/cubit/splash_cubit.dart';
import 'package:swamiil/features/splash/Presentation/screens/splash_screen.dart';
import 'package:swamiil/features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_cubit.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';
import 'package:swamiil/firebase_options.dart';
import 'package:talker/talker.dart';

import 'core/helper_function/notifications.dart';
import 'core/models/local_notifications.dart';

// @pragma('vm:entry-point')
// Future<void> firebaseMessagingBackgroundHandler(RemoteMessage event) async {
//   if (event.notification != null) {
//     appNotifications(event.notification!, click: true, fromWhereClicked: 3, payload: event.data);
//   }
// }
// Future<void> localMessagingBackgroundHandler(NotificationResponse pay) async {
//   clickNoti(pay.payload!);
// }

// Global navigator key
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final talker = Talker(
  settings: TalkerSettings(
    colors: {'info': AnsiPen()..yellow()},
    titles: {
      TalkerLogType.exception.toString(): 'Exception',
      TalkerLogType.error.toString(): 'Error',
      TalkerLogType.info.toString(): 'Info',
    },
  ),
);
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  setupDependencies();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await ApiHandel.getInstance.init();
  startSharedPref();
  final niddlerBuilder = NiddlerBuilder()
    ..bundleId = 'com.zeroonez.sawamil.user';
  final niddler = niddlerBuilder.build();
  await niddler.start();
  niddler.install();
  // await notificationsFirebase();
  // FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
  // await NotificationLocalClass.init();
  // await Firebase.initializeApp();

  // await CacheHelper.init();
  // await ServicesLocator().init();

  EasyLocalization.logger.enableBuildModes = [];
  Bloc.observer = MyBlocObserver();

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('en'), Locale('ar')],
      path: 'assets/translation',
      fallbackLocale: const Locale('ar'),
      startLocale: Locale("ar"),
      saveLocale: true,
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => SplashCubit(
            getIt.get<CitiesCubit>(),
            getIt.get<AuthCubit>(),
            getIt.get<BrandsCubit>(),
            getIt.get<SettingsCubit>(),
          ),
        ),
        BlocProvider(
          create: (context) => getIt.get<CitiesCubit>(),
        ),
        BlocProvider(
          create: (context) => getIt.get<FavouritesCubit>(),
        ),
        BlocProvider(
          create: (context) =>
              AreaCubit(useCase: CityUseCase(repository: CityRepositoryImpl())),
        ),
        BlocProvider(
          create: (context) => getIt.get<AuthCubit>(),
        ),
        BlocProvider(
          create: (context) => LayoutCubit(),
        ),
        BlocProvider(
          create: (context) => DatePickerCubit(),
        ),
        BlocProvider(
          create: (context) => ImageCubit(),
        ),
        BlocProvider(
          create: (context) => getIt<RateCubit>(),
        ),
        BlocProvider(
          create: (context) => HomeCubit(
              homeUseCase: HomeUseCase(
                  homeRepo: HomeRepoImpl(
                      homeRemoteDataSource: HomeRemoteDataSource(
                          apiHandel: ApiHandel.getInstance)))),
        ),
        BlocProvider(
          create: (context) => getIt.get<BrandsCubit>(),
        ),
        BlocProvider(
          create: (context) => getIt.get<AuthSupplierCubit>(),
        ),
        BlocProvider(
          create: (context) => getIt.get<SettingsCubit>(),
        ),
        BlocProvider(
          create: (context) => getIt.get<NewOrderCubit>(),
        ),
        BlocProvider(
          create: (context) =>
              FinishedOrdersCubit(orderUseCase: getIt<OrderUseCase>()),
        ),
        BlocProvider(
          create: (context) => getIt.get<WaitingOrdersCubit>(),
        ),
        BlocProvider(
          create: (context) => UserProfileCubit(
              settingsUseCase:
                  SettingsUseCase(settingsRepo: SettingsRepoImpl())),
        ),
        BlocProvider(
          create: (context) =>
              ChatCubit(ChatUseCase(repository: ChatRepositoryImpl())),
        ),
        BlocProvider(
          create: (context) => MessagesCubit(
              chatUseCase: ChatUseCase(repository: ChatRepositoryImpl())),
        ),
        BlocProvider(
          create: (context) => getIt.get<OffersCubit>(),
        ),
        BlocProvider(
            create: (context) =>
                SupplierOffersCubit(useCases: getIt.get<OffersUseCase>())),
        BlocProvider(
          create: (context) =>
              getIt.get<SupplierProfileCubit>()..getSupplierProfile(),
        ),
        BlocProvider(
          create: (context) => SupplierPublicProfileCubit(
              supplierProfileUseCase: RateUseCase(
                  rateRepo: RateRepoImpl(
                      rateRemoteDataSource: RateRemoteDataSource(
                          apiHandel: ApiHandel.getInstance)))),
        ),
      ],
      child: Sizer(
        builder: (context, orientation, deviceType) {
          return GestureDetector(
            onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
            child: AnnotatedRegion(
              value: lightBarColor(),
              child: MaterialApp(
                  debugShowCheckedModeBanner: false,
                  title: 'Swamiil',
                  home: SplashScreen(),
                  navigatorKey: navigatorKey,
                  locale: context.locale,
                  supportedLocales: context.supportedLocales,
                  localizationsDelegates: context.localizationDelegates,
                  theme: defaultTheme),
            ),
          );
        },
      ),
    );
  }
}
