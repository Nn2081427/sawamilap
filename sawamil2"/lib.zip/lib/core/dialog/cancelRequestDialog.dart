import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/main.dart';

Future<String?> cancelRequestDialog() async {
  int selectedReason = -1;
  String? selectedReasonText;
  TextEditingController otherReasonController = TextEditingController();

  return showDialog<String>(
    context: navigatorKey.currentState!.context,
    builder: (BuildContext context) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: StatefulBuilder(builder: (context, setState) {
        final reasons = [
          {"text": "unable_to_agree".tr(), "index": 0},
          {"text": "client_not_responding".tr(), "index": 1},
          {"text": "other_reason".tr(), "index": 2},
        ];

        return Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("why_close_order".tr(), style: Fonts.textBlack18),
                SizedBox(height: 1.h),
                ...reasons.map((reason) => ReasonItem(
                      text: reason["text"]! as String,
                      index: reason["index"]! as int,
                      selectedReason: selectedReason,
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value;
                          if (value != 2) {
                            selectedReasonText =
                                reasons[value]["text"] as String;
                            otherReasonController.clear();
                          } else {
                            selectedReasonText = null;
                          }
                        });
                      },
                    )),
                if (selectedReason == 2) ...[
                  SizedBox(height: 1.h),
                  TextField(
                    controller: otherReasonController,
                    maxLines: 1,
                    decoration: InputDecoration(
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: AppColors.mainColor,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      hintText: "write your reason".tr(),
                      hintStyle: Fonts.text14Black.copyWith(
                        color: Colors.grey,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    onChanged: (value) {
                      setState(() {
                        selectedReasonText =
                            value.trim().isEmpty ? null : value.trim();
                      });
                    },
                  ),
                ],
                SizedBox(height: 1.h),
                Row(
                  children: [
                    Expanded(
                      child: CustomButton(
                        backgroundColor: AppColors.textFieldBgColor,
                        borderRadius: BorderRadius.circular(8),
                        padding: EdgeInsets.symmetric(vertical: 12),
                        onTap: () => Navigator.of(context).pop(),
                        child: Center(
                          child: Text(
                            "cancel".tr(),
                            style: Fonts.text14Black.copyWith(
                                color: Colors.grey,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: CustomButton(
                        backgroundColor: Colors.red,
                        borderRadius: BorderRadius.circular(8),
                        padding: EdgeInsets.symmetric(vertical: 12),
                        onTap: () {
                          // Only pop if a reason is selected or entered
                          if (selectedReasonText != null &&
                              selectedReasonText!.isNotEmpty) {
                            Navigator.of(context).pop(selectedReasonText);
                          }
                        },
                        child: Center(
                          child: Text(
                            "close_order".tr(),
                            style: Fonts.text14Black.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }),
    ),
  );
}

class ReasonItem extends StatelessWidget {
  final String text;
  final int index;
  final int selectedReason;
  final Function(int) onChanged;

  const ReasonItem({
    super.key,
    required this.text,
    required this.index,
    required this.selectedReason,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onChanged(index),
      child: Container(
        width: double.infinity,
        height: 50,
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.5.h),
        margin: EdgeInsets.only(bottom: 1.5.h),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: selectedReason == index
                ? AppColors.mainColor
                : Colors.grey[300]!,
            width: selectedReason == index ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Checkbox(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              value: selectedReason == index,
              onChanged: (value) => onChanged(index),
              activeColor: AppColors.mainColor,
              checkColor: Colors.white,
              side: BorderSide(color: Colors.grey[300]!),
            ),
            Expanded(
              child: Text(
                text,
                style: Fonts.text14Black
                    .copyWith(fontSize: 16.sp, color: Colors.grey),
                textAlign: TextAlign.right,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
