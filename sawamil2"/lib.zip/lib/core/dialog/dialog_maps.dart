// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';
// import 'package:maps_launcher/maps_launcher.dart';
// import 'package:sizer/sizer.dart';

// import '../constants/constants.dart';

// openDialogMapsSheet(double lat, double long) async {
//   try {
//     final coords = Coord(lat, long);
//     const title = "Order Address";
//     final availableMaps = await MapsLauncher();

//     showModalBottomSheet(
//       context: Constants.globalContext(),
//       builder: (BuildContext context) {
//         return SafeArea(
//           child: SingleChildScrollView(
//             child: Wrap(
//               children: <Widget>[
//                 for (var map in availableMaps)
//                   ListTile(
//                     onTap: () => map.showMarker(coords: coords, title: title),
//                     title: Text(map.mapName),
//                     leading: SvgPicture.asset(map.icon, height: 10.h, width: 10.h),
//                   ),
//               ],
//             ),
//           ),
//         );
//       },
//     );
//   } catch (e) {}
// }
