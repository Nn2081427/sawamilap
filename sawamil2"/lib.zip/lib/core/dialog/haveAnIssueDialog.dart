import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/main.dart';

void haveAnIssueDialog({
  String? title,
  void Function()? okButtonTap,
  void Function()? cancelButtonTap,
  String? okButtonText,
  String? cancelButtonText,
  TextEditingController? controller,
}) {
//  TextEditingController controller = TextEditingController();

  showDialog(
    context: navigatorKey.currentState!.context,
    builder: (BuildContext context) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
        width: 80.w,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title ?? "issue_with_order".tr(),
              style: Fonts.textBlack18,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Container(
              decoration: BoxDecoration(
                color: AppColors.textFieldBgColor,
                borderRadius: BorderRadius.circular(8),
              ),
              padding: EdgeInsets.all(1.w),
              child: TextFormField(
                controller: controller,
                maxLines: 4,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: "tell_us_your_issue".tr(),
                  hintStyle: TextStyle(color: Colors.black.withOpacity(0.5)),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(2.w),
                ),
                style: TextStyle(color: Colors.black),
              ),
            ),
            SizedBox(height: 2.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: CustomButton(
                      backgroundColor: AppColors.textFieldBgColor,
                      borderRadius: BorderRadius.circular(8),
                      padding: EdgeInsets.symmetric(vertical: 1.5.h),
                      onTap: cancelButtonTap ?? () => navPop(),
                      child: Center(
                        child: Text(
                          cancelButtonText ?? "ignore".tr(),
                          style: Fonts.text14Black.copyWith(color: Colors.grey),
                        ),
                      )),
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: CustomButton(
                      backgroundColor: AppColors.mainColor,
                      padding: EdgeInsets.symmetric(vertical: 1.5.h),
                      borderRadius: BorderRadius.circular(8),
                      onTap: okButtonTap,
                      child: Center(
                        child: Text(
                          okButtonText ?? "send".tr(),
                          style:
                              Fonts.text14Black.copyWith(color: Colors.white),
                        ),
                      )),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
