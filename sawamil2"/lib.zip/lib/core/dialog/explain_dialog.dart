import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/main.dart';

enum OrderType {
  assigned('مقيد'),
  pending('معلق'),
  completed('مكتمل'),
  cancelled('ملغى');

  final String arabicName;
  const OrderType(this.arabicName);
}

void explainDialog(
    {required String orderDescription,
    required String orderStatus,
    required Color orderStatusColorContainer}) {
  showDialog(
    context: navigatorKey.currentState!.context,
    builder: (BuildContext context) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
        width: 80.w,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: ShapeDecoration(
                  color: orderStatusColorContainer.withOpacity(0.1),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6)),
                ),
                child: Text(
                  orderStatus,
                  style: Fonts.text16Orange
                      .copyWith(color: orderStatusColorContainer),
                ),
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              orderDescription,
              style: Fonts.text14Black.copyWith(fontWeight: FontWeight.w500),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: CustomButton(
                    backgroundColor: AppColors.mainColor,
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    borderRadius: BorderRadius.circular(8),
                    child: Center(
                      child: Text(
                        "okay_understood".tr(),
                        style: Fonts.text14Black.copyWith(color: Colors.white),
                      ),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
