import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/widgets/svg_widget.dart';

import '../constants/constants.dart';

void customAlertDialog(
    {String? image,
    required String title,
    required String content,
    double? top,
    required String confirm,
    Color? color,
    Color? backConfirm,
    Color? backCancel,
    required void Function() confirmTap,
    bool? confirmFound,
    double? padding,
    required String cancel,
    required void Function() cancelTap}) {
  showDialog(
    context: Constants.globalContext(),
    builder: (BuildContext context) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
        content: Stack(
          alignment: AlignmentDirectional.topStart,
          clipBehavior: Clip.none,
          children: [
            if (image != null)
              Positioned(
                  top: top ?? -16.h,
                  right: 0,
                  left: 0,
                  child: Container(
                      width: 35.w,
                      height: 35.w,
                      padding: EdgeInsets.all(padding ?? 0),
                      decoration:
                          BoxDecoration(shape: BoxShape.circle, color: color),
                      child: image.contains('.svg')
                          ? SvgWidget(svg: image, fit: BoxFit.contain)
                          : Image.asset(image, fit: BoxFit.contain))),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("warning"),
                SizedBox(height: 0.5.h),
                Text("warning"),
                SizedBox(height: 3.h),
                Row(
                  children: [
                    if (confirmFound == null)
                      Expanded(
                        child: InkWell(
                          onTap: confirmTap,
                          child: Container(
                              padding: EdgeInsets.all(2.w),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: backConfirm ?? AppColors.mainColor),
                              child: Text("confirm")),
                        ),
                      ),
                    if (confirmFound == null) SizedBox(width: 1.w),
                    Expanded(
                      child: InkWell(
                        onTap: cancelTap,
                        child: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                color: backCancel ?? Color(0xff8E8E8E)),
                            child: Text("cancel")),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
        // actions: <Widget>[
        //   TextButton(
        //     onPressed: cancelTap,
        //     child: Text(cancel),
        //   ),
        //   ElevatedButton(
        //     onPressed: confirmTap,
        //     child: Text(confirm),
        //   ),
        // ],
      );
    },
  );
}
