import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

import '../constants/constants.dart';

void showToast(String text,
    {Color? color, String? title, bool normalToast = false,bool success = false}) {
  if (normalToast) {
    Fluttertoast.showToast(
      msg: text,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.TOP,
      timeInSecForIosWeb: 3,
      backgroundColor: color ?? AppColors.mainColor,
      textColor: Colors.white,
      fontSize: 20.sp,
    );
  } else {
    final materialBanner = MaterialBanner(
      /// need to set following properties for best effect of awesome_snackbar_content
      elevation: 2,
      shadowColor: Colors.transparent,
      backgroundColor: Colors.transparent,

      forceActionsBelow: true,
      content: AwesomeSnackbarContent(
        title: (success?'success':'error').tr(),
        message: text.replaceAll('\n',
            "\n---------------------------------------------------------\n"),

        /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
        contentType: ContentType.warning,
        messageTextStyle: Fonts.textWhite18,
        titleTextStyle: Fonts.textWhite18.copyWith(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        color: color ?? AppColors.mainColor,
        // to configure for material banner
        inMaterialBanner: true,
      ),
      actions: const [
        SizedBox.shrink(),
      ],
    );

    ScaffoldMessenger.of(Constants.globalContext())
      ..hideCurrentMaterialBanner()
      ..showMaterialBanner(materialBanner);
    Future.delayed(Duration(seconds: 3), () {
      ScaffoldMessenger.of(Constants.globalContext())
          .hideCurrentMaterialBanner();
    });
  }
}
