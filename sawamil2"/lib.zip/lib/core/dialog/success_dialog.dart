import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/main.dart';
import '../constants/constants.dart';

void successDialog({var then, String? msg, String? lottie, int? sec}) async {
  showDialog(
    context: navigatorKey.currentState!.context,
    builder: (context) {
      return Dialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: SafeArea(
          child: Padding(
            padding: MediaQuery.of(context).viewInsets,
            child: InkWell(
              onTap: () {
                FocusScope.of(context).unfocus();
              },
              child: Container(
                width: 100.w,
                constraints: BoxConstraints(
                  maxHeight: Constants.isTablet ? 50.h : 35.h,
                  minHeight: Constants.isTablet ? 50.h : 35.h,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 5.w),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(
                          height: 3.h,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: (30.w) / 2),
                          child: lottie != null
                              ? Lottie.asset(lottie,
                                  fit: BoxFit.contain, width: 40.w)
                              : Image.asset('assets/images/success.gif',
                                  fit: BoxFit.contain, width: 40.w),
                        ),
                        SizedBox(
                          height: 0.h,
                        ),
                        Text(
                          msg ?? "success".tr(),
                          style: Fonts.text16Black,
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(
                          height: 2.h,
                        ),
                        CustomButton(
                          width: double.infinity,
                          backgroundColor: AppColors.mainColor,
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          borderRadius: BorderRadius.circular(8),
                          child: Center(
                            child: Text(
                              "ok".tr(),
                              style: Fonts.text14Black
                                  .copyWith(color: Colors.white),
                            ),
                          ),
                          onTap: () {
                            Navigator.pop(context);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    },
  ).then((value) {
    if (then != null) {
      then();
    }
  });
}
