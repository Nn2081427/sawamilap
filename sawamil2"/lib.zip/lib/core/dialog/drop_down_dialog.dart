import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/text_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/drop_down_option_widget.dart';
import 'package:swamiil/core/widgets/main_search_widget.dart';

import '../constants/constants.dart';
import '../helper_function/helper_function.dart';
import '../helper_function/navigation.dart';
import '../models/drop_down_class.dart';

Future showDropDownDialog(DropDownClass dropDownClass,
    {String? title,
    String? buttonText,
    void Function()? buttonOnTap,
    void Function()? onChanged,
    TextEditingController? controller}) async {
  dynamic selected = dropDownClass.selected();
  return await showModalBottomSheet(
    context: Constants.globalContext(),
    backgroundColor: Colors.transparent,
    isDismissible: true,
    isScrollControlled: true,
    enableDrag: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25), topRight: Radius.circular(25))),
    builder: (context) {
      final bottomPadding = MediaQuery.of(context).viewInsets.bottom;
      final screenHeight = MediaQuery.of(context).size.height;
      final maxHeight = screenHeight * 0.8; // Allow up to 80% of screen height

      return SafeArea(
        bottom: false,
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Container(
            width: 100.w,
            constraints: BoxConstraints(
              maxHeight:
                  bottomPadding > 0 ? maxHeight + bottomPadding : maxHeight,
              minHeight: 20.h, // Minimum height
            ),
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(25),
                    topRight: Radius.circular(25))),
            child: StatefulBuilder(builder: (context, setState) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Handle bar for better UX
                  Container(
                    margin: EdgeInsets.only(top: 1.h),
                    width: 12.w,
                    height: 0.5.h,
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),

                  // Fixed header section (title + search)
                  if (title != null || controller != null)
                    Container(
                      padding: EdgeInsets.fromLTRB(5.w, 2.h, 5.w, 1.h),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Title if provided
                          if (title != null) ...[
                            Text(title,
                                style: TextStyleClass.semiStyle().copyWith(
                                    fontSize: 18, fontWeight: FontWeight.bold)),
                            SizedBox(height: 1.5.h),
                          ],

                          // Search widget if controller is provided
                          if (controller != null) ...[
                            MainSearchWidget(
                              controller: controller,
                              onChange: (s) async {
                                await delay(500);
                                setState(() {});
                                if (onChanged != null) {
                                  onChanged();
                                }
                              },
                            ),
                            SizedBox(height: 1.h),
                          ],
                        ],
                      ),
                    ),

                  // Scrollable content area
                  Flexible(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 5.w),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: dropDownClass.list().isEmpty
                            ? SizedBox(
                                height: 15.h,
                                child: Center(
                                  child: Text(
                                    "no_data".tr(),
                                    style: TextStyleClass.normalStyle()
                                        .copyWith(
                                            color: Colors.grey,
                                            fontSize: 15.sp),
                                  ),
                                ),
                              )
                            : Scrollbar(
                                thumbVisibility: true,
                                thickness: 4,
                                radius: const Radius.circular(10),
                                child: ListView.separated(
                                  itemCount: dropDownClass.list().length,
                                  shrinkWrap: true,
                                  physics: const BouncingScrollPhysics(),
                                  padding: EdgeInsets.symmetric(vertical: 1.h),
                                  separatorBuilder: (context, index) =>
                                      const Divider(
                                          height: 1, color: Colors.transparent),
                                  itemBuilder: (ctx, index) {
                                    dynamic data = dropDownClass.list()[index];
                                    return DropDownOptionWidget(
                                      dropDownClass: dropDownClass,
                                      data: data,
                                      selected: selected,
                                      rebuild: () {
                                        selected = data;
                                        setState(() {});
                                      },
                                    );
                                  },
                                ),
                              ),
                      ),
                    ),
                  ),

                  // Fixed button at bottom
                  Container(
                    padding: EdgeInsets.fromLTRB(5.w, 1.h, 5.w,
                        bottomPadding > 0 ? bottomPadding + 1.h : 2.h),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(0, -2),
                        ),
                      ],
                    ),
                    child: SizedBox(
                      width: double.infinity,
                      child: CustomButton(
                        padding: EdgeInsets.symmetric(vertical: 1.5.h),
                        borderRadius: BorderRadius.circular(10),
                        backgroundColor: AppColors.mainColor,
                        onTap: buttonOnTap ??
                            () async {
                              navPop(selected);
                              await dropDownClass.onTap(selected);
                            },
                        buttonText: buttonText ?? "save".tr(),
                      ),
                    ),
                  ),
                ],
              );
            }),
          ),
        ),
      );
    },
  );
}
