import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/dialog/snack_bar.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/text_field.dart';
import 'package:swamiil/features/rate/presentation/cubits/rate_cubit/rate_cubit.dart';
import 'package:swamiil/main.dart';

void showRatingDialog({required int orderId}) {
  TextEditingController controller = TextEditingController();
  int selectedRating = 0;
  bool isSubmitting = false;
  String? commentError;
  String? ratingError;

  showDialog(
    context: navigatorKey.currentState!.context,
    barrierDismissible: false,
    builder: (BuildContext context) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: StatefulBuilder(
        builder: (context, setState) {
          bool validateInputs() {
            bool isValid = true;

            if (selectedRating == 0) {
              setState(() {
                ratingError = "please_select_rating".tr();
              });
              isValid = false;
            } else {
              setState(() {
                ratingError = null;
              });
            }

            if (controller.text.trim().isEmpty) {
              setState(() {
                commentError = "comment_required".tr();
              });
              isValid = false;
            } else if (controller.text.trim().length < 3) {
              setState(() {
                commentError = "comment_too_short".tr();
              });
              isValid = false;
            } else {
              setState(() {
                commentError = null;
              });
            }

            return isValid;
          }

          void submitRating() {
            if (validateInputs()) {
              setState(() {
                isSubmitting = true;
              });

              context
                  .read<RateCubit>()
                  .rateSupplier(
                    rate: selectedRating.toDouble(),
                    orderId: orderId,
                    comment: controller.text.trim(),
                  )
                  .then((_) {
                controller.clear();
                navPop();
              }).catchError((error) {
                setState(() {
                  isSubmitting = false;
                });
                showToast(error.toString());
              });
            }
          }

          return Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
            margin: EdgeInsets.symmetric(horizontal: 1.5.w),
            //   width: 80.w,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "rate_seller_question".tr(),
                    style: Fonts.textBlack18,
                  ),
                  SizedBox(height: 2.h),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      "rating".tr(),
                      style: Fonts.text14Black
                          .copyWith(fontWeight: FontWeight.w500),
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Container(
                    //     margin: EdgeInsets.symmetric(horizontal: 3.w),
                    padding: EdgeInsets.symmetric(
                        vertical: 1.5.h, horizontal: 2.5.w),
                    decoration: BoxDecoration(
                      color: AppColors.textFieldBgColor.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(8),
                      border: ratingError != null
                          ? Border.all(color: Colors.red, width: 1)
                          : null,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(5, (index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedRating = index + 1;
                              ratingError = null;
                            });
                          },
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 1.w),
                            child: Icon(
                              FontAwesomeIcons.solidStar,
                              size: 8.w,
                              color: index < selectedRating
                                  ? Colors.amber
                                  : Colors.grey[300],
                            ),
                          ),
                        );
                      }).reversed.toList(),
                    ),
                  ),
                  if (ratingError != null)
                    Padding(
                      padding: EdgeInsets.only(top: 0.5.h, right: 1.w),
                      child: Text(
                        ratingError!,
                        style: TextStyle(color: Colors.red, fontSize: 12),
                      ),
                    ),
                  SizedBox(height: 2.h),
                  TextFieldWidget(
                    controller: controller,
                    maxLines: 8,
                    borderColor: Colors.black.withOpacity(0.1),
                    hintText: "write_comment".tr(),
                    hintStyle: Fonts.text14Black.copyWith(
                        color: Colors.black.withOpacity(0.6),
                        fontWeight: FontWeight.w500),
                    style: Fonts.text14Black,
                    onChange: (value) {
                      if (commentError != null) {
                        setState(() {
                          commentError = null;
                        });
                      }
                    },
                  ),
                  if (commentError != null)
                    Padding(
                      padding: EdgeInsets.only(top: 0.5.h, right: 1.w),
                      child: Text(
                        commentError!,
                        style: TextStyle(color: Colors.red, fontSize: 12),
                      ),
                    ),
                  SizedBox(height: 2.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: CustomButton(
                          backgroundColor: AppColors.textFieldBgColor,
                          borderRadius: BorderRadius.circular(8),
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          onTap: isSubmitting
                              ? null
                              : () {
                                  navPop();
                                  controller.clear();
                                },
                          child: Center(
                            child: Text(
                              "ignore".tr(),
                              style: Fonts.text14Black.copyWith(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black.withOpacity(0.5)),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: CustomButton(
                          backgroundColor: AppColors.mainColor,
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          borderRadius: BorderRadius.circular(8),
                          onTap: isSubmitting ? null : submitRating,
                          child: Center(
                            child: isSubmitting
                                ? SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Text(
                                    "send".tr(),
                                    style: Fonts.text14Black.copyWith(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w500),
                                  ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    ),
  );
}
