import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/core/widgets/text_field.dart';
import 'package:swamiil/main.dart';

void showCustomInputDialog({
  required String title,
  required int textFieldCount,
  required List<String> hintTexts,
  String? supportMessage,
  required String cancelButtonText,
  required String submitButtonText,
  required Color submitButtonColor,
  VoidCallback? onSubmit,
}) {
  assert(hintTexts.length >= textFieldCount, 'Not enough hint texts provided');

  final List<TextEditingController> controllers = List.generate(
    textFieldCount,
    (_) => TextEditingController(),
  );

  showDialog(
    context: navigatorKey.currentState!.context,
    builder: (BuildContext context) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Fonts.textBlack18,
                textAlign: TextAlign.start,
              ),
              SizedBox(height: 0.h),
              ...List.generate(
                textFieldCount,
                (index) => Column(
                  children: [
                    InputField(
                      controller: controllers[index],
                      hintText: hintTexts[index],
                    ),
                  ],
                ),
              ),
              if (supportMessage != null)
                Text(
                  supportMessage,
                  style: Fonts.text14Black.copyWith(
                    color: Colors.grey,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              SizedBox(height: 1.h),
              Row(
                children: [
                  Expanded(
                    child: CustomButton(
                      backgroundColor: AppColors.textFieldBgColor,
                      borderRadius: BorderRadius.circular(8),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Center(
                        child: Text(
                          cancelButtonText,
                          style: Fonts.text14Black.copyWith(
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      onTap: () => Navigator.pop(context),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: CustomButton(
                      backgroundColor: submitButtonColor,
                      borderRadius: BorderRadius.circular(8),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Center(
                        child: Text(
                          submitButtonText,
                          style: Fonts.text14Black.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        if (onSubmit != null) {
                          onSubmit();
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;

  const InputField({
    super.key,
    required this.controller,
    required this.hintText,
  });

  @override
  Widget build(BuildContext context) {
    return TextFieldWidget(
      hintText: hintText,
      controller: controller,
      hintStyle: Fonts.text14Black.copyWith(
        fontWeight: FontWeight.w500,
        fontSize: 14.sp,
      ),
      textAlign: TextAlign.right,
      borderColor: Colors.grey.shade300,
      style: const TextStyle(color: Colors.black),
    );
  }
}
