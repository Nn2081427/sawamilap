import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/main.dart';
import '../constants/constants.dart';

void confirmDialog({
  required String title,
  required String confirm,
  required String? cancel,
  required void Function() confirmTap,
  void Function()? cancelTap,
  bool? isDismiss,
  bool? isSendOffer,
  TextEditingController? descriptionController,
  TextEditingController? priceController,
}) {
  showDialog(
    context: navigatorKey.currentState!.context,
    barrierDismissible: isDismiss ?? false,
    builder: (BuildContext context) => Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        width: Constants.isTablet ? 40.w : double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dialog title
            Text(
              title,
              style: Fonts.textBlack18,
              textAlign: TextAlign.center,
            ),

            SizedBox(height: 3.h),
            isSendOffer == true
                ? Column(
                    children: [
                      SizedBox(
                        // height: 50,
                        child: TextFormField(
                          maxLines: 3,
                          minLines: 1,
                          controller: descriptionController,
                          decoration: InputDecoration(
                            floatingLabelStyle: Fonts.text14Black,
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide(
                                    color: AppColors.mainColor, width: 2)),
                            fillColor: Colors.white,
                            filled: true,
                            labelText:
                                "write some information for your offer...".tr(),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide:
                                  BorderSide(color: Colors.grey.shade100),
                            ),
                          ),
                          keyboardType: TextInputType.text,
                          style: Fonts.text16Black,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      SizedBox(
                        height: 50,
                        child: TextFormField(
                          controller: priceController,
                          decoration: InputDecoration(
                            floatingLabelStyle: Fonts.text14Black,
                            focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppColors.mainColor, width: 2)),
                            fillColor: Colors.white,
                            filled: true,
                            labelText: "add value".tr(),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide:
                                  BorderSide(color: AppColors.textFieldBgColor),
                            ),
                          ),
                          keyboardType: TextInputType.text,
                          style: Fonts.text16Black,
                        ),
                      ),
                    ],
                  )
                : SizedBox.shrink(),
            SizedBox(height: 1.h),

            // Action buttons
            Row(
              children: [
                // Cancel button
                Expanded(
                  child: CustomButton(
                    backgroundColor: AppColors.textFieldBgColor,
                    borderRadius: BorderRadius.circular(8),
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    onTap: cancelTap ??
                        () {
                          Navigator.pop(context);
                        },
                    child: Center(
                      child: Text(cancel ?? "تجاهل",
                          style: Fonts.text16Black.copyWith()
                          //  TextStyle(
                          //   color: Colors.black,
                          //   fontSize: Constants.isTablet ? 2.5.sp : 14.sp,
                          // ),
                          ),
                    ),
                  ),
                ),

                SizedBox(width: 2.w),

                // Confirm button
                Expanded(
                  child: CustomButton(
                    backgroundColor: isSendOffer == true
                        ? Colors.green
                        : AppColors.mainColor,
                    borderRadius: BorderRadius.circular(8),
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    child: Center(
                      child: Text(confirm,
                          style: Fonts.text16Black.copyWith(
                            color: isSendOffer == true
                                ? Colors.white
                                : Colors.white,
                          )),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                      Future.delayed(Duration(milliseconds: 100), () {
                        confirmTap();
                      });
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}
