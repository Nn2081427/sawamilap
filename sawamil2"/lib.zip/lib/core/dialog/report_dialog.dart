import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/widgets/custom_button.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/main.dart';

void reportDialog(
    {required String title, required String type, required int id}) {
  TextEditingController controller = TextEditingController();

  final formKey = GlobalKey<FormState>();
  showDialog(
    context: navigatorKey.currentState!.context,
    builder: (BuildContext context) => Dialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                Assets.reportDialogIcon,
                height: 7.h,
                width: 10.h,
              ),
              SizedBox(height: 1.h),
              Container(
                decoration: BoxDecoration(
                  color: Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.all(8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.edit_note, color: Colors.black54),
                    SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        controller: controller,
                        maxLines: 5,
                        textAlign: TextAlign.right,
                        decoration: InputDecoration(
                          hintText: "اكتب رأيك او المشكلة التي تواجهها...",
                          hintStyle: Fonts.text14Black.copyWith(
                              color: Colors.black.withOpacity(0.3),
                              fontWeight: FontWeight.w500),
                          border: InputBorder.none,
                        ),
                        style: TextStyle(color: Colors.black),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 16),
              CustomButton(
                width: double.infinity,
                backgroundColor: AppColors.mainColor,
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
                borderRadius: BorderRadius.circular(8),
                child: Center(
                  child: Text(
                    "send".tr(),
                    style: Fonts.text14Black.copyWith(color: Colors.white),
                  ),
                ),
                onTap: () {
                  if (formKey.currentState!.validate()) {
                    context.read<SettingsCubit>().contactUs(data: {
                      "message": controller.text,
                    });
                    navPop();
                  }
                },
              ),
              SizedBox(height: 8),
              CustomButton(
                width: double.infinity,
                backgroundColor: AppColors.textFieldBgColor,
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
                borderRadius: BorderRadius.circular(8),
                child: Center(
                  child: Text(
                    "ignore".tr(),
                    style: Fonts.text14Black.copyWith(color: Colors.grey),
                  ),
                ),
                onTap: () {
                  navPop();
                },
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
