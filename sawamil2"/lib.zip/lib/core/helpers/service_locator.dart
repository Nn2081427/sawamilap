// import 'package:dio/dio.dart';
// import 'package:get_it/get_it.dart';
// import 'package:google_sign_in/google_sign_in.dart';
// import 'package:internet_connection_checker/internet_connection_checker.dart';
// import 'package:package_info_plus/package_info_plus.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:swamiil/core/api/dio.dart';
// import 'package:swamiil/core/utilies/app_preferences.dart';

// final getIt = GetIt.instance;

// class ServicesLocator {
//   Future<void> init() async {
//     /// TregoDio
//     SwamiilDio dio = SwamiilDio();
//     dio.init();
//     PackageInfo packageInfo = await PackageInfo.fromPlatform();
//     getIt.registerLazySingleton<PackageInfo>(() => packageInfo);
//     getIt.registerLazySingleton<Dio>(() => Dio());

//     /// App Preferences
//     getIt.registerLazySingleton<AppPreferences>(() => AppPreferences(getIt()));

//     /// Shared Preferences
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//     getIt.registerFactory<SharedPreferences>(() => sharedPreferences);

//     /// Network info

//     /// Network Connection checker
//     getIt.registerLazySingleton<InternetConnectionChecker>(
//         () => InternetConnectionChecker());

//     /// Google SignIn
//     getIt.registerLazySingleton(() => GoogleSignIn(scopes: ["email"]));
//   }
// }
