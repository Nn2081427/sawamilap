import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/constants/assets.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';

import '../../main.dart';

class Constants {
  // static final GlobalKey<NavigatorState> navState = GlobalKey<NavigatorState>();
  static const String baseUrl = 'https://swamil.zeroonez.com';
  static const String domainApi = "$baseUrl/api/";
  static const String packageName = "com.zeroonez.sawamil.user";
  static bool isTablet = false;
  static BuildContext globalContext() {
    return navigatorKey.currentContext!;
  }
}

void printDebug(dynamic text) {
  if (kDebugMode) {
    print(text.toString());
  }
}

// /// layout icons
List<Map<String, String>> userAssetsIcons = [
  {
    "selected": Assets.selectedHomeIcon,
    "unselected": Assets.homeIcon,
  },
  {
    "selected": Assets.selectedOrdersIcon,
    "unselected": Assets.ordersIcon,
  },
  {
    "selected": Assets.selectedChatIcon,
    "unselected": Assets.chatIcon,
  },
  // {
  //   "selected":
  //       navigatorKey.currentContext!.read<AuthCubit>().userEntity?.image ?? "",
  //   "unselected":
  //       navigatorKey.currentContext!.read<AuthCubit>().userEntity?.image ?? "",
  // },
];

/// tabs layout Names
List<String> userTabsNames = [
  "Home".tr(),
  "Orders".tr(),
  "Chats".tr(),
  "Profile".tr(),
];
List<String> supplierTabsNames = [
  "Orders".tr(),
  "My Offers".tr(),
  "Clients".tr(),
  "Profile".tr(),
];
List<Map<String, String>> supplierAssetsIcons = [
  {
    "selected": Assets.selectedOrdersIcon,
    "unselected": Assets.ordersIcon,
  },
  {
    "selected": Assets.selectedTicketIcon,
    "unselected": Assets.unSelectedTicketIcon,
  },
  {
    "selected": Assets.selectedClientsIcon,
    "unselected": Assets.unSelectedClientsIcon,
  },
  {
    "selected": Assets.profileIcon,
    "unselected": Assets.profileIcon,
  },
];
