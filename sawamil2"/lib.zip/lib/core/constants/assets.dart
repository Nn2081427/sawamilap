class Assets {
  /// Images
  static const String logoSplash = "assets/images/splashLogo.png";
  static const String dashedSplash = "assets/images/dashedImage.png";
  static const String introImage = "assets/images/introImage.png";
  static const String whiteLogoBg = "assets/images/white_logo_login.png";
  static const String heundayIcon = "assets/images/huyendaiImage.png";
  static const String benzIcon = "assets/images/benzImage.png";
  static const String skodaIcon = "assets/images/skodaImage.png";
  static const String mazdaIcon = "assets/images/mazdaImage.png";
  static const String pegoutIcon = "assets/images/pegoutImage.png";
  static const String carUploadImage = "assets/images/car_upload_image.png";
  static const String chatUser1 = "assets/images/chat1.png";
  // static const String chatUser2 = "assets/images/chat2.png";
  static const String chatUser3 = "assets/images/chat3.png";
  static const String chatUser4 = "assets/images/chat4.png";
  static const String userProfile = "assets/images/person1.png";
  static const String supplierImageProfile =
      "assets/images/user_profile_image.png";
  static const String cameraImage = "assets/images/camera.svg";

  static const String onboarding1 = 'assets/images/onBoarding_image_1.png';
  static const String onboarding2 = 'assets/images/onBoarding_image_2.png';
  static const String onboarding3 = 'assets/images/onBoarding_image_3.png';

  /// Icons
  static const String userIcon = "assets/icons/user.svg";
  static const String boxIcon = "assets/icons/box-tick.svg";
  static const String coffeeIcon = "assets/icons/coffee.svg";
  static const String arrowBack = "assets/icons/Arrow.svg";
  static const String googleIcon = "assets/icons/googleIcon.svg";
  static const String appleIcon = "assets/icons/apple.svg";
  static const String notificationsIcon = "assets/icons/notificationsIcon.svg";
  static const String cameraIcon = "assets/icons/cameraIcon.svg";
  static const String homeIcon = "assets/icons/homeIcon.png";
  static const String selectedHomeIcon = "assets/icons/selectedHomeIcon.png";
  static const String chatIcon = "assets/icons/chatIcon.png";
  static const String selectedChatIcon = "assets/icons/selectedChatIcon.png";
  static const String ordersIcon = "assets/icons/ordersIconpng.png";
  static const String selectedOrdersIcon =
      "assets/icons/ordersSelectedIcon.png";
  static const String profileIcon = "assets/images/person2.png";
  static const String locationIcon = "assets/icons/Location.svg";
  static const String deleteIcon = "assets/icons/trash.svg";
  static const String emailIcon = "assets/icons/email.svg";
  static const String privacyIcon = "assets/icons/headphone.svg";
  static const String logoutIcon = "assets/icons/logout.svg";
  static const String messageIcon = "assets/icons/message.svg";
  static const String profileIcon2 = "assets/icons/profile-circle.svg";
  static const String whoweareIcon = "assets/icons/who_we_are.svg";
  static const String termsAndConditionsIcon = "assets/icons/terms.svg";
  static const String editIcon = "assets/icons/edit.svg";
  static const String personIcon = "assets/icons/person.svg";
  static const String locationOutlinedIcon =
      "assets/icons/location_outlined.svg";
  static const String timerIcon = "assets/icons/timer.svg";
  static const String offersIcon = "assets/icons/offers.svg";
  static const String reportDialogIcon = "assets/icons/report_dialogPng.png";
  static const String unSelectedTicketIcon =
      "assets/icons/unselected_ticket.png";
  static const String selectedTicketIcon =
      "assets/icons/seletcted_ticket_icon.png";
  static const String unSelectedClientsIcon =
      "assets/icons/unSelectedClientsIcon.png";
  static const String selectedClientsIcon =
      "assets/icons/selected_clients_icon.png";
  static const String hidIcon = "assets/icons/Hide.svg";
  static const String walletIcon = "assets/icons/walletIcon.svg";
  static const String clientsRating = "assets/icons/clients_rating_icon.svg";
  static const String currencyIcon = "assets/icons/currencyIcon.png";
  static const String serachIcon = "assets/icons/search.svg";
  static const String filterIcon = "assets/icons/filter.svg";
  static const String changePassword = "assets/icons/change_password.svg";
// Jsons
  static const String lottieSuccess = "assets/json/lottie_success.json";
  static const String loadingLottie = "assets/json/loading_lottie.json";
  static const String emptyLottie = "assets/json/no_orders.json";
  static const String emptyListLottie = "assets/json/empty_list.json";
}
