import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';

ThemeData defaultTheme = ThemeData(
    useMaterial3: false,
    primaryColor: AppColors.mainColor,
    unselectedWidgetColor: Colors.white,
    scaffoldBackgroundColor: Colors.white,
    checkboxTheme: checkboxThemeData,
    dividerColor: Colors.transparent,
    radioTheme: radioThemeData,
    tabBarTheme: tabBarTheme,
    appBarTheme: appBarTheme,
    fontFamily: "DIN",
    splashColor: Colors.transparent);

AppBarTheme appBarTheme = AppBarTheme(
  color: Colors.white,
  centerTitle: true,
  foregroundColor: Colors.black,
  systemOverlayStyle: barColor(),
  elevation: 0,
  toolbarHeight: 7.5.h,
  titleTextStyle: TextStyle(
      fontFamily: "DIN",
      fontWeight: FontWeight.bold,
      fontSize: 16.sp,
      color: Colors.black),
);

EdgeInsets globalPadding = EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.h);

CheckboxThemeData checkboxThemeData = CheckboxThemeData(
    fillColor: WidgetStateProperty.all<Color>(Colors.transparent),
    checkColor: WidgetStateProperty.all<Color>(AppColors.mainColor),
    overlayColor: WidgetStateProperty.all<Color>(AppColors.mainColor),
    visualDensity: VisualDensity.compact);

RadioThemeData radioThemeData = RadioThemeData(
  fillColor: WidgetStateProperty.all(AppColors.mainColor),
);

TabBarTheme tabBarTheme = TabBarTheme(
    labelColor: AppColors.mainColor,
    indicatorSize: TabBarIndicatorSize.label,
    unselectedLabelColor: Colors.grey);

SystemUiOverlayStyle androidLightBarColor() {
  if (Platform.isAndroid) {
    return const SystemUiOverlayStyle(
      statusBarColor: Colors.white,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    );
  }
  return SystemUiOverlayStyle.light;
}

SystemUiOverlayStyle barColor() {
  if (Platform.isAndroid) {
    return const SystemUiOverlayStyle(
        statusBarBrightness: Brightness.dark,
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: Colors.transparent,
        systemNavigationBarColor: Colors.white);
  }
  return SystemUiOverlayStyle.dark;
}

SystemUiOverlayStyle lightBarColor() {
  if (Platform.isAndroid) {
    return const SystemUiOverlayStyle(
      systemNavigationBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    );
  }
  return SystemUiOverlayStyle.light;
}
