import 'package:flutter/material.dart';

class AppColors {
  static const Color mainColor = Color(0xffF59331);
  static const Color opcityOrangeColor = Color(0xffFFE6CF);
  static const Color opcityOrange = Color(0xffFFF3E7);
  static const Color textFieldBgColor = Color(0xffF6F6F6);
  static const Color lightGrey = Color(0xffF5F5F5);
  static const Color lightRed = Color(0xffFFE5E6);
  static LinearGradient gradient = LinearGradient(
    colors: [opcityOrangeColor, mainColor],
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    tileMode: TileMode.decal,
  );
}
