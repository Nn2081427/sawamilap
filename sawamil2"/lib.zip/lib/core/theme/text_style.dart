import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class TextStyleClass {
  static TextStyle bigStyle({Color? color, FontWeight? fontWeight}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 22.sp,
      height: 1.3,
      fontWeight: fontWeight ?? FontWeight.normal,
    );
  }

  static TextStyle semiBigStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 19.sp,
      height: 1.3,
      //fontWeight: FontWeight.bold,
    );
  }

  static TextStyle semiBigBoldStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 19.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle headBoldStyle({Color? color, double? fontSize}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: fontSize ?? 16.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle headStyle({Color? color, double? fontSize}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: fontSize ?? 16.sp,
      height: 1.3,
    );
  }

  static TextStyle semiHeadBoldStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 15.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle semiHeadStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 15.sp,
      height: 1.3,
    );
  }

  static TextStyle semiStyle({Color? color, double? height}) {
    return TextStyle(
        color: color ?? Colors.black,
        fontSize: 13.sp,
        fontWeight: FontWeight.w400,
        height: height ?? 1.3);
  }

  static TextStyle semiDecorationStyle({Color? color}) {
    return TextStyle(
        color: color ?? Colors.black,
        fontSize: 13.sp,
        height: 1.3,
        decoration: TextDecoration.underline,
        decorationColor: color ?? Colors.black);
  }

  static TextStyle semiBoldStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 13.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle normalStyle(
      {Color? color, double? fontSize, double? height}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: fontSize ?? 10.sp,
      height: height ?? 1.3,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle normalLineThroughStyle(
      {double? fontSize,
      Color? color,
      TextDecoration? decoration,
      Color? decorationColor}) {
    return TextStyle(
      color: color ?? Colors.black,
      decoration: decoration ?? TextDecoration.lineThrough,
      decorationColor: decorationColor ?? Colors.red,
      fontSize: fontSize ?? 10.sp,
      height: 1.3,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle normalBoldStyle({Color? color, double? fontSize}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: fontSize ?? 16.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle textButtonStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.white,
      fontSize: 14.sp,
      height: 1.3,
    );
  }

  static TextStyle smallTextButtonStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.white,
      fontSize: 9.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle smallStyle({double? fontSize, Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: fontSize ?? 9.sp,
      height: 1.3,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle smallBoldStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 12.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle tinyStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 7.5.sp,
      height: 1.3,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle tinyBoldStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 7.5.sp,
      height: 1.3,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle veryTinyStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 5.5.sp,
      height: 1.3,
      fontWeight: FontWeight.w400,
    );
  }

  static TextStyle smallDecorationStyle({Color? color}) {
    return TextStyle(
      color: color ?? Colors.black,
      fontSize: 9.sp,
      height: 1.3,
      fontWeight: FontWeight.w400,
      decoration: TextDecoration.underline,
      decorationColor: color ?? Colors.black,
    );
  }
}
