import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';

abstract class Fonts {
  static TextStyle textSplash25 = TextStyle(
    color: Colors.white,
    fontSize: 25,
    fontWeight: FontWeight.w700,
    fontFamily: "DINNextLTW23",
    height: 0,
  );
  static TextStyle textWhite18 = TextStyle(
    color: Colors.white,
    fontSize: 18,
    fontWeight: FontWeight.w500,
    fontFamily: "DINNextLTW23",
    height: 0,
  );
  static TextStyle textSplash32 = TextStyle(
    color: Colors.white,
    fontSize: 32,
    fontWeight: FontWeight.w700,
    fontFamily: "DINNextLTW23",
    height: 0,
  );

  static TextStyle textSplash24 = TextStyle(
    color: Colors.white,
    fontSize: 24,
    fontWeight: FontWeight.w500,
    fontFamily: "DINNextLTW23",
  );
  static TextStyle textSplash14 = TextStyle(
    color: Colors.white,
    fontSize: 14,
    fontWeight: FontWeight.w500,
    fontFamily: "DINNextLTW23",
  );
  static TextStyle text20Orange = TextStyle(
    color: AppColors.mainColor,
    fontSize: 20,
    fontWeight: FontWeight.w400,
    fontFamily: "DINNextLTW23",
  );
   static TextStyle text24Orange = TextStyle(
    color: AppColors.mainColor,
    fontSize: 24,
    fontWeight: FontWeight.w600,
    fontFamily: "DINNextLTW23",
  );
  static TextStyle text16Orange = TextStyle(
    color: AppColors.mainColor,
    fontSize: 16,
    fontWeight: FontWeight.w400,
    fontFamily: "DINNextLTW23",
  );
  static TextStyle textBlack18 = TextStyle(
    color: Colors.black,
    fontSize: 18,
    fontWeight: FontWeight.w500,
    fontFamily: "DINNextLTW23",
    height: 0,
  );
  static TextStyle headTitle20 = TextStyle(
    color: Colors.black,
    fontSize: 22,
    fontWeight: FontWeight.bold,
    fontFamily: "DINNextLTW23",
    height: 0,
  );
  static TextStyle text16Black = TextStyle(
    color: Colors.black,
    fontSize: 16,
    fontWeight: FontWeight.w500,
    fontFamily: "DINNextLTW23",
    height: 0,
  );
  static TextStyle text14Black = TextStyle(
    color: Colors.black,
    fontSize: 14,
    fontWeight: FontWeight.w600,
    fontFamily: "DINNextLTW23",
    height: 0,
  );
}
