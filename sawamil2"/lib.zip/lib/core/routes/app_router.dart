import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:swamiil/core/routes/routes.dart';
import 'package:swamiil/features/user_auth/presentation/screens/users_screen.dart';
import 'package:swamiil/features/splash/Presentation/screens/intro_screen.dart';
import 'package:swamiil/features/splash/Presentation/screens/splash_screen.dart';

class AppRouter {
  Route generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case Routes.splashScreen:
        return PageTransition(
          type: PageTransitionType.fade,
          child: SplashScreen(),
        );
       case Routes.introScreen:
        return PageTransition(
          type: PageTransitionType.fade,
          child: OnboardingScreen(),
        );
      case Routes.usersScreen:
        return PageTransition(
          type: PageTransitionType.fade,
          child: UsersScreen(),
        );

      default:
        throw Exception('Route not found: ${settings.name}');
    }
  }
}
