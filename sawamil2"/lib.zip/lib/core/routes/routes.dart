class Routes {
  static const String splashScreen = "/";
  static const String introScreen = "/intro_screen";
  static const String usersScreen = "/users_screen";
}
