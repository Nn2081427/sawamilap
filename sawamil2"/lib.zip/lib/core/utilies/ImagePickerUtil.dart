import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:swamiil/core/helper_function/image.dart';
import 'package:swamiil/core/helpers/image.dart';
import 'dart:io';

import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

class ImageResult {
  final String path;
  final File file;
  final XFile xFile;

  ImageResult({required this.path, required this.file, required this.xFile});
}

class ImagePickerUtil {
  /// Picks an image from the gallery with specified quality
  ///
  /// Returns ImageResult containing the path, File, and XFile of the picked image
  /// or null if no image was selected or if there was an error
  static Future<ImageResult?> pickImage({
    required BuildContext context,
    int imageQuality = 80,
    ImageSource source = ImageSource.gallery,
    void Function(String)? onLoading,
  }) async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: source,
        imageQuality: imageQuality,
      );

      if (image != null) {
        if (onLoading != null) {
          onLoading(image.path);
        }
        File file = File(image.path);
        return ImageResult(path: image.path, file: file, xFile: image);
      }
      return null;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to process image. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
      return null;
    }
  }

  static Future<List<XFile>?> pickMultiImage({
    required BuildContext context,
    int imageQuality = 80,
    void Function(String)? onLoading,
  }) async {
    try {
      final ImagePicker picker = ImagePicker();
      final List<XFile> images = await picker.pickMultiImage(
        imageQuality: imageQuality,
      );

      if (images.isEmpty) return [];

      final List<XFile> results = [];
      for (var image in images) {
        if (onLoading != null) {
          onLoading(image.path);
        }
        File file = File(image.path);
        results.add(image);
      }

      return results;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to process images. Please try again.'.tr()),
          backgroundColor: Colors.red,
        ),
      );
      return null;
    }
  }

  /// Shows options to choose between camera and gallery sources
  static Future<ImageResult?> showImageSourcePicker({
    required BuildContext context,
    int imageQuality = 80,
    void Function(String)? onLoading,
  }) async {
    ImageSource? source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading:
                      const Icon(Icons.camera_alt, color: AppColors.mainColor),
                  title: Text(
                    "Take a photo".tr(),
                    style: Fonts.text16Black,
                  ),
                  onTap: () => Navigator.pop(context, ImageSource.camera),
                ),
                ListTile(
                  leading: const Icon(Icons.photo_library,
                      color: AppColors.mainColor),
                  title: Text(
                    "Choose from gallery".tr(),
                    style: Fonts.text16Black,
                  ),
                  onTap: () => Navigator.pop(context, ImageSource.gallery),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (source == null) return null;

    return pickImage(
      context: context,
      source: source,
      imageQuality: imageQuality,
      onLoading: onLoading,
    );
  }

  static Future<List<XFile?>> showImageSourcePickerMulti({
    required BuildContext context,
    int imageQuality = 80,
    void Function(String)? onLoading,
  }) async {
    ImageSource? source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading:
                      const Icon(Icons.camera_alt, color: AppColors.mainColor),
                  title: Text(
                    "Take a photo".tr(),
                    style: Fonts.text16Black,
                  ),
                  onTap: () => Navigator.pop(context, ImageSource.camera),
                ),
                ListTile(
                  leading: const Icon(Icons.photo_library,
                      color: AppColors.mainColor),
                  title: Text(
                    "Choose from gallery".tr(),
                    style: Fonts.text16Black,
                  ),
                  onTap: () => Navigator.pop(context, ImageSource.gallery),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (source == ImageSource.camera) {
      // Camera typically allows picking only one image, so use pickImage
      final result = await pickMultiImageCamera(context, 2);
      return result ?? [];
    }
    final images = await pickMultiImage(
      context: context,
      imageQuality: imageQuality,
      onLoading: onLoading,
    );
    return images ?? [];
  }
}
