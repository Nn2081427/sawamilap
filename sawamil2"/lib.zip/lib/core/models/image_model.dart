class ImageClass{
  final int id;
  final String image;

  ImageClass({
    required this.id,
    required this.image,
  });

}