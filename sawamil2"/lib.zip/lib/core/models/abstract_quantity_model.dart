abstract class QuantityClass {
  void addQuantity();
  void reduceQuantity({required int i});
  late int quantity;
}
