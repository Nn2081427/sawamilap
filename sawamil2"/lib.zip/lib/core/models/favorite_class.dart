abstract class Favorite {
  late bool isFavorite;
  late int id;

  Favorite({required this.id, this.isFavorite = false});

  String type();
  int count();
}

class OrderFavorite extends Favorite {
  OrderFavorite({required super.id, super.isFavorite = false});
  @override
  String type() => 'order';
  @override
  int count() => 1;
}
