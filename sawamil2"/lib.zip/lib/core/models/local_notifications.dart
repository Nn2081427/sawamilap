// import 'dart:convert';
//
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:provider/provider.dart';
//
// import '../../main.dart';
// import '../constants/constants.dart';
// import '../helper_function/convert.dart';
// import '../helper_function/helper_function.dart';
//
// class NotificationLocalClass {
//   static final FlutterLocalNotificationsPlugin notificationsPlugin =
//   FlutterLocalNotificationsPlugin();
//   static Future notificationDet()async{
//     return const NotificationDetails(
//       android: AndroidNotificationDetails(
//           'test','c_name',importance: Importance.max,priority: Priority.high,
//           showWhen: false,playSound: true,channelShowBadge: true,channelDescription: 'c_des',
//         icon: '@mipmap/ic_launcher',
//       ),
//       iOS: DarwinNotificationDetails(
//
//       ),
//     );
//   }
//   static Future showNoti({int? id,required String title,required String body,required String payload})async{
//     try{
//       notificationsPlugin.show(id??DateTime.now().millisecond, title, body,await notificationDet(),payload: payload);
//       delay(2500).then((value) => notificationsPlugin.cancelAll());
//     }catch(e){
//       print(e);
//     }
//   }
//   static Future init({bool initScheduled = false})async{
//     final settings = InitializationSettings(
//       android: const AndroidInitializationSettings('logo'),
//       iOS: DarwinInitializationSettings(
//           requestSoundPermission: true,
//           requestBadgePermission: true,
//           requestAlertPermission: true,
//           defaultPresentBadge: true,
//           onDidReceiveLocalNotification: (id,title,body,pay)async{
//
//             clickNoti(pay!);
//
//           }
//       ),
//     );
//     await notificationsPlugin.initialize(
//       settings,
//       onDidReceiveNotificationResponse: (pay)async{
//
//         clickNoti(pay.payload!);
//       },
//       onDidReceiveBackgroundNotificationResponse: localMessagingBackgroundHandler,
//     );
//   }
// }
//
// void clickNoti(String pay)async{
//   Map payload = jsonDecode(pay);
//   if(AuthProvider.isLogin()){
//     if (payload.containsKey('message_type_')) {
//       if (payload['message_type_'] == "chat") {
//         Map message = jsonDecode(payload['data_']);
//         Map chat = message['chat'];
//         MessageProvider messageProvider = Provider.of(Constants.globalContext(), listen: false);
//         bool check = messageProvider.checkMessageOfThisChat(convertStringToInt(chat['id']));
//         if (!check) {
//           int orderId = convertStringToInt(chat['order_id']);
//           if (messageProvider.chatEntity == null) {
//             messageProvider.goToMessagePage(id: orderId);
//           } else {
//             messageProvider.getMessages(isSupport: false,orderId: orderId);
//           }
//         }
//       } else if (payload['message_type_'] == "order") {
//         int orderId = convertStringToInt(jsonDecode(payload['data_']));
//         OrderDetailsProvider orderDetailsProvider = Provider.of(Constants.globalContext(), listen: false);
//         if (orderDetailsProvider.ordersDetails != null && orderDetailsProvider.ordersDetails!.id != orderId) {
//           orderDetailsProvider.getOrderDetailsData(id: orderId);
//         }
//         if (orderDetailsProvider.ordersDetails == null) {
//           orderDetailsProvider.goToOrderDetailsHome(orderId);
//         }
//       }else if (payload['message_type_'] == "support_chat") {
//         Map message = jsonDecode(payload['data_']);
//         MessageProvider messageProvider = Provider.of(Constants.globalContext(), listen: false);
//         bool check = messageProvider.checkMessageOfThisChat(convertStringToInt(message['chat']['id']));
//         if (!check) {
//           if (messageProvider.chatEntity == null) {
//             messageProvider.goToMessagePage(isSupport: true);
//           } else {
//             messageProvider.getMessages(isSupport: true);
//           }
//         }
//       }else if(payload['message_type_'] == "new_offer"){
//         // data
//         // cubit
//         // check are i am in page
//         // false navP
//       }
//     }
//   }
// }