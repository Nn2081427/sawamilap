abstract class AbstractClass{
  late String name;
  late String price;
  late String  description;
  late String   image;
}

abstract class SuperAbstract{
  List<AbstractClass> ? superList();
}