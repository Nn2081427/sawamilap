

class BottomModel{
  String svg;
  String label;

  BottomModel({required this.svg,required this.label});
}