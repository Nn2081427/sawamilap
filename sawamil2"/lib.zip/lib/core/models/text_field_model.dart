import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TextFieldModel {
  String? image;
  String? key;
  String? label;
  String? hint;
  String? titleText;
  TextInputType? textInputType;
  TextEditingController controller;
  bool next;
  bool obscureText;
  bool readOnly;
  bool? isLabel;
  double? height;
  final List<TextInputFormatter>? inputFormatter;
  String? Function(String?)? validator;
  Widget? suffix;
  Widget? prefix;
  Widget? title;
  void Function()? onTap;
  double? width;
  int? min;
  int? max;
  EdgeInsets? contentPadding;
  bool? expands;
  int? maxLength;
  TextStyle? labelStyle;

  TextFieldModel({
    this.image,
    this.key,
    this.label,
    this.hint,
    this.titleText,
    this.textInputType,
    required this.controller,
    this.next = true,
    this.obscureText = false,
    this.readOnly = false,
    this.isLabel,
    this.height,
    this.inputFormatter,
    this.validator,
    this.suffix,
    this.prefix,
    this.title,
    this.onTap,
    this.width,
    this.min,
    this.max,
    this.contentPadding,
    this.expands,
    this.maxLength,
    this.labelStyle,
  });

  TextFieldModel copyWith({
    String? image,
    String? key,
    String? label,
    String? hint,
    String? titleText,
    TextInputType? textInputType,
    TextEditingController? controller,
    bool? next,
    bool? obscureText,
    bool? readOnly,
    bool? isLabel,
    double? height,
    List<TextInputFormatter>? inputFormatter,
    String? Function(String?)? validator,
    Widget? suffix,
    Widget? prefix,
    Widget? title,
    void Function()? onTap,
    double? width,
    int? min,
    int? max,
    EdgeInsets? contentPadding,
    bool? expands,
    int? maxLength,
    TextStyle? labelStyle,
  }) {
    return TextFieldModel(
      image: image ?? this.image,
      key: key ?? this.key,
      label: label ?? this.label,
      hint: hint ?? this.hint,
      titleText: titleText ?? this.titleText,
      textInputType: textInputType ?? this.textInputType,
      controller: controller ?? this.controller,
      next: next ?? this.next,
      obscureText: obscureText ?? this.obscureText,
      readOnly: readOnly ?? this.readOnly,
      isLabel: isLabel ?? this.isLabel,
      height: height ?? this.height,
      inputFormatter: inputFormatter ?? this.inputFormatter,
      validator: validator ?? this.validator,
      suffix: suffix ?? this.suffix,
      prefix: prefix ?? this.prefix,
      title: title ?? this.title,
      onTap: onTap ?? this.onTap,
      width: width ?? this.width,
      min: min ?? this.min,
      max: max ?? this.max,
      contentPadding: contentPadding ?? this.contentPadding,
      expands: expands ?? this.expands,
      maxLength: maxLength ?? this.maxLength,
      labelStyle: labelStyle ?? this.labelStyle,
    );
  }
}
