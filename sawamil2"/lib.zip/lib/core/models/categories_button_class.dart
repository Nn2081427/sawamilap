abstract class CategoriesButton {
  void onTap(int index);
  List<String>? categories();
  int currentIndex();
}
