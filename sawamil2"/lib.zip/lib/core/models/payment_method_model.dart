class PaymentMethodModel {
  String title;
  String image;
  PaymentMethodModel({required this.title, required this.image});
}
