// import 'dart:io';
//
// import 'package:camera/camera.dart';
// import 'package:flutter/material.dart';
//
// import 'package:sarfha/core/helper_function/navigation.dart';
// import 'package:sarfha/core/widget/svg_widget.dart';
// import 'package:sarfha/core/widget/video_view_page.dart';
// import 'package:sarfha/features/language/presentation/provider/language_provider.dart';
// import 'package:sizer/sizer.dart';
//
// import '../../config/app_color.dart';
// import '../../config/text_style.dart';
// import '../constants/images.dart';
// import '../helper_function/image.dart';
//
//
// class UploadVideoWidget extends StatelessWidget {
//   const UploadVideoWidget({super.key,required this.image, required this.selectImage, this.video});
//   final XFile? video;
//   final String? image;
//   final void Function(XFile? image) selectImage;
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       elevation: 8,
//       child: InkWell(
//         onTap: ()async{
//           if(video==null){
//             FocusScope.of(context).unfocus();
//             XFile? image = await chooseImage(video: true);
//             selectImage(image);
//           }else{
//             navP(VideoViewPage(video: File(video!.path)));
//           }
//         },
//         child: Container(
//           width: 94.w,
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(12),
//             color: const Color(0xffFBF8F8),
//           ),
//           padding: EdgeInsets.all(3.w),
//           child: Column(
//             children: [
//               Row(
//                 children: [
//                   Text(LanguageProvider.translate('global', 'add_video'),
//                     style: TextStyleClass.semiStyle(color: AppColor.defaultColor),)
//                 ],
//               ),
//               SizedBox(height: 3.h,),
//               Stack(
//                 clipBehavior: Clip.none,
//                 children: [
//                   Container(
//                     width: 35.w,
//                     height: 45.w,
//                     decoration: BoxDecoration(
//                       border: Border.all(color: Colors.grey),
//                       borderRadius: BorderRadius.circular(8),
//                       image: image==null?null:DecorationImage(
//                         image: FileImage(File(image!),),
//                         fit: BoxFit.cover,
//                       ),
//                     ),
//                     child: image==null?Center(
//                       child: SvgWidget(svg: Images.uploadPhotoIcon,width: 13.w,color: AppColor.defaultColor,),
//                     ):const SizedBox(),
//                   ),
//                   if(image!=null)Positioned(
//                     top: -3.w,
//                     left: -3.w,
//                     child: InkWell(onTap: (){
//                       selectImage(null);
//                     },child: Icon(Icons.delete,color: Colors.red,size: 8.w,)),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
