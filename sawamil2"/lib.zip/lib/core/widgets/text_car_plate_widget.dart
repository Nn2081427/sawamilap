import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/text_style.dart';

class TextCarPlateWidget extends StatelessWidget {
  const TextCarPlateWidget({super.key, required this.text,
    required this.changeIndex, required this.addIndex,});
  final String text;
  final int changeIndex;
  final int addIndex;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Container(
          padding: EdgeInsets.only(top: 1.5.h),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(text.length-changeIndex, (i) {
              int index = i;
              index += addIndex;
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 0.5.w),
                child: Text(text[index],style: TextStyleClass.semiBoldStyle(),),
              );
            }),
          ),
        ),
      ),
    );
  }
}
