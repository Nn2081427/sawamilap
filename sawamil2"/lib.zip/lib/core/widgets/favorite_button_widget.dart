import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/constants.dart';

class FavoriteButtonWidget extends StatefulWidget {
  final int id;
  final bool initialIsFavorite;
  final Color? color;
  final double? padding, size, margin;

  /// Should return the updated status (true = favorite, false = not)
  final Future<bool> Function()? onToggleFavorite;

  const FavoriteButtonWidget({
    required this.id,
    required this.initialIsFavorite,
    super.key,
    this.color,
    this.padding,
    this.size,
    this.margin,
    this.onToggleFavorite,
  });

  @override
  State<FavoriteButtonWidget> createState() => _FavoriteButtonWidgetState();
}

class _FavoriteButtonWidgetState extends State<FavoriteButtonWidget> {
  late bool isFavorite;

  @override
  void initState() {
    super.initState();
    isFavorite = widget.initialIsFavorite;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        if (widget.onToggleFavorite != null) {
          final result = await widget.onToggleFavorite!();
          setState(() {
            isFavorite = result;
          });
        } else {
          setState(() {
            isFavorite = !isFavorite;
          });
        }
      },
      child: Container(
        height: 12.w,
        width: 12.w,
        margin: EdgeInsets.only(bottom: widget.margin ?? 2.h),
        child: Icon(
          isFavorite ? Icons.favorite : Icons.favorite_border,
          color: isFavorite ? Colors.red : Colors.grey,
          size: widget.size ?? (Constants.isTablet ? 24 : 19),
        ),
      ),
    );
  }
}
