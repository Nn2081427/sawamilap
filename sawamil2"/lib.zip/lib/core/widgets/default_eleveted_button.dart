import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

class DefaultElevetedButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String label;
  final Color? labelColor;
  final Color? color;
  final double? width;
  final double? height;
  final double? fontSize;
  final FontWeight? fontWeghit;
  final double? borderRadius;

  const DefaultElevetedButton(
      {super.key,
      required this.onPressed,
      required this.label,
      this.color,
      this.labelColor,
      this.height,
      this.width,
      this.fontSize,
      this.fontWeghit,
      this.borderRadius});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
          backgroundColor: color ?? AppColors.mainColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(borderRadius ?? 15)),
          )),
      child: SizedBox(
        height: height ?? 54,
        width: width ?? double.infinity,
        child: Center(
          child: Text(label,
              style: Fonts.textSplash14.copyWith(
                color: labelColor ?? Colors.white,
                fontSize: fontSize ?? 17.sp,
                fontWeight: fontWeghit ?? FontWeight.w600,
              )),
        ),
      ),
    );
  }
}
