import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helpers/image.dart';
import 'package:swamiil/core/theme/text_style.dart';

class UploadImageCustomWidget extends StatelessWidget {
  const UploadImageCustomWidget({super.key, required this.image, required this.imageItem, required this.deleteImage});
  final dynamic image;
  final void Function(XFile images) imageItem;
  final VoidCallback deleteImage;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(3.w),
          color: const Color(0xffFBF8F8),
          boxShadow: [ BoxShadow(
            color: Colors.black.withOpacity(0.05),
            spreadRadius: 5,
            blurRadius: 7,
            offset: const Offset(1, 3), // changes position of shadow
          )]

      ),
      margin: EdgeInsets.symmetric(horizontal: 2.w),
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.h),
      child: InkWell(
        onTap: ()async{
          XFile? pickedImage = await chooseImage();
          if(pickedImage!=null){
            imageItem(pickedImage);
          }
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if(image == null)

              Text("add_event_image",style: TextStyleClass.normalStyle(color: Colors.grey),),

            SizedBox(height: 1.h,),
            if(image !=null)
              InkWell(
                onTap: (){
                  deleteImage();
                },
                child: Container(
                  width: 100.w,
                  height: 30.h,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    image: (image is XFile)?DecorationImage(
                      image: FileImage(File(image!.path)),
                      fit: BoxFit.contain,
                    ):DecorationImage(
                      image: CachedNetworkImageProvider(image),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            if(image == null)
              Container(
                margin: EdgeInsets.symmetric(vertical: 1.h),
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Colors.grey.withOpacity(0.1),
                ),
                // child: SvgWidget(
                //   svg: Images.completeDataImage,width: 10.w,
                // ),
                // child: Text(LanguageProvider.translate("buttons", "add_image"),style: TextStyleClass.normalStyle(color: Colors.white),),
              ),
            Row(
              children: [
                if(image != null)
                  Text('delete_image',style: TextStyleClass.smallStyle(
                  color: Colors.black,
                ),),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
