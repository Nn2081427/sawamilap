import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';


class CustomTrianglePainter extends CustomPainter {
  final double? extraWidth;
  final Color? color;
  final double borderRadius;

  CustomTrianglePainter({
    this.color,
    this.extraWidth,
    this.borderRadius = 10.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color ?? Colors.white;
    final path = Path();

    final double tipX = size.width + (extraWidth ?? 0);
    final double tipY = size.height / 2;

    path.moveTo(tipX, tipY);
    path.lineTo(borderRadius, 0); // Top edge
    path.quadraticBezierTo(0, 0, 0, borderRadius); // Top-left rounded corner
    path.lineTo(0, size.height - borderRadius); // Left edge
    path.quadraticBezierTo(0, size.height, borderRadius, size.height); // Bottom-left rounded corner
    path.lineTo(tipX, tipY); // Back to tip
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// Usage example:
class TriangleWidget extends StatelessWidget {
  const TriangleWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadiusDirectional.horizontal(
        end: Radius.circular(12), // Match the painter's borderRadius
      ),
      child: CustomPaint(
        size: Size(100, 60), // Adjust size as needed
        painter: CustomTrianglePainter(
          color: AppColors.mainColor,
          extraWidth: 20,
          borderRadius: 12,
        ),
      ),
    );
  }
}
// class CustomTrianglePainter extends CustomPainter {
//   final double extraWidth;
//   final Color color;
//   final double cornerRadius;

//   CustomTrianglePainter({
//     this.extraWidth = 20,
//     this.color = Colors.white,
//     this.cornerRadius = 8,
//   });

//   // Helper to normalize an Offset vector.
//   Offset _normalize(Offset vector) {
//     final len = vector.distance;
//     return len == 0 ? vector : vector / len;
//   }

//   @override
//   void paint(Canvas canvas, Size size) {
//     // Define the triangle's vertices:
//     // A: The tip on the right (extended by extraWidth).
//     // B: The top-left corner.
//     // C: The bottom-left corner.
//     final Offset A = Offset(size.width + extraWidth, size.height / 2);
//     final Offset B = Offset(0, 0);
//     final Offset C = Offset(0, size.height);

//     // --- Compute rounding for corner at B ---
//     // For the edge A -> B, get the unit vector from B toward A.
//     final Offset vBA = _normalize(A - B);
//     // Move from B toward A by cornerRadius.
//     final Offset B1 = B + vBA * cornerRadius;

//     // For the edge B -> C, get the unit vector from B toward C.
//     final Offset vBC = _normalize(C - B);
//     // Move from B toward C by cornerRadius.
//     final Offset B2 = B + vBC * cornerRadius;

//     // --- Compute rounding for corner at C ---
//     // For the edge C -> B, get the unit vector from C toward B.
//     final Offset vCB = _normalize(B - C);
//     final Offset C1 = C + vCB * cornerRadius;

//     // For the edge C -> A, get the unit vector from C toward A.
//     final Offset vCA = _normalize(A - C);
//     final Offset C2 = C + vCA * cornerRadius;

//     // Build the path:
//     final Path path = Path()
//       // Start at the tip (A)
//       ..moveTo(A.dx, A.dy)
//       // Draw a line toward B, stopping at B1 (so we can round the corner)
//       ..lineTo(B1.dx, B1.dy)
//       // Round the corner at B from B1 to B2.
//       ..arcToPoint(
//         B2,
//         radius: Radius.circular(cornerRadius),
//         clockwise: true,
//       )
//       // Draw line along the left edge toward C,
//       // stopping short of C at C1 for the rounding.
//       ..lineTo(C1.dx, C1.dy)
//       // Round the corner at C from C1 to C2.
//       ..arcToPoint(
//         C2,
//         radius: Radius.circular(cornerRadius),
//         clockwise: true,
//       )
//       // Close the triangle by drawing back to the tip A.
//       ..lineTo(A.dx, A.dy)
//       ..close();

//     // Draw the path.
//     final Paint paint = Paint()..color = color;
//     canvas.drawPath(path, paint);
//   }

//   @override
//   bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
// }

class TrianglePainter extends CustomPainter {
  final double? extraWidth;
  final Color? color;

  TrianglePainter({this.color, this.extraWidth}); // Increase extraWidth to make the triangle bigger

  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()..color = color ?? Colors.white;

    Path path = Path()
      // Move the triangle tip further right by extraWidth
      ..moveTo(size.width + (extraWidth ?? 0), size.height / 2)
      ..lineTo(0, 0)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class RightHeadTrianglePainter extends CustomPainter {
  final double? extraWidth;
  final Color? color;

  RightHeadTrianglePainter({this.color, this.extraWidth});
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()..color = color ?? Colors.white;

    Path path = Path()
      ..moveTo(size.width + (extraWidth ?? 0), size.height / 2)
      ..lineTo(0, 5)
      ..arcToPoint(
        Offset(0, size.height - 5),
        radius: const Radius.circular(2),
        clockwise: false,
      )
      ..lineTo(0, size.height - 5)
      ..arcToPoint(
        Offset(0, 5),
        radius: const Radius.circular(2),
        clockwise: false,
      )
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
