import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import 'triangle_widget.dart';

class ButtonWithArrowWidget extends StatelessWidget {
  final VoidCallback onTap;
  final String text;
  final String ?textWithReplace;
  final String ?textReplace;
  final double?height,width;
  const ButtonWithArrowWidget({
    super.key,
    this.height,
    this.width,
    this.textWithReplace,
    this.textReplace,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        onTap();
      },
      child: Container(
        width:width?? 100.w,
        height: height??5.5.h,
        padding: EdgeInsets.symmetric(horizontal: 0.w,vertical: 0.5.h),
        decoration: BoxDecoration(
          // gradient: AppColor.gradient,
           borderRadius: BorderRadiusDirectional.horizontal(start:Radius.circular(5),end: Radius.circular(5))
      ,
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            
            // Text(
            //     textWithReplace ==null ? LanguageProvider.translate("buttons", text ):
            //   LanguageProvider.translate("buttons", textWithReplace ==null? text : textWithReplace! ).replaceAll("*inputs*", textReplace??''),
            //   style: TextStyleClass.semiBoldStyle(color: Colors.white),
            // ),
            Positioned(left: 0,top: 0,bottom: 0,
              child: SizedBox(
                height: 6.h,width: 4.w,
                child: CustomPaint(
                  painter: TrianglePainter(),
                ),
              ),
            ),
          ],
        )
      ),
    );
  }
}
