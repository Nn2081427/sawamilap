// import 'package:flutter/material.dart';
// import 'package:pinch_zoom/pinch_zoom.dart';
// import 'package:sarfha/config/theme.dart';
// import 'package:sarfha/core/widget/smooth_video_progress_widget.dart';
// import 'package:sarfha/features/language/presentation/provider/language_provider.dart';
// import 'package:sizer/sizer.dart';
// import 'package:video_player/video_player.dart';
//
// import '../../../../core/helper_function/navigation.dart';
// import '../../config/app_color.dart';
// import '../constants/constants.dart';
//
// class VideoViewPage extends StatefulWidget {
//   final dynamic video;
//   const VideoViewPage({required this.video,super.key});
//   @override
//   State<VideoViewPage> createState() => _VideoViewPageState();
// }
//
// class _VideoViewPageState extends State<VideoViewPage> {
//   late VideoPlayerController _controller;
//   late Future<void> _initializeVideoPlayerFuture;
//
//   @override
//   void initState() {
//     super.initState();
//
//     if(widget.video is String){
//       _controller = VideoPlayerController.networkUrl(
//         Uri.parse(widget.video),
//       );
//     }else{
//       _controller = VideoPlayerController.file(
//         widget.video,
//       );
//     }
//
//     _initializeVideoPlayerFuture = _controller.initialize();
//     _initializeVideoPlayerFuture.then((val){
//       if(mounted){
//         setState(() {});
//         _controller.play();
//       }
//     });
//     _controller.setLooping(false);
//   }
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
//   @override
//   Widget build(BuildContext context) {
//     return PopScope(
//       canPop: true,
//       onPopInvoked: (val){
//         if (_controller.value.isPlaying) {
//           _controller.pause();
//         }
//       },
//       child: AnnotatedRegion(
//         value: lightBarColor(),
//         child: Scaffold(
//           backgroundColor: Colors.black,
//           body: SizedBox(
//             width: 100.w,
//             height: 100.h,
//             child: Stack(
//               children: [
//                 Center(
//                   child: FutureBuilder(
//                     future: _initializeVideoPlayerFuture,
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.done) {
//                         return PinchZoom(
//                           maxScale: 3,
//                           child: RotatedBox(
//                             quarterTurns: 0+(_controller.value.size.width < _controller.value.size.height ? 0 : 1),
//                             child: AspectRatio(
//                               aspectRatio: _controller.value.aspectRatio,
//                               child: VideoPlayer(_controller),
//                             ),
//                           ),
//                         );
//                       } else {
//                         return const Center(
//                           child: CircularProgressIndicator(),
//                         );
//                       }
//                     },
//                   ),
//                 ),
//                 PositionedDirectional(
//                   top: 8.h,
//                   start: 3.w,
//                   child: Container(
//                     margin: EdgeInsets.all(1.5.w),
//                     decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withOpacity(0.3)),
//                     child: Transform.scale(
//                       scale: Constants.isTablet?2:1,
//                       child: BackButton(
//                         color: Colors.white,
//                         onPressed: () {
//                           _controller.dispose();
//                           navPop();
//                         },
//                       ),
//                     ),
//                   ),
//                 ),
//                 Positioned(
//                   bottom: 3.h,
//                   left: 0,
//                   right: 0,
//                   child: SmoothVideoProgressWidget(videoPlayerController: _controller),
//                 ),
//               ],
//             ),
//           ),
//           floatingActionButton: Padding(
//             padding: EdgeInsets.only(bottom: 2.h),
//             child: FloatingActionButton(
//               backgroundColor: AppColor.defaultColor,
//               onPressed: () {
//                 setState(() {
//                   if (_controller.value.isPlaying) {
//                     _controller.pause();
//                   } else {
//                     _controller.play();
//                   }
//                 });
//               },
//               child: Icon(
//                 _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
//                 size: 20,
//                 color: Colors.white,
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
