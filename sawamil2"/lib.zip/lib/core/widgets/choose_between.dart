import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';


class ChooseBetween extends StatelessWidget {
  final bool isSelected;
  final String text;
  final double? width, height;
  final VoidCallback onTap;

  const ChooseBetween({
    super.key,
    required this.isSelected,
    required this.onTap,
    required this.text,
    this.width,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 2.w),
        alignment: Alignment.center,
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: isSelected ? AppColors.mainColor : const Color(0xffEAEAEA),
        ),
        padding: EdgeInsets.all(3.w),
        child: Text(
          text,
        ),
      ),
    );
  }
}
