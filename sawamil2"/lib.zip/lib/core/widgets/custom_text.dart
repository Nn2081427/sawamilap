import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';


class CustomText extends StatelessWidget {
  final String text;
  final String? fontFamily;
  final Color? color;
  final Color? decorationColor;
  final double fontSize;
  final FontWeight? fontWeight;
  final int? maxLines;
  final double? height;
  final TextAlign? textAlign;
  final TextDecoration? decoration;
  const CustomText({
    super.key,
    required this.text,
    this.color = AppColors.mainColor,
    this.fontWeight = FontWeight.normal,
    required this.fontSize,
    this.fontFamily,
    this.decorationColor,
    this.textAlign,
    this.height,
    this.decoration,
    this.maxLines = 2,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: textAlign,
      overflow: TextOverflow.ellipsis,
      style: GoogleFonts.poppins(
        height: height ?? 1.4,
        fontSize: fontSize.sp,
        // fontFamily: fontFamily ?? AppFonts.regular,
        color: color,
        decoration: decoration ?? TextDecoration.none,
        decorationColor: decorationColor ?? Colors.red,
        decorationStyle: TextDecorationStyle.solid,
        fontWeight: fontWeight ?? FontWeight.normal,
      ),
      maxLines: maxLines,
    );
  }
}
