import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

import '../constants/constants.dart';
import '../dialog/drop_down_dialog.dart';
import '../models/drop_down_class.dart';

class DropDownWidget extends StatefulWidget {
  final DropDownClass dropDownClass;
  final double? width, borderRadius;
  final Color? borderColor, color;
  final double? padding;
  final void Function()? onTap, onChanged, clear;
  final TextEditingController? controller;
  final String? hintText;

  const DropDownWidget({
    required this.dropDownClass,
    this.width,
    super.key,
    this.onTap,
    this.controller,
    this.borderRadius,
    this.borderColor,
    this.padding,
    this.color,
    this.onChanged,
    this.clear,
    this.hintText,
  });

  @override
  State<DropDownWidget> createState() => DropDownWidgetState(dropDownClass);
}

class DropDownWidgetState extends State<DropDownWidget> {
  DropDownClass dropDownClass;
  DropDownWidgetState(this.dropDownClass);

  @override
  Widget build(BuildContext context) {
    // Cache the displayed widget and name to avoid rebuilds
    final displayedWidget = dropDownClass.displayedWidget();
    final displayedName = dropDownClass.displayedName();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.hintText != null)
          Padding(
            padding: EdgeInsets.only(bottom: 0.5.h),
            child: Text(
              widget.hintText!,
              style: Fonts.textBlack18,
            ),
          ),
        GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            if (widget.onTap == null) {
              if (widget.clear != null) {
                widget.clear!();
              }
              showDropDownDialog(
                dropDownClass,
                controller: widget.controller,
                onChanged: () {
                  setState(() {});
                  if (widget.onChanged != null) {
                    widget.onChanged!();
                  }
                },
              );
            } else {
              widget.onTap!();
            }
          },
          child: Container(
            width: widget.width ?? 100.w,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(widget.borderRadius ?? 10),
              color: widget.color ?? Colors.white,
              border: Border.all(color: widget.borderColor?.withOpacity(0.5) ?? Colors.grey),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: 10,
                vertical: widget.padding ?? 0.7.h,
              ),
              child: Row(
                children: [
                  if (displayedWidget != null) ...[
                    displayedWidget,
                    SizedBox(width: 3.w),
                  ],
                  Expanded(
                    child: Text(
                      displayedName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Fonts.text16Black.copyWith(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.keyboard_arrow_down_sharp,
                    color: Colors.grey,
                    size: Constants.isTablet ? 60 : 30,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
