import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/font_style.dart';

class CustomButton extends StatelessWidget {
  final Widget? child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double? width;
  final double? height;
  final Color? backgroundColor;
  final BorderRadiusGeometry? borderRadius;
  final BoxBorder? border;
  final List<BoxShadow>? boxShadow;
  final GestureTapCallback? onTap;
  final String? buttonText;
  final TextStyle? textStyle;

  const CustomButton({
    super.key,
    this.child,
    this.padding,
    this.margin,
    this.width,
    this.height,
    this.backgroundColor,
    this.borderRadius,
    this.border,
    this.boxShadow,
    this.onTap,
    this.buttonText,
    this.textStyle,
  });

  @override
  Widget build(BuildContext   context) {
    final container = Container(
      padding: padding,
      margin: margin,
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: backgroundColor ?? Colors.white,
        borderRadius: borderRadius ?? BorderRadius.circular(12),
        border: border,
        boxShadow: boxShadow,
      ),
      child: Center(
        child: child ??
            Text(
              buttonText!,
              style: textStyle ?? Fonts.textWhite18,
            ),
      ),
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: container);
    } else {
      return container;
    }
  }
}
