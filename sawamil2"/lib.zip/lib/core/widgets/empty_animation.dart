import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/core/theme/text_style.dart';

class EmptyAnimation extends StatelessWidget {
  const EmptyAnimation(
      {super.key,
      this.width,
      this.height,
      required this.title,
      required this.gif,
      this.aboveText});
  final double? width;
  final double? height;
  final String title;
  final String gif;
  final bool? aboveText;
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (aboveText != null && aboveText!)
          Text(
            title,
            style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
          ),
        SizedBox(
          height: 1.h,
        ),
        SizedBox(
            width: double.infinity,
            height: 40.h,
            child: Lottie.asset(gif,
                fit: BoxFit.cover, width: width, height: height)),
        SizedBox(
          height: 2.h,
        ),
        if (aboveText == null)
          Text(
            title.tr(),
            style: Fonts.textBlack18.copyWith(fontWeight: FontWeight.w500),
          ),
      ],
    );
  }
}
