// import 'package:flutter/material.dart';
// import 'package:sizer/sizer.dart';
// import 'package:swamiil/core/theme/text_style.dart';

// import '../constants/constants.dart';

// class SeeAllWidget extends StatelessWidget {
//   const SeeAllWidget({super.key, required this.title, required this.onTap});
//   final String title;
//   final VoidCallback onTap;
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(title,style: TextStyleClass.semiStyle().copyWith(height: 1),),
//           InkWell(
//             onTap: (){
//               onTap();
//             },
//             child: Container(
//               padding: EdgeInsets.symmetric(horizontal: 6.w,vertical: 0.8.h),
//               decoration: BoxDecoration(
//                 color: Colors.white,
//                 borderRadius: BorderRadius.circular(1.5.w),
//                 boxShadow: [],
//               ),
//               child:ShaderMask(
//                   shaderCallback: (bounds) => AppColor.gradient.createShader(bounds),
//                   blendMode: BlendMode.srcIn,
//                   child: Text("see_all",style: TextStyleClass.normalStyle().copyWith(height: 1),)),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
