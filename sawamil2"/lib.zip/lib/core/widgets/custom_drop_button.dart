import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/font_style.dart';

class CustomDropDownButton extends StatefulWidget {
  final String? hint;
  final List<String> items;
  final String? selectedValue;
  final ValueChanged<String?>? onChanged;
  final double? width;
  final TextStyle? textStyle;
  final Color? dropdownColor;

  const CustomDropDownButton({
    super.key,
    this.hint,
    required this.items,
    this.selectedValue,
    this.onChanged,
    this.width,
    this.textStyle,
    this.dropdownColor,
  });

  @override
  _CustomDropDownButtonState createState() => _CustomDropDownButtonState();
}

class _CustomDropDownButtonState extends State<CustomDropDownButton> {
  String? _selectedValue;
  Color? borderColor;

  @override
  void initState() {
    super.initState();
    _selectedValue = widget.selectedValue;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12),
      width: widget.width ?? double.infinity,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Colors.white,
          border: Border.all(
            color: borderColor ?? Colors.grey,
            width: 0.7,
          )),
      child: DropdownButton<String>(
        iconDisabledColor: Colors.black,
        iconEnabledColor: Colors.black,
        isExpanded: true,
        value: _selectedValue,
        hint: Text(
          widget.hint ?? 'Select an option',
          style:
              widget.textStyle ?? TextStyle(color: Colors.grey, fontSize: 16),
        ),
        icon: Icon(Icons.arrow_drop_down),
        iconSize: 24,
        elevation: 16,
        style: Fonts.textBlack18.copyWith(
          color: Colors.grey,
          fontSize: 14,
        ),
        dropdownColor: widget.dropdownColor ?? Colors.white,
        underline: SizedBox(), // Hide the underline
        onChanged: (String? newValue) {
          setState(() {
            _selectedValue = newValue;
          });
          if (widget.onChanged != null) {
            widget.onChanged!(newValue);
          }
        },
        items: widget.items
            .map<DropdownMenuItem<String>>(
              (String value) => DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              ),
            )
            .toList(),
      ),
    );
  }
}
