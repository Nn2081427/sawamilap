import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/helpers/image.dart';
import 'package:swamiil/core/theme/text_style.dart';

class UploadMultiImageWidget extends StatelessWidget {
  const UploadMultiImageWidget(
      {super.key,
      required this.images,
      required this.count,
      required this.deleteImage,
      required this.imagesList});
  final List images;
  final int count;
  final void Function(int i) deleteImage;
  final void Function(List<XFile> images) imagesList;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade300),
      ),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      child: InkWell(
        onTap: () async {
          List<XFile>? pickedImages = await chooseImageMulti(context);
          if (pickedImages != null) {
            imagesList(pickedImages);
          }
        },
        child: Column(
          children: [
            SizedBox(
              height: 1.h,
            ),
            if (images.isNotEmpty)
              SizedBox(
                width: 94.w,
                height: 10.h,
                child: Row(
                  children: [
                    Container(
                      width: 18.w,
                      height: 18.w,
                      padding: EdgeInsets.symmetric(horizontal: 2.w),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: Colors.black,
                          border: Border.all(color: Colors.red, width: 2)),
                      child: Icon(
                        Icons.add,
                        size: 8.w,
                        color: Colors.white,
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: images.length,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (ctx, i) {
                          return InkWell(
                            onTap: () {
                              deleteImage(i);
                            },
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 2.w),
                              child: Container(
                                width: 18.w,
                                height: 18.w,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  image: (images[i] is XFile)
                                      ? DecorationImage(
                                          image:
                                              FileImage(File(images[i].path)),
                                          fit: BoxFit.cover,
                                        )
                                      : DecorationImage(
                                          image: CachedNetworkImageProvider(
                                              images[i].image),
                                          fit: BoxFit.cover,
                                        ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            if (images.isEmpty)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Container(
                  //   width: 12.w,
                  //   height: 12.w,
                  //   decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.circular(15),
                  //     image: const DecorationImage(image: AssetImage(Images.addImageTwo),fit: BoxFit.cover),
                  //   ),
                  // ),
                  // SizedBox(width: 1.w,),
                  // Container(
                  //   width: 14.w,
                  //   height: 14.w,
                  //
                  //   decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.circular(15),
                  //     image: const DecorationImage(image: AssetImage(Images.addImageOne),fit: BoxFit.cover),
                  //   ),
                  // ),
                  // SizedBox(width: 1.w,),
                  // Container(
                  //   width: 12.w,
                  //   height: 12.w,
                  //
                  //   decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.circular(15),
                  //     image: const DecorationImage(image: AssetImage(Images.addImageThree),fit: BoxFit.cover),
                  //   ),
                  // ),
                ],
              ),
            if (images.isEmpty)
              Container(
                margin: EdgeInsets.symmetric(vertical: 1.h),
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Colors.black,
                    border: Border.all(color: Colors.grey, width: 2)),
                child: Text(
                  "add_image",
                  style: TextStyleClass.normalStyle(
                      color: Colors.white, fontSize: 15.sp),
                ),
              ),
            if (images.isEmpty)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'upload_image'.replaceAll('*input*', count.toString()),
                    style: TextStyleClass.smallStyle(
                      color: Colors.black,
                    ),
                  ),
                  // const Spacer(),
                  // Icon(Icons.arrow_forward_ios,color: Colors.grey,size: Constants.isTablet?40:20,),
                ],
              ),
            Row(
              children: [
                if (images.isNotEmpty)
                  Text(
                    'delete_image',
                    style: TextStyleClass.smallStyle(
                      color: Colors.black,
                    ),
                  ),
                // const Spacer(),
                // Text('${images.length}/$count',style: TextStyle(
                //   color: Colors.black,
                //   fontSize: 12.sp,
                // ),),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
