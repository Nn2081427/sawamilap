import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/widgets/custom_text.dart';

final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

class CustomScreen extends StatelessWidget {
  const CustomScreen({
    super.key,
    this.appBar,
    this.body,
    this.drawer,
    this.bottomNavigationBar,
    this.actions,
    this.title,
    this.automaticallyImplyLeading,
    this.leading,
  });

  final PreferredSizeWidget? appBar;
  final Widget? body;
  final Widget? drawer;
  final Widget? bottomNavigationBar;
  final List<Widget>? actions;
  final String? title;
  final bool? automaticallyImplyLeading;
  final Widget? leading;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: scaffoldKey,
      appBar: appBar ??
          (title != null
              ? AppBar(
                  leading: leading,
                  automaticallyImplyLeading: automaticallyImplyLeading ?? true,
                  backgroundColor: AppColors.mainColor,
                  surfaceTintColor: AppColors.mainColor,
                  elevation: 0,
                  centerTitle: true,
                  title: CustomText(
                    text: title!,
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                  ),
                  actions: actions,
                )
              : null),
      bottomNavigationBar: bottomNavigationBar,
      drawer: drawer,
      backgroundColor: Colors.white,
      body: SafeArea(child: body ?? const SizedBox.shrink()),
    );
  }
}
