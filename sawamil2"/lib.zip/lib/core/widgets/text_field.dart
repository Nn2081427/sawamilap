import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';
import '../constants/constants.dart';
import '../theme/app_colors.dart';
import '../theme/text_style.dart';

class TextFieldWidget extends StatelessWidget {
  final bool obscureText, autoFocus, otp, readOnly, next, isLabel;
  final TextEditingController controller;
  final double? width, height, verticalPadding, borderRadius, elevation;
  final Widget? titleWidget, prefix, suffix;
  final void Function(String)? onChange;
  final void Function()? onTextTap, onEditingComplete, onSuffixTap;
  final int? maxLines, maxLength, minLines;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final String? counter, hintText;
  final List<TextInputFormatter>? inputFormatter;
  final Color? color,
      borderColor,
      cursorColor,
      focusedBorder,
      enabledBorder,
      errorStyleColor;
  final TextStyle? style, hintStyle, labelStyle;
  final TextAlign? textAlign;
  final EdgeInsets? contentPadding;
  final void Function(String)? onFieldSubmitted;
  const TextFieldWidget(
      {this.maxLines,
      this.labelStyle,
      this.hintText,
      this.cursorColor,
      required this.controller,
      this.height,
      this.width,
      this.style,
      this.focusedBorder,
      this.hintStyle,
      this.enabledBorder,
      this.isLabel = false,
      this.color,
      this.borderColor,
      this.borderRadius,
      this.counter,
      this.autoFocus = false,
      this.keyboardType,
      this.maxLength,
      this.next = true,
      this.obscureText = false,
      this.textAlign,
      this.onChange,
      this.onEditingComplete,
      this.onSuffixTap,
      this.otp = false,
      this.prefix,
      this.readOnly = false,
      this.suffix,
      this.onTextTap,
      this.titleWidget,
      this.validator,
      this.verticalPadding,
      super.key,
      this.minLines,
      this.contentPadding,
      this.elevation,
      this.errorStyleColor,
      this.inputFormatter, this.onFieldSubmitted});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: verticalPadding ?? 1.h,
      ),
      child: SizedBox(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            titleWidget ?? const SizedBox(),
            if (titleWidget != null)
              SizedBox(
                height: 0.8.h,
              ),
            Material(
              borderRadius: BorderRadius.circular(borderRadius ?? 12),
              elevation: elevation ?? 0,
              color: Colors.transparent,
              child: SizedBox(
                width: width ?? 100.w,
                height: height,
                child: TextFormField(
                  onFieldSubmitted:  onFieldSubmitted,
                  textAlign: textAlign ?? TextAlign.start,
                  obscureText: obscureText,
                  inputFormatters: inputFormatter,
                  onChanged: onChange,
                  controller: controller,
                  // cursorHeight: 25,
                  onTap: onTextTap ??
                      () {
                        TextEditingController c = controller;
                        if (c.selection ==
                            TextSelection.fromPosition(
                                TextPosition(offset: c.text.length - 1))) {
                          c.selection = TextSelection.fromPosition(
                              TextPosition(offset: c.text.length));
                        }
                      },
                  minLines: minLines,
                  cursorColor: cursorColor ?? Colors.black,

                  readOnly: readOnly,
                  autofocus: autoFocus,
                  maxLines: maxLines ?? 1,
                  maxLength: maxLength,
                  style: style ??
                      TextStyle(
                          fontSize: 16.sp,
                          color: Colors.black.withOpacity(0.6)),
                  validator: validator ??
                      (value) {
                        if (value!.isEmpty) {
                          return 'Field_is_required'.tr();
                        }
                        return null;
                      },
                  onEditingComplete: onEditingComplete ??
                      () {
                        FocusScope.of(context).unfocus();
                        if (next) {
                          FocusScope.of(context).nextFocus();
                        }
                      },
                  keyboardType: keyboardType,
                  decoration: inputDecoration(errorStyleColor: errorStyleColor),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration inputDecoration({Color? errorStyleColor}) {
    return InputDecoration(
      counterText: counter ?? "",
      isDense: true,
      counterStyle: TextStyleClass.normalStyle(),
      // labelText: labelText==null?null:LanguageProvider.translate('inputs', labelText!,),
      hintText: hintText ?? "text_field".tr(),
      fillColor: color ?? AppColors.textFieldBgColor,
      hintStyle: hintStyle ??
          Fonts.textBlack18.copyWith(
            color: Colors.grey,
            fontSize: 14,
          ),
      filled: true,
      labelStyle: Fonts.textBlack18.copyWith(color: Colors.grey),
      floatingLabelStyle: TextStyleClass.semiStyle(),
      border: focusedBorder != null
          ? null
          : border(borderRadius: borderRadius, color: borderColor, otp: otp),
      disabledBorder:
          border(borderRadius: borderRadius, color: borderColor, otp: otp),
      focusedBorder: border(
          borderRadius: borderRadius,
          color: focusedBorder ?? borderColor,
          borderWidth: focusedBorder == null ? 0 : 3,
          otp: otp),
      enabledBorder: border(
          borderRadius: borderRadius,
          color: enabledBorder ?? borderColor,
          otp: otp),
      errorBorder:
          border(color: Colors.red, borderRadius: borderRadius, otp: otp),
      focusedErrorBorder:
          border(color: Colors.red, borderRadius: borderRadius, otp: otp),
      hoverColor: Colors.grey,
      prefixIcon: prefix,
      errorStyle: TextStyleClass.normalStyle(
          color: errorStyleColor ?? Colors.red, fontSize: 13.sp),
      contentPadding: contentPadding ??
          EdgeInsets.symmetric(
              horizontal: 3.w, vertical: Constants.isTablet ? 1.4.h : 1.9.h),
      suffixIcon: suffix ??
          (onSuffixTap == null
              ? null
              : IconButton(
                  onPressed: onSuffixTap,
                  icon: Icon(
                    obscureText
                        ? Icons.visibility_off_outlined
                        : Icons.visibility,
                    size: 20,
                    color: obscureText ? Colors.grey : AppColors.mainColor,
                  ),
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent)),
    );
  }

  static InputBorder border(
      {Color? color,
      double? borderRadius,
      double? borderWidth,
      bool otp = false}) {
    if (otp) {
      return UnderlineInputBorder(
        borderRadius: BorderRadius.circular(0),
        borderSide: BorderSide(
            color: color ?? Colors.transparent, width: borderWidth ?? 1),
      );
    }
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(borderRadius ?? 10),
      borderSide: BorderSide(
          color: color ?? Colors.transparent, width: borderWidth ?? 1),
    );
  }

  static InputDecoration get decoration {
    return InputDecoration(
        isDense: true,
        counterStyle: TextStyleClass.normalStyle(),
        counterText: '',
        fillColor: Colors.white,
        border: border(),
        disabledBorder: border(),
        focusedBorder: border(),
        enabledBorder: border(),
        errorBorder: border(color: Colors.red),
        focusedErrorBorder: border(),
        contentPadding: EdgeInsets.symmetric(
            horizontal: 3.w, vertical: Constants.isTablet ? 1.4.h : 1.7.h));
  }
}
