import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:swamiil/features/orders/Presentation/cubits/finished_order_cubit/finished_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/new_order_cubit/new_order_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_cubit.dart';

class CustomTabBarWidget extends StatefulWidget {
  final List<String> tabTitles;
  final List<Widget> tabContents;

  const CustomTabBarWidget({
    super.key,
    required this.tabTitles,
    required this.tabContents,
  }) : assert(tabTitles.length == tabContents.length);

  @override
  State<CustomTabBarWidget> createState() => _CustomTabBarWidgetState();
}

class _CustomTabBarWidgetState extends State<CustomTabBarWidget> {
  int selectedIndex = 0;

  @override
  void initState() {
    context.read<NewOrderCubit>().getNewOrders();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildTabHeader(),
        Expanded(child: widget.tabContents[selectedIndex]),
      ],
    );
  }

  Widget _buildTabHeader() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: AppColors.textFieldBgColor,
      ),
      child: Row(
        children: List.generate(widget.tabTitles.length, (index) {
          final isSelected = selectedIndex == index;
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => selectedIndex = index);
                _handleTabChange(index); // Call function here
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  color: isSelected ? Colors.orange : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(
                  widget.tabTitles[index],
                  style: Fonts.textWhite18.copyWith(
                    color: isSelected ? Colors.white : Colors.black,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  void _handleTabChange(int index) {
    switch (index) {
      case 0:
        context.read<NewOrderCubit>().getNewOrders();
        break;
      case 1:
        context.read<WaitingOrdersCubit>().refresh();
        break;
      case 2:
        context.read<FinishedOrdersCubit>().refresh();
        break;
    }
  }
}
