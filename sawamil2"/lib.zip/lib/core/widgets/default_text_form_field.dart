import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/font_style.dart';

class DefaultTextFormField extends StatefulWidget {
  final String hintText;
  final Widget? suffixIcon;
  final TextInputType keyboardType;
  final String? Function(String?)? validator;
  final TextEditingController controller;
  final bool isPassword;
  final int? maxLength;
  final Color? hintTextColor;
  final bool? readOnly;
final void Function(String)? onChanged;
  const DefaultTextFormField({
    super.key,
    required this.hintText,
    required this.controller,
    this.keyboardType = TextInputType.text,
    this.isPassword = false,
    this.maxLength,
    this.suffixIcon,
    this.validator,
    this.hintTextColor,
    this.readOnly, this.onChanged,
  });

  @override
  State<DefaultTextFormField> createState() => _DefaultTextFormFieldState();
}

class _DefaultTextFormFieldState extends State<DefaultTextFormField> {
  bool isObscure = true;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onChanged: widget.onChanged,
      enabled: !(widget.readOnly ?? false),
      decoration: InputDecoration(
          fillColor: AppColors.textFieldBgColor,
          filled: true,
          suffixIcon: widget.isPassword
              ? IconButton(
                  onPressed: () => setState(() => isObscure = !isObscure),
                  icon: isObscure
                      ? const Icon(Icons.visibility_off_outlined)
                      : const Icon(Icons.visibility),
                )
              : null,
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ),
          disabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(15),
          ), // Added to remove line when readOnly
          hintText: widget.hintText,
          hintStyle: Fonts.textBlack18.copyWith(
            color: widget.hintTextColor ?? Colors.grey,
            fontSize: 14,
          )),
      style: const TextStyle(
        color: Colors.black,
      ),
      validator: widget.validator,
      controller: widget.controller,
      obscureText: widget.isPassword ? isObscure : false,
      keyboardType: widget.keyboardType,
      maxLength: widget.maxLength,
      textAlign: TextAlign.start,
    );
  }
}
