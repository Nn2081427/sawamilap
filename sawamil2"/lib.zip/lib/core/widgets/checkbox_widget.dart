import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';

class CheckBoxWidget extends StatelessWidget {
  const CheckBoxWidget(
      {super.key,
      required this.check,
      required this.onChange,
      this.padding,
      this.size});
  final bool check;
  final EdgeInsets? padding;
  final double? size;
  final void Function(bool val) onChange;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        onChange(!check);
      },
      child: Container(
        width: 5.w,
        height: 5.w,
        margin: EdgeInsets.symmetric(horizontal: 2.w),
        decoration: BoxDecoration(
          color: check ? AppColors.mainColor : Colors.white,
          borderRadius: BorderRadius.circular(5),
          border: Border.all(
              color: check ? AppColors.mainColor : Colors.grey.shade300),
        ),
        // padding: EdgeInsets.all(1.3.w),
        child: Icon(
          Icons.done,
          size: size ?? 10,
          color: Colors.white,
        ),
      ),
    );
  }
}
