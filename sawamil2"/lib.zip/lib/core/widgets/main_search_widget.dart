import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'text_field.dart';

class MainSearchWidget extends StatelessWidget {
  const MainSearchWidget({super.key, this.onChange, required this.controller});
  final void Function(String)? onChange;
  final TextEditingController controller;
  @override
  Widget build(BuildContext context) {
    return TextFieldWidget(
      verticalPadding: 1.h, width: 100.w,
      borderColor: Colors.transparent, color: Colors.grey.shade100,
      onChange: onChange, borderRadius: 4,
      height: 5.h, controller: controller,
      prefix: Icon(Icons.search,color: AppColors.mainColor,),
    );
  }
}