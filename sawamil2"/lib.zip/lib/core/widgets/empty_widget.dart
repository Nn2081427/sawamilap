import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

class EmptyWidget extends StatelessWidget {
  final String title;
  final String image;
  const EmptyWidget({super.key, required this.title, required this.image});
  @override
  Widget build(BuildContext context) {
    return Center(
        child: SizedBox(
            // height: 30.h,
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Image.asset(
        image,
        width: 60.w,
        fit: BoxFit.fitWidth,
      ),
      SizedBox(height: 1.h),
      Text(
        title.tr(),
        style: Fonts.text14Black,
      )
    ])));
  }
}
