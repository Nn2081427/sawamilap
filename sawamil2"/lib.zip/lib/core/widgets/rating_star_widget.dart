import 'package:flutter/material.dart';
import 'package:simple_star_rating/simple_star_rating.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

class RatingStarWidget extends StatelessWidget {
  const RatingStarWidget(
      {super.key,
      this.onRate,
      this.read = false,
      this.rate = 5,
      this.showText = true,
      this.iconSize});
  final void Function(double rate)? onRate;
  final bool read, showText;
  final double rate;
  final double? iconSize;
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Directionality(
          textDirection: TextDirection.rtl,
          child: SimpleStarRating(
            allowHalfRating: true,
            starCount: 5,
            rating: rate,
            size: iconSize ?? 18,
            isReadOnly: read,
            onRated: (rate) {
              if (onRate != null) {
                onRate!(rate ?? 0.0);
              }
            },
            spacing: 10,
          ),
        ),
        if (showText)
          SizedBox(
            width: 3.w,
          ),
        if (showText)
          Text(
            '($rate)',
            style: Fonts.textSplash14.copyWith(color: Colors.black),
          ),
      ],
    );
  }
}
