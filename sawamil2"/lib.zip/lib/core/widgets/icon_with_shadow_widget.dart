import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'svg_widget.dart';


class IconWithShadowWidget extends StatelessWidget {
  const IconWithShadowWidget({super.key, required this.image, this.onTap, this.size});
  final String image ;
  final VoidCallback? onTap;
  final bool? size;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        if(onTap !=null){
          onTap!();
        }
      },
      child: Container(
        padding:size !=null? EdgeInsets.all( 1.w) :  EdgeInsets.all( 1.5.h),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            spreadRadius: 1,
            blurRadius: 4,
            offset: const Offset(0, 6),
          )],
        ),
        child:SvgWidget(svg: image,width:size !=null? 4.w: 6.w,),
      ),
    );
  }
}
