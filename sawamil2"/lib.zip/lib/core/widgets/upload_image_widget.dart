// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';
//
// import '../constants/constants.dart';
// import 'svg_widget.dart';
//
// class UploadImageWidget extends StatelessWidget {
//   const UploadImageWidget({super.key, required this.fromAuth});
//   final bool fromAuth ;
//
//   @override
//   Widget build(BuildContext context) {
//     var authProvider = Provider.of<AuthProvider>(context);
//     return InkWell(
//       onTap: () async {
//         if (authProvider.image != null) {
//           showDialog(
//               context: context,
//               builder: (ctx) {
//                 return Container(
//                   height: 35.w,
//                   width: 35.w,
//                   decoration: BoxDecoration(
//                       shape: BoxShape.circle,
//                       image: DecorationImage(
//                           image: authProvider.showUserImage(),
//                           fit:authProvider.image==null? BoxFit.contain:BoxFit.cover)),
//                 );
//               });
//         }else{
//           FocusScope.of(context).unfocus();
//           XFile? image = await chooseImage();
//           if (image != null) {
//             authProvider.updateImage(image);
//           }
//         }
//       },
//       child: Column(
//         children: [
//           SizedBox(
//             width: 17.h,
//             height: 17.h,
//             child: Stack(
//               alignment: LanguageProvider.isAr() ? Alignment.bottomRight : Alignment.bottomLeft,
//               children: [
//
//                 Container(
//                   width: 34.w,
//                   height: 34.w,
//                   padding: EdgeInsets.all(0.2.w),
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,gradient: AppColor.gradient
//                   ),
//                   child: Container(
//                     width: 34.w,
//                     height: 34.w,
//                     padding: EdgeInsets.all(6.w),
//                     decoration: BoxDecoration(
//                         shape: BoxShape.circle,color: Colors.white
//                       // image: DecorationImage(
//                       //     fit: authProvider.image==null? BoxFit.fill:BoxFit.cover,
//                       //     image: authProvider.showUserImage()
//                       // )
//                     ),
//                     child: Image(image: authProvider.showUserImage(),
//                       fit: authProvider.image==null? BoxFit.fill:BoxFit.cover,
//                     ),
//                   ),
//                 ),
//                 PositionedDirectional(
//                   bottom: Constants.isTablet?0: 0.5.h,
//                   end: Constants.isTablet?0:2.w,
//
//                   child: InkWell(
//                       onTap: () async {
//                         FocusScope.of(context).unfocus();
//                         XFile? image = await chooseImage();
//                         if (image != null) {
//                           // authProvider.updateImage(image);
//                         }
//                       },
//                       child:  CircleAvatar(
//                         radius: 0.w,
//                         backgroundColor: AppColor.defaultColor,
//                         child: Icon(Icons.add,color: Colors.white,size: 5.w,),
//                       )),
//                 ),
//               ],
//             ),
//           ),
//           SizedBox(height: 1.h),
//           fromAuth ?Text(
//             LanguageProvider.translate('register', 'image'),
//             style: TextStyleClass.normalStyle(),
//           ) :const SizedBox() ,
//         ],
//       ),
//     );
//   }
// }
//
//
