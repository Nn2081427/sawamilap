import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pinch_zoom/pinch_zoom.dart';
import 'package:sizer/sizer.dart';

import '../../features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import '../constants/constants.dart';
import '../helper_function/navigation.dart';
import '../theme/font_style.dart';
import 'button_widget.dart';
import 'custom_button.dart';

class ImagePreviewWidget extends StatelessWidget {
  final XFile? img;
  final String? imgPath;
  final bool showSendButton;
  const ImagePreviewWidget(
      {this.img, this.imgPath, super.key, required this.showSendButton});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        bottomNavigationBar: img == null && !showSendButton
            ? null
            : Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomButton(
                      onTap: () {
                        navPop();
                        context.read<MessagesCubit>().sendImageMessage(
                            chatId: context.read<MessagesCubit>().currentChat!.id,
                            imageFile: img!);
                      },
                      padding: EdgeInsets.symmetric(vertical: 12),
                      borderRadius: BorderRadius.circular(8),
                      child: Center(
                        child: Text(
                          "send".tr(),
                          style: Fonts.text14Black,
                        ),
                      )),
                  SizedBox(
                    height: 1.h,
                  ),
                ],
              ),
        extendBody: true,
        appBar: AppBar(
          backgroundColor: Colors.black,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
              size: 6.w,
            ),
            onPressed: () => Navigator.of(Constants.globalContext()).pop(),
          ),
          title: const SizedBox(),
        ),
        body: PinchZoom(
          maxScale: 2.5,
          child: Container(
            width: 100.w,
            height: 95.h,
            decoration: BoxDecoration(
              image: img == null
                  ? DecorationImage(
                      image: CachedNetworkImageProvider(imgPath!),
                      fit: BoxFit.contain,
                    )
                  : DecorationImage(
                      image: FileImage(File(img!.path)),
                      fit: BoxFit.contain,
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
