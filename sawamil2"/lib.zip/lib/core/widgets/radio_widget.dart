import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';

import '../constants/constants.dart';

class RadioWidget extends StatelessWidget {
  const RadioWidget({super.key, required this.selected, required this.myColor, this.onTap});
  final bool selected;
  final Color myColor;
  final void Function()? onTap;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: Constants.isTablet ? 4.w : 4.w,
        height: Constants.isTablet ? 4.w : 4.w,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: myColor, width: 2.5)),
        padding: EdgeInsets.all(0.7.w),
        child: Container(decoration: BoxDecoration(color: selected ? AppColors.mainColor : Colors.white, shape: BoxShape.circle)),
      ),
    );
  }
}
