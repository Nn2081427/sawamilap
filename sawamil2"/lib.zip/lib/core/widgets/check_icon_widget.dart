// import 'package:flutter/material.dart';
// import 'package:swamiil/core/widgets/checkbox_widget.dart';

// class CheckIconWidget extends StatelessWidget {
//   const CheckIconWidget({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<SubjectBloc, SubjectState>(
//       builder: (context, state) {
//         return ;
//       },
//     );
//   }
// }
