import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import 'package:swamiil/core/theme/text_style.dart';

import '../constants/constants.dart';

class ButtonWidget extends StatelessWidget {
  final double? width, height, borderRadius, elevation;
  final void Function() onTap;
  final Color? color, borderColor;
  final String text;
  final String? textReplace;
  final EdgeInsetsGeometry? padding;
  final BorderRadiusGeometry? directionBorderRadius;
  final TextStyle? textStyle;
  final Widget? widget;
  final bool widgetAfterText, takeSmallestWidth, isGradient;
  const ButtonWidget(
      {this.widget,
      this.width,
      this.height,
      this.textReplace,
      this.directionBorderRadius,
      required this.onTap,
      this.borderRadius,
      required this.text,
      this.textStyle,
      this.borderColor,
      this.color,
      this.widgetAfterText = true,
      super.key,
      this.takeSmallestWidth = false,
      this.elevation,
      this.isGradient = false, this.padding});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: takeSmallestWidth ? null : (width ?? 90.w),
        height: height ?? (Constants.isTablet ? 7.h :6.h),
        decoration: BoxDecoration(
          borderRadius: directionBorderRadius ?? BorderRadius.circular(borderRadius ?? 3.w),
          color:color ?? AppColors.mainColor,
          // gradient: isGradient == true ? AppColor.gradient : null,
          border: borderColor == null || color == null
              ? null
              : Border.all(color: borderColor!),
        ),
        child: Padding(
          padding:padding ?? EdgeInsets.symmetric(horizontal: 2.w,),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (!widgetAfterText) widget ?? const SizedBox(),
              Text(
                textReplace!,
                style:
                    textStyle ?? TextStyleClass.normalBoldStyle(color: Colors.white),
              ),
              if (widgetAfterText) widget ?? const SizedBox(),
            ],
          ),
        ),
      ),
    );
  }
}

class BorderButtonWidget extends StatelessWidget {
  final double? width, height, borderRadius;
  final void Function() onTap;
  final Color? color;
  final String text;
  final EdgeInsetsGeometry? padding;
  final TextStyle? textStyle;
  final Widget? widget;
  final bool widgetAfterText, takeSmallestWidth;
  const BorderButtonWidget(
      {this.widget,
      this.width,
      this.height,
      required this.onTap,
      this.borderRadius,
      required this.text,
      this.textStyle,
      this.color,
      this.widgetAfterText = true,
      super.key,
      this.takeSmallestWidth = false, this.padding});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: takeSmallestWidth ? null : (width ?? 90.w),
        height: height ?? (Constants.isTablet ? 7.h :6.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(borderRadius ?? 10),
          color: Colors.white,
          border: Border.all(color: color ?? AppColors.mainColor),
        ),
        child: Padding(
          padding: padding ?? EdgeInsets.symmetric(horizontal: 2.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (!widgetAfterText) widget ?? const SizedBox(),
              if (!widgetAfterText && widget != null)
                SizedBox(
                  width: 3.w,
                ),
              Text(
               text,
                style: textStyle ??
                    TextStyleClass.textButtonStyle(
                        color: color ?? Colors.white),
              ),
              if (widgetAfterText && widget != null)
                SizedBox(
                  width: 3.w,
                ),
              if (widgetAfterText) widget ?? const SizedBox(),
            ],
          ),
        ),
      ),
    );
  }
}
