import 'package:flutter/material.dart';
import 'package:swamiil/core/theme/font_style.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewPage extends StatefulWidget {
  final String title;
  final String link;
  const WebViewPage({required this.title, required this.link, super.key});

  @override
  State<WebViewPage> createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  WebViewController controller = WebViewController();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
          },
          onPageStarted: (String url) {},
          onPageFinished: (String url) {},
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) {
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.link));
  }

  @override
  Widget build(BuildContext context) {
    // if (Platform.isAndroid) WebView.platform = AndroidWebView();
    return Scaffold(
      backgroundColor: Colors.white,
      // appBar: defaultAppBar( isCircular: true,hideArrow: true,
      //     title : LanguageProvider.translate("more", widget.title)),
      appBar: AppBar(
          title: Text(widget.title,
              style: Fonts.headTitle20.copyWith(fontWeight: FontWeight.w500)),
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 2),
      body: WebViewWidget(controller: controller),
    );
  }
}
