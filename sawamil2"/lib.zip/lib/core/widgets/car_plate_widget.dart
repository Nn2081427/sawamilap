// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:sizer/sizer.dart';
// import 'package:swamiil/core/theme/text_style.dart';
// import 'text_car_plate_widget.dart';

// class CarPlateWidget extends StatelessWidget {
//   const CarPlateWidget({super.key, this.plateAr, this.plateEn});
//   final String? plateAr,plateEn;
//   @override
//   Widget build(BuildContext context) {
//     // CheckoutProvider checkoutProvider = Provider.of(context);
//     return Container(
//       width: 100.w,
//       height: 16.h,
//       decoration: BoxDecoration(
//         border: Border.all(color: Colors.black,width: 2),
//         borderRadius: BorderRadius.circular(12),
//       ),
//       margin: EdgeInsets.only(right: 5.w,left: 5.w,bottom: 1.5.h),
//       padding: EdgeInsets.zero,
//       child: Row(
//         children: [
//           Container(
//             height: 16.h,
//             decoration: BoxDecoration(
//                 color:Color(0xff003A18),borderRadius: BorderRadiusDirectional.horizontal(start: Radius.circular(8)),
//             ),
//             padding: EdgeInsets.symmetric(horizontal: 2.w,vertical: 1.3.h),
//             child: FittedBox(
//               child: Column(
//                 children: [
//                   // Image.asset(Images.ksa,width:8.w,),
//                   SizedBox(height: 0.5.h,),
//                   Text('السعودية',style: TextStyleClass.tinyStyle(color: Colors.white),),
//                   SizedBox(height: 0.5.h,),
//                   Text('K',style: TextStyleClass.smallBoldStyle(color: Colors.white),),
//                   SizedBox(height: 0.5.h,),
//                   Text('S',style: TextStyleClass.smallBoldStyle(color: Colors.white),),
//                   SizedBox(height: 0.5.h,),
//                   Text('A',style: TextStyleClass.smallBoldStyle(color: Colors.white),),
//                   // SizedBox(height: 0.5.h,),
//                   // CircleAvatar(backgroundColor: Colors.black,radius: 1.5.w,),
//                 ],
//               ),
//             ),
//           ),
//           // SizedBox(width: 2.w,),
//           Container(
//             width: 2,
//             height: 16.h,
//             color: Colors.black,
//           ),
//           Expanded(
//             flex: 4,
//             child: Column(
//               children: [
//                 Expanded(
//                   child: plateAr!=null?TextCarPlateWidget(text: plateAr!, changeIndex: 4, addIndex: 4):
//                   BoardWidget(inputs: checkoutProvider.plateAr, changeIndex: 4, addIndex: 4,hintText: checkoutProvider.hintTextAr,),
//                 ),
//                 Container(
//                   height: 2,
//                   color: Colors.black,
//                 ),
//                 Expanded(
//                   child: plateEn!=null?TextCarPlateWidget(text: plateEn!, changeIndex: 4, addIndex: 4):
//                   BoardWidget(inputs: checkoutProvider.plateEn, changeIndex: 4, addIndex: 4,hintText: checkoutProvider.hintTextEn,),
//                 ),
//               ],
//             ),
//           ),
//           Container(
//             width: 2,
//             height: 16.h,
//             color: Colors.black,
//           ),
//           Expanded(
//             flex: 5,
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 Expanded(
//                   child: plateAr!=null?TextCarPlateWidget(text: plateAr!, changeIndex: 3, addIndex: 0):
//                   BoardWidget(inputs: checkoutProvider.plateAr, changeIndex: 3, addIndex: 0,hintText: checkoutProvider.hintTextAr,),
//                 ),
//                 Container(
//                   height: 2,
//                   color: Colors.black,
//                 ),
//                 Expanded(
//                   child: plateEn!=null?TextCarPlateWidget(text: plateEn!, changeIndex: 3, addIndex: 0):
//                   BoardWidget(inputs: checkoutProvider.plateEn, changeIndex: 3, addIndex: 0,hintText: checkoutProvider.hintTextEn,),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
