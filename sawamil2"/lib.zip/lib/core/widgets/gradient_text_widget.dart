// import 'package:flutter/material.dart';

// import '../../config/app_color.dart';
// import '../../config/text_style.dart';
// import '../../features/language/presentation/provider/language_provider.dart';

// class GradientTextWidget extends StatelessWidget {
//   final String? translationKey;
//   final String? value;
//   final String? title;
//   final TextStyle? style;
//   final int? maxLines;

//   const GradientTextWidget({super.key, this.title,this.value, this.translationKey, this.style, this.maxLines});

//   @override
//   Widget build(BuildContext context) {
//     return ShaderMask(
//       shaderCallback: (bounds) => AppColor.gradient.createShader(bounds),
//       blendMode: BlendMode.srcIn,
//       child: Text(title ?? LanguageProvider.translate(translationKey!, value!),
//           style: style ?? TextStyleClass.normalStyle(color: AppColor.defaultColor), maxLines: maxLines, overflow: TextOverflow.ellipsis),
//     );
//   }
// }
