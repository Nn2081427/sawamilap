
// import 'package:flutter/material.dart';
// import 'package:sizer/sizer.dart';
// import 'package:swamiil/core/helper_function/convert.dart';
// import 'package:swamiil/core/theme/text_style.dart';

// import '../dialog/date_dialog.dart';

// class SelectDayWidget extends StatefulWidget {
//   const SelectDayWidget({Key? key, required this.dateTime, required this.onChange}) : super(key: key);
//   final DateTime dateTime;
//   final void Function(DateTime time) onChange;

//   @override
//   State<SelectDayWidget> createState() => _SelectDayWidgetState(dateTime);
// }

// class _SelectDayWidgetState extends State<SelectDayWidget> {
//   late DateTime dateTime;

//   _SelectDayWidgetState(this.dateTime);

//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       onTap: ()async{
//         DateTime? newDate = await selectDate(dateTime: dateTime,lastDate: DateTime.now(),firstDate: DateTime(1960));
//         if(newDate!=null){
//           dateTime = newDate;
//         widget.onChange(newDate);
//           setState(() {

//           });
//         }
//       },
//       child: Container(
//         width: 35.w,
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(12),
//           border: Border.all(color: Colors.grey.shade300),
//         ),
//         padding: EdgeInsets.symmetric(horizontal: 2.w,vertical: 1.h),
//         child: Row(
//           children: [
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(convertDateToStringDMMMY(dateTime),style: TextStyleClass.semiStyle(),),
//                 SizedBox(height: 0.5.h,),
//                 Text(getDayNameFromDate(dateTime),style: TextStyleClass.normalStyle(color: Colors.grey),),
//               ],
//             ),
//             Spacer(),
//             Icon(Icons.arrow_drop_down,size: 20,),
//           ],
//         ),
//       ),
//     );
//   }
// }
