import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class DottedLinePainter extends CustomPainter {
  DottedLinePainter({this.color, required Container child});
  final Color? color;

  @override
  void paint(Canvas canvas, Size size) {
    double dashHeight = 2.h;
    double dashSpace = 3;
    double startY = 0;

    final paint = Paint()
      ..color = color ?? Colors.grey.shade300
      ..strokeWidth = 2;

    while (startY < size.height) {
      canvas.drawLine(
        Offset(size.width / 2, startY),
        Offset(size.width / 2, startY + dashHeight),
        paint,
      );
      startY += dashHeight + dashSpace;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
