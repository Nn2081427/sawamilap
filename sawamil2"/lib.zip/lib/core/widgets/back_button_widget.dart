import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/app_colors.dart';
import '../constants/constants.dart';
import '../helper_function/navigation.dart';


class BackButtonWidget extends StatelessWidget {
  const BackButtonWidget({super.key, this.color, this.onTap});
  final Color? color;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        if(onTap!=null){
          onTap!();
        }else{
          navPop();
        }
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: EdgeInsets.all(Constants.isTablet?1.w:2.5.w),
            margin: EdgeInsets.symmetric(vertical: 1.h,horizontal: 2.w),
            decoration: BoxDecoration(
                color: Colors.white,borderRadius: BorderRadius.circular(15)
            ),
            child: Icon(Icons.arrow_back_rounded,color: AppColors.mainColor,size: 5.w,),
          ),
        ],
      ),
    );
  }
}
