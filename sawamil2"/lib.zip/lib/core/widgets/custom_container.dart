import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:swamiil/core/theme/font_style.dart';

class CustomContainerWithRow extends StatelessWidget {
  final String svgAssetPath;
  final String text;
  final double height;
  final double width;
  final Color backgroundColor;
  final EdgeInsetsGeometry padding;
  final TextStyle? textStyle;
  final VoidCallback? onTap;

  const CustomContainerWithRow({
    super.key,
    required this.svgAssetPath,
    required this.text,
    this.height = 60,
    this.width = double.infinity,
    this.backgroundColor = Colors.white,
    this.padding = const EdgeInsets.symmetric(horizontal: 16),
    this.textStyle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: height,
        width: width,
        padding: padding,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                text,
                style: textStyle,
              ),
              const SizedBox(width: 10),
              SvgPicture.asset(
                svgAssetPath,
                height: 22,
                width: 22,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
