import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class MainLayoutPage extends StatelessWidget {
  const MainLayoutPage({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.w,
      height: 100.h,
      child: Stack(
        children: [
          Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.center,
                colors: [const Color(0xFFFFE8DB), Colors.white,Colors.white],
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }
}
