import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/theme/font_style.dart';

import '../constants/constants.dart';
import '../models/text_field_model.dart';
import 'svg_widget.dart';
import 'text_field.dart';

class ListTextFieldWidget extends StatelessWidget {
  const ListTextFieldWidget(
      {super.key,
      required this.inputs,
      this.maxLength,
      this.inputFormatter,
      this.style,
      this.color,
      this.borderColor,
      this.expands,
      this.isGradient,
      this.textColor,
      this.errorStyleColor,
      
      this.isWrap = false});
  final List<TextFieldModel> inputs;
  final TextStyle? style;
  final bool? isGradient;
  final bool isWrap;
  final bool? expands;
  final Color? borderColor, errorStyleColor, textColor, color;
  final List<TextInputFormatter>? inputFormatter;
  final int? maxLength;
  @override
  Widget build(BuildContext context) {
    List telInputs = ['phone', 'whats'];
    List<Widget> inputWidgets = List.generate(
      inputs.length,
      (index) {
        TextFieldWidget textFieldWidget = TextFieldWidget(
          inputFormatter: inputs[index].inputFormatter,
          errorStyleColor: errorStyleColor,
       
          titleWidget: inputs[index].label != null
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(inputs[index].label!.tr(),
                        style: style ?? Fonts.textBlack18),
                    if (inputs[index].image != null)
                      SizedBox(
                        width: 2.w,
                      ),
                    if (inputs[index].image != null)
                      SvgWidget(
                        svg: inputs[index].image!,
                        width: Constants.isTablet ? 5.w : null,
                        color: textColor,
                      ),
                  ],
                )
              : null,
          color: color,
          height: inputs[index].height,
          borderColor: borderColor,
          isLabel: inputs[index].isLabel ?? false,
         //  maxLength: telInputs.contains(inputs[index].key) ? 10 : null,
           maxLength: inputs[index].maxLength,
          controller: inputs[index].controller,
          keyboardType: inputs[index].textInputType,
          next: inputs.length - 1 != index,
          hintText: inputs[index].hint,
          onTextTap: inputs[index].onTap,
          minLines: inputs[index].min,
          maxLines: inputs[index].max,
          validator: inputs[index].validator,
          obscureText: inputs[index].obscureText,
          suffix: inputs[index].suffix,
          prefix: inputs[index].prefix,
          readOnly: inputs[index].readOnly,
          width: inputs[index].width,
          contentPadding: inputs[index].contentPadding,
          labelStyle: inputs[index].labelStyle,
          
          
        );
        return textFieldWidget;
      },
    );
    if (isWrap) {
      return SizedBox(
        width: double.infinity,
        child: Wrap(
          alignment: WrapAlignment.spaceBetween,
          children: inputWidgets,
        ),
      );
    }
    return Column(
      children: inputWidgets,
    );
  }
}
