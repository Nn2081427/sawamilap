import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:swamiil/core/theme/app_colors.dart';

class CustomImageCacheProvider extends StatelessWidget {
  final dynamic imageUrl;
  final double? width;
  final double? height;
  final BoxFit? fit;
  final double? borderRadius;
  final Widget? placeholder;
  final Widget? errorWidget;

  const CustomImageCacheProvider({
    super.key,
    required this.imageUrl,
    this.width,
    this.height,
    this.fit,
    this.borderRadius,
    this.placeholder,
    this.errorWidget,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(borderRadius ?? 0),
      child: Builder(builder: (context) {
        if (imageUrl is XFile) {
          return Image.file(
            File(imageUrl.path),
            width: width,
            height: height,
            fit: fit ?? BoxFit.cover,
          );
        }

        return CachedNetworkImage(
          imageUrl: imageUrl,
          width: width,
          height: height,
          fit: fit ?? BoxFit.cover,
          placeholder: (context, url) => Shimmer.fromColors(
            baseColor: AppColors.textFieldBgColor.withOpacity(0.5),
            highlightColor: Colors.white.withOpacity(0.8),
            period: const Duration(milliseconds: 1000),
            child: Container(
              width: width,
              height: height,
              color: AppColors.textFieldBgColor,
            ),
          ),
          errorWidget: (context, url, error) =>
              errorWidget ?? const Icon(Icons.error),
        );
      }),
    );
  }
}
