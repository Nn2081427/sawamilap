
sealed class LanguageState {}

class LanguageInitial extends LanguageState {}

class LanguageChangedState extends LanguageState {}
