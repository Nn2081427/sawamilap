class Failure {
  final String errMessage;
  Failure({required this.errMessage});
}
