// import 'dart:convert';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:provider/provider.dart';
// import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
// import 'package:swamiil/features/offers/data/models/offer_model.dart';
// import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_cubit.dart';
// import '../../features/chat/data/models/message_model.dart';
// import '../constants/constants.dart';
// import '../models/local_notifications.dart';
// import 'convert.dart';
//
// Future notificationsFirebase()async{
//   FirebaseMessaging.onMessage.listen((event) async{
//     if(event.notification!=null){
//       appNotifications(event.notification!,payload: event.data,fromWhereClicked: 1);
//     }
//   });
//
//   FirebaseMessaging.onMessageOpenedApp.listen((event) async{
//
//     if(event.notification!=null){
//       appNotifications(event.notification!,click: true,fromWhereClicked: 2,
//           payload: event.data);
//     }
//   });
//   NotificationSettings settings = await FirebaseMessaging.instance.requestPermission(sound: true, badge: false, alert: true, criticalAlert: true, provisional: true);
//
//
//   // if (settings.authorizationStatus == AuthorizationStatus.authorized) {
//   //
//   // } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
//   //
//   // } else {
//   //
//   // }
// }
//
//
// void appNotifications(RemoteNotification data2,
//     {bool click = false,bool start = false,Map? payload,required int fromWhereClicked})async {
//   bool showNotificationLocal = true;
//
//   if (payload!.containsKey('message_type_')) {
//
//     if (payload['message_type_'] == "chat") {
//       try{
//         Map message = jsonDecode(payload['data_']);
//         MessageModel messageModel = MessageModel.fromJson(message);
//         MessagesCubit messageProvider = Constants.globalContext().read<MessagesCubit>();
//         bool check = messageProvider.checkMessageOfThisChat(convertStringToInt(message['chat']['id']));
//         print('start_not3');
//         if(check){
//           showNotificationLocal = false;
//           messageProvider.addOneMessage(messageModel);
//         }
//       }catch(e){
//         print(e);
//       }
//
//     } else if (payload['message_type_'] == "order") {
//       int orderId = convertStringToInt(jsonDecode(payload['data_']));
//
//       WaitingOrdersCubit waitingOrdersCubit = Constants.globalContext().read<WaitingOrdersCubit>();
//       if(waitingOrdersCubit.pagingController.itemList!=null){
//         waitingOrdersCubit.removeOrder(orderId);
//       }
//     } else if (payload['message_type_'] == "offer"){
//
//       Map data = jsonDecode(payload['data_']);
//       int offerId = convertStringToInt(data['offer_id']);
//       OfferModel? offerModel;
//       if(data.containsKey('offer')&&data['offer']!=null){
//         offerModel = OfferModel.fromJson(data['offer']);
//       }
//       // offercubit
//
//       if(){
//         if(offerModel!=null){
//           // addoffer
//         }else{
//           // delete offer
//         }
//       }
//
//
//     }else if (payload['message_type_'] == "order_details"){
//
//       int orderId = convertStringToInt(jsonDecode(payload['data_']));
//       // order details cubit
//       if(cubit.orderEntity?.id!=orderId){
//         // load order details
//       }
//
//
//
//     }else if (payload['message_type_'] == "new_offer"){
//       // OfferMoeel offerMoeel = OfferMoeel.fromJson(jsonDecode(payload['data_']));
//       // cubit
//       // check page inside it or not
//       // add
//     }
//   }
//
//   if(click&&AuthProvider.isLogin()&&fromWhereClicked==2){
//     clickNoti(jsonEncode(payload));
//     NotificationLocalClass.notificationsPlugin.cancelAll();
//   }
//   if(showNotificationLocal&&AuthProvider.isLogin()&&!click){
//     NotificationLocalClass.showNoti(title: data2.title??"", body: data2.body??"", payload: jsonEncode(payload));
//   }
//
// }
// // final AudioPlayer audioPlayer = AudioPlayer();
// //
// // Future<void> playSuccessSound({required String path}) async {
// //   await audioPlayer.play(AssetSource('sounds/$path'));
// // }