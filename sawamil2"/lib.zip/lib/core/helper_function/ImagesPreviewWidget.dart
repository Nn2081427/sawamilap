import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:pinch_zoom/pinch_zoom.dart';
import 'package:sizer/sizer.dart';
import '../constants/constants.dart';
import '../helper_function/navigation.dart';

class ImagesPreviewWidget extends StatefulWidget {
  final List<dynamic> images;
  final int? index;

  const ImagesPreviewWidget({super.key, required this.images, this.index});

  @override
  State<ImagesPreviewWidget> createState() => _ImagesPreviewWidgetState();
}

class _ImagesPreviewWidgetState extends State<ImagesPreviewWidget> {
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: widget.index ?? 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox(
        width: 100.w,
        height: 100.h,
        child: Stack(
          children: [
            PageView.builder(
              controller: _pageController,
              itemCount: widget.images.length,
              itemBuilder: (context, index) {
                return PinchZoom(
                  maxScale: 2.5,
                  child: Container(
                    width: 100.w,
                    height: 100.h,
                    decoration: BoxDecoration(
                      color: Colors.black,
                    ),
                    child: Center(
                      child: _buildImageWidget(widget.images[index]),
                    ),
                  ),
                );
              },
            ),
            PositionedDirectional(
              top: 8.h,
              start: 3.w,
              child: Container(
                margin: EdgeInsets.all(1.5.w),
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.3)),
                child: Transform.scale(
                  scale: Constants.isTablet ? 2 : 1,
                  child: BackButton(
                    color: Colors.white,
                    onPressed: () {
                      navPop();
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageWidget(dynamic image) {
    try {
      if (image is String) {
        return Hero(
          tag: image,
          child: CachedNetworkImage(
            imageUrl: image,
            fit: BoxFit.contain,
            placeholder: (context, url) =>
                const Center(child: CircularProgressIndicator()),
            errorWidget: (context, url, error) => const Icon(Icons.error),
          ),
        );
      } else if (image is XFile) {
        return Hero(
          tag: image.path,
          child: Image.file(
            File(image.path),
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) {
              print('Error loading image: $error');
              return const Icon(Icons.error, size: 50);
            },
          ),
        );
      } else {
        // Fallback
        return const Icon(Icons.error, size: 50);
      }
    } catch (e) {
      print('Error displaying image: $e');
      return const Icon(Icons.error, size: 50);
    }
  }
}
