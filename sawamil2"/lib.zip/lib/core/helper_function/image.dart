import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/helper_function/AddImagePage.dart';
import 'package:swamiil/core/helper_function/navigation.dart';

Future<XFile?> chooseImage({BuildContext? context, bool video = false}) async {
  final ctx = context ?? Constants.globalContext();
  return showCupertinoModalPopup<XFile?>(
    context: ctx,
    builder: (BuildContext context) => Transform.scale(
      scale: 1,
      child: CupertinoAlertDialog(
        title: const Text('Select source', style: TextStyle(fontSize: 16)),
        actions: <CupertinoDialogAction>[
          CupertinoDialogAction(
            onPressed: () async {
              final file = video
                  ? await pickVideo(context, 1)
                  : await pickImage(context, 1);
              Navigator.pop(context, file);
            },
            child: const Text('Camera'),
          ),
          CupertinoDialogAction(
            onPressed: () async {
              final file = video
                  ? await pickVideo(context, 2)
                  : await pickImage(context, 2);
              Navigator.pop(context, file);
            },
            child: const Text('Gallery'),
          )
        ],
      ),
    ),
  );
}

Future<List<XFile>?> chooseImageMulti(BuildContext context,
    {bool video = false}) {
  return showCupertinoModalPopup<List<XFile>?>(
    context: context,
    builder: (BuildContext context) => Transform.scale(
      scale: 1,
      child: CupertinoAlertDialog(
        title: const Text('Select source', style: TextStyle(fontSize: 16)),
        actions: <CupertinoDialogAction>[
          CupertinoDialogAction(
            onPressed: () async {
              final files = await pickMultiImageCamera(context, 1);
              // Navigator.pop(context, files);
            },
            child: const Text('Camera'),
          ),
          CupertinoDialogAction(
            onPressed: () async {
              final files = await pickMultiImageCamera(context, 2);
              Navigator.pop(context, files);
            },
            child: const Text('Gallery'),
          )
        ],
      ),
    ),
  );
}

Future<String?> checkPermission(int type) async {
  if (type == 1) {
    var status = await Permission.camera.status;
    if (!status.isGranted) {
      status = await Permission.camera.request();
      if (!status.isGranted) {
        return 'Camera permission denied';
      }
    }
  } else {
    var status = await Permission.photos.status;
    if (!status.isGranted) {
      status = await Permission.photos.request();
      if (!status.isGranted) {
        return 'Gallery permission denied';
      }
    }
  }
  return null;
}

Future<XFile?> pickImage(BuildContext context, int type) async {
  final picker = ImagePicker();
  try {
    if (type == 1) {
      final status = await checkPermission(1);
      if (status != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(status)),
        );
        return null;
      }
      return await picker.pickImage(
          source: ImageSource.camera, imageQuality: 80);
    } else {
      final status = await checkPermission(2);
      if (status != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(status)),
        );
        return null;
      }
      return await picker.pickImage(
          source: ImageSource.gallery, imageQuality: 80);
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error picking image: $e')),
    );
    return null;
  }
}

Future<XFile?> pickVideo(BuildContext context, int type) async {
  const maxDuration = Duration(minutes: 5);
  final picker = ImagePicker();
  try {
    if (type == 1) {
      final status = await checkPermission(1);
      if (status != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(status)),
        );
        return null;
      }
      return await picker.pickVideo(
        source: ImageSource.camera,
        maxDuration: maxDuration,
      );
    } else {
      final status = await checkPermission(2);
      if (status != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(status)),
        );
        return null;
      }
      return await picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: maxDuration,
      );
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error picking video: $e')),
    );
    return null;
  }
}

Future<List<XFile>?> pickMultiImageCamera(
    BuildContext context, int type) async {
  // final picker = ImagePicker();
 

  List<XFile>? images = [];
  await navP(
    AddImagePage(
      multiple: true,
    ),
    then: (val) async{
     
      if (val != null) {
        images = val;
      }
      // return images;
    },
  );
  return images;

  // try {
  //   if (type == 1) {
  //     final status = await checkPermission(1);
  //     if (status != null) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(content: Text(status)),
  //       );
  //       return null;
  //     }
  //     final file = await picker.pickImage(source: ImageSource.camera);
  //     return file != null ? [file] : null;
  //   } else {
  //     final status = await checkPermission(2);
  //     if (status != null) {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(content: Text(status)),
  //       );
  //       return null;
  //     }
  //     return await picker.pickMultiImage();
  //   }
  // } catch (e) {
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(content: Text('Error picking images: $e')),
  //   );
  //   return null;
  // }
}
