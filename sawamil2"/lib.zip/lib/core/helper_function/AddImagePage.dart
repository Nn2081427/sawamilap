import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:sizer/sizer.dart';
import 'package:swamiil/core/constants/constants.dart';
import 'package:swamiil/core/helper_function/loading.dart';
import 'package:swamiil/core/theme/text_style.dart';
import 'package:swamiil/core/theme/theme.dart';
import 'package:swamiil/core/widgets/custom_button.dart';

import '../../../../../core/helper_function/navigation.dart';

class AddImagePage extends StatefulWidget {
  final bool multiple;
  const AddImagePage({super.key, required this.multiple});

  @override
  State<AddImagePage> createState() => _AddImagePageState();
}

class _AddImagePageState extends State<AddImagePage>
    with TickerProviderStateMixin {
  CameraController? _controller;
  double _currentZoomLevel = 1.0;
  double _maxZoomLevel = 1.0;
  double _minZoomLevel = 1.0;
  XFile? image;
  bool clicked = false;
  List<XFile> images = [];
  bool _isFlashOn = false;
  late AnimationController _captureAnimationController;
  late AnimationController _flashAnimationController;
  late Animation<double> _captureAnimation;
  late Animation<double> _flashAnimation;

  @override
  void initState() {
    super.initState();
    _captureAnimationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    _flashAnimationController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _captureAnimation = Tween<double>(begin: 1.0, end: 0.8).animate(
      CurvedAnimation(
          parent: _captureAnimationController, curve: Curves.easeInOut),
    );
    _flashAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
          parent: _flashAnimationController, curve: Curves.easeInOut),
    );
    _initializeCamera();
  }

  @override
  void dispose() {
    _captureAnimationController.dispose();
    _flashAnimationController.dispose();
    try {
      if (_controller != null) {
        _controller!.dispose();
      }
    } catch (e) {
      print('Error disposing camera controller: $e');
    }
    super.dispose();
  }

  void _save() {
    if (_controller == null || !_controller!.value.isInitialized) {
      _showSnackBar('Camera is not ready yet', isError: true);
      return;
    }

    if (widget.multiple) {
      if (images.isNotEmpty) {
        _cleanupCameraBeforeNavigating();
        navPop(images);
      } else {
        _showSnackBar('Please capture at least one image', isError: true);
      }
    } else {
      loading();
      _controller?.takePicture().then((val) async {
        image = val;
        navPop();
        await Future.delayed(const Duration(milliseconds: 50));
        _cleanupCameraBeforeNavigating();
        navPop(image);
      }).catchError((error) {
        navPop();
        _showSnackBar('Error taking picture: $error', isError: true);
      });
    }
  }

  void _cleanupCameraBeforeNavigating() {
    try {
      if (_controller != null && _controller!.value.isInitialized) {
        _controller!.pausePreview();
      }
    } catch (e) {
      print('Error cleaning up camera: $e');
    }
  }

  void _takeImage() async {
    if (_controller == null || !_controller!.value.isInitialized) {
      _showSnackBar('Camera is not ready yet', isError: true);
      return;
    }

    // Trigger capture animation and haptic feedback
    HapticFeedback.mediumImpact();
    _captureAnimationController.forward().then((_) {
      _captureAnimationController.reverse();
    });

    // Flash effect
    _flashAnimationController.forward().then((_) {
      _flashAnimationController.reverse();
    });

    loading();

    try {
      _controller?.takePicture().then((val) async {
        try {
          final imageFile = File(val.path);
          final imageBytes = await imageFile.readAsBytes();
          final originalImage = img.decodeImage(imageBytes);

          if (originalImage == null) {
            throw Exception("Failed to decode image");
          }

          final correctedImage = img.bakeOrientation(originalImage);
          final correctedBytes = img.encodeJpg(correctedImage);
          await imageFile.writeAsBytes(correctedBytes);
          await Future.delayed(const Duration(milliseconds: 10));

          images.add(XFile(imageFile.path));

          if (mounted) {
            setState(() {});
            navPop();
            _showSnackBar('Image captured successfully!', isError: false);
          }
        } catch (error) {
          print('Error processing image: $error');
          images.add(val);
          if (mounted) {
            setState(() {});
            navPop();
          }
        }
      }).catchError((error) {
        print('Error taking picture: $error');
        if (mounted) {
          navPop();
          _showSnackBar('Error capturing image: $error', isError: true);
        }
      });
    } catch (e) {
      print('Error in _takeImage: $e');
      navPop();
      _showSnackBar('Error: $e', isError: true);
    }
  }

  void _showSnackBar(String message, {required bool isError}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(color: Colors.white, fontSize: 14),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? Colors.red.shade600 : Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: EdgeInsets.all(4.w),
      ),
    );
  }

  void _handleZoom(double scale) {
    if (_controller?.value.isInitialized != true) return;

    double factor = 0.07;
    if (scale > 1) {
      setState(() {
        _currentZoomLevel += (scale * factor);
        if (_currentZoomLevel > _maxZoomLevel) {
          _currentZoomLevel = _maxZoomLevel;
        }
        _controller?.setZoomLevel(_currentZoomLevel);
      });
    } else {
      factor = 0.2;
      if (scale < 0.4) {
        factor = 0.7;
      }
      setState(() {
        _currentZoomLevel -= (scale * factor);
        if (_currentZoomLevel < _minZoomLevel) {
          _currentZoomLevel = _minZoomLevel;
        }
        _controller?.setZoomLevel(_currentZoomLevel);
      });
    }
  }

  Future<void> _toggleFlash() async {
    if (_controller == null) return;

    try {
      setState(() {
        _isFlashOn = !_isFlashOn;
      });

      await _controller!
          .setFlashMode(_isFlashOn ? FlashMode.torch : FlashMode.off);
      HapticFeedback.lightImpact();
    } catch (e) {
      print('Error toggling flash: $e');
    }
  }

  Future<void> _toggleCamera() async {
    if (_controller == null) return;

    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        _showSnackBar('No cameras available', isError: true);
        return;
      }

      final CameraController? oldController = _controller;
      final currentCameraIndex =
          cameras.indexWhere((c) => c.name == _controller?.description.name);
      final nextCameraIndex = (currentCameraIndex + 1) % cameras.length;
      final nextCamera = cameras[nextCameraIndex];

      _controller = CameraController(nextCamera, ResolutionPreset.veryHigh,
          enableAudio: false, imageFormatGroup: ImageFormatGroup.jpeg);

      await _controller!.initialize();
      await oldController?.dispose();

      await _controller!.getMaxZoomLevel().then((val) {
        _maxZoomLevel = val < 8 ? val : 8;
      });

      await _controller!.getMinZoomLevel().then((val) {
        _minZoomLevel = val;
      });

      _currentZoomLevel = 1.0;

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print('Error toggling camera: $e');
      _showSnackBar('Error switching camera: $e', isError: true);
    }
  }

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        if (mounted) {
          _showSnackBar('No cameras available', isError: true);
        }
        return;
      }

      _controller = CameraController(cameras[0], ResolutionPreset.veryHigh,
          enableAudio: false, imageFormatGroup: ImageFormatGroup.jpeg);

      await _controller!.initialize();

      if (!mounted) return;

      await _controller!.getMaxZoomLevel().then((val) {
        if (mounted) {
          _maxZoomLevel = val < 8 ? val : 8;
        }
      });

      await _controller!.getMinZoomLevel().then((val) {
        if (mounted) {
          _minZoomLevel = val;
        }
      });

      try {
        final minExposure = await _controller!.getMinExposureOffset();
        await _controller!.setExposureOffset(minExposure);
      } catch (e) {
        print('Error setting exposure: $e');
      }

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      print('Error initializing camera: $e');
      if (mounted) {
        _showSnackBar('Error initializing camera: $e', isError: true);
      }
    }
  }

  Widget _buildModernButton({
    required IconData icon,
    required VoidCallback onTap,
    String? label,
    Color? backgroundColor,
    Color? iconColor,
    double? size,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: backgroundColor ?? Colors.black.withOpacity(0.6),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: iconColor ?? Colors.white,
              size: size ?? (Constants.isTablet ? 32 : 24),
            ),
            if (label != null) ...[
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCaptureButton() {
    return AnimatedBuilder(
      animation: _captureAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _captureAnimation.value,
          child: GestureDetector(
            onTap: widget.multiple ? _takeImage : _save,
            child: Container(
              width: 20.w,
              height: 20.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    Colors.white,
                    Colors.grey.shade200,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 15,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Container(
                margin: EdgeInsets.all(1.w),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.multiple ? Colors.red.shade500 : Colors.white,
                  border: Border.all(
                    color: Colors.grey.shade300,
                    width: 2,
                  ),
                ),
                child: Icon(
                  widget.multiple ? Icons.camera_alt : Icons.check,
                  color: widget.multiple ? Colors.white : Colors.black,
                  size: 8.w,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildZoomIndicator() {
    if (_currentZoomLevel <= 1.0) return const SizedBox.shrink();

    return Positioned(
      top: 15.h,
      left: 0,
      right: 0,
      child: Center(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.6),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.2)),
          ),
          child: Text(
            '${_currentZoomLevel.toStringAsFixed(1)}x',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (val) {
        _cleanupCameraBeforeNavigating();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: const SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
            statusBarIconBrightness: Brightness.light,
            systemNavigationBarColor: Colors.black,
          ),
          child: SizedBox(
            width: 100.w,
            height: 100.h,
            child: Stack(
              children: [
                // Camera Preview
                SizedBox(
                  width: 100.w,
                  height: 100.h,
                  child: (_controller == null ||
                          !_controller!.value.isInitialized)
                      ? Container(
                          color: Colors.black,
                          child: const Center(
                            child: CircularProgressIndicator(
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          ),
                        )
                      : ClipRect(
                          child: GestureDetector(
                            onScaleUpdate: (ScaleUpdateDetails details) {
                              _handleZoom(details.scale);
                            },
                            child: CameraPreview(_controller!),
                          ),
                        ),
                ),

                // Flash overlay
                AnimatedBuilder(
                  animation: _flashAnimation,
                  builder: (context, child) {
                    return _flashAnimation.value > 0
                        ? Container(
                            width: 100.w,
                            height: 100.h,
                            color: Colors.white
                                .withOpacity(_flashAnimation.value * 0.8),
                          )
                        : const SizedBox.shrink();
                  },
                ),

                // Zoom indicator
                _buildZoomIndicator(),

                // Top controls
                Positioned(
                  top: 8.h,
                  left: 0,
                  right: 0,
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildModernButton(
                          icon: Icons.arrow_back_ios_new,
                          onTap: () {
                            _cleanupCameraBeforeNavigating();
                            navPop();
                          },
                        ),
                        _buildModernButton(
                          icon: _isFlashOn ? Icons.flash_on : Icons.flash_off,
                          onTap: _toggleFlash,
                          backgroundColor: _isFlashOn
                              ? Colors.yellow.withOpacity(0.8)
                              : Colors.black.withOpacity(0.6),
                          iconColor: _isFlashOn ? Colors.black : Colors.white,
                        ),
                      ],
                    ),
                  ),
                ),

                // Image gallery for multiple mode
                if (images.isNotEmpty && widget.multiple)
                  Positioned(
                    bottom: 25.h,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 12.h,
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: images.length,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: EdgeInsets.only(right: 3.w),
                            child: Stack(
                              children: [
                                Container(
                                  width: 18.w,
                                  height: 12.h,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.5),
                                      width: 2,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.3),
                                        blurRadius: 8,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.file(
                                      File(images[index].path),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: -1.w,
                                  right: -1.w,
                                  child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        images.removeAt(index);
                                      });
                                      HapticFeedback.lightImpact();
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(1.w),
                                      decoration: const BoxDecoration(
                                        color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        Icons.close,
                                        color: Colors.white,
                                        size: 4.w,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                // Bottom controls
                Positioned(
                  bottom: 6.h,
                  left: 0,
                  right: 0,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 6.w, vertical: 3.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        _buildModernButton(
                          icon: Icons.flip_camera_ios,
                          onTap: _toggleCamera,
                          label: "Flip",
                        ),

                        // Main capture button
                        _buildCaptureButton(),

                        // Save/Gallery button
                        if ((widget.multiple && images.isNotEmpty) ||
                            !widget.multiple)
                          _buildModernButton(
                            icon: widget.multiple
                                ? Icons.check
                                : Icons.photo_library,
                            onTap: _save,
                            label: widget.multiple ? "Done" : "Gallery",
                            backgroundColor: Colors.green.withOpacity(0.8),
                          )
                        else
                          SizedBox(width: 15.w),
                      ],
                    ),
                  ),
                ),

                // Image count indicator for multiple mode
                if (widget.multiple && images.isNotEmpty)
                  Positioned(
                    top: 12.h,
                    right: 4.w,
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(20),
                        border:
                            Border.all(color: Colors.white.withOpacity(0.3)),
                      ),
                      child: Text(
                        '${images.length} ${images.length == 1 ? 'Photo' : 'Photos'}',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
