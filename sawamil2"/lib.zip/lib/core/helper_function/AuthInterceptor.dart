import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:swamiil/core/helper_function/api.dart';
import 'package:swamiil/core/helper_function/appSecureStore.dart';
import 'package:swamiil/core/helper_function/navigation.dart';
import 'package:swamiil/features/splash/Presentation/screens/intro_screen.dart';
import 'package:swamiil/main.dart';

import '../constants/constants.dart';

class AuthInterceptor extends Interceptor {
  final BuildContext? _context;
  bool _isShowingDialog = false;
  bool _isRefreshing = false;
  final Dio _dio = Dio(); // Separate Dio instance for token refresh

  AuthInterceptor({BuildContext? context}) : _context = context;

  @override
  Future<void> onError(
      DioException err, ErrorInterceptorHandler handler) async {
    talker.info('Error occurred: ${err.message}');
    talker.info('Error type: ${err.type}');
    talker.info('Response status: ${err.response?.statusCode}');
    talker.info('Request path: ${err.requestOptions.path}');
    
    // Check for 401 error
    if (err.response?.statusCode == 401) {
      talker.info('401 error occurred - attempting token refresh');
      
      // Prevent multiple simultaneous refresh attempts
      if (_isRefreshing) {
        talker.info('Token refresh already in progress, waiting...');
        await Future.delayed(const Duration(milliseconds: 500));
        // Try the request again with potentially updated token
        try {
          final response = await _retryRequest(err.requestOptions);
          return handler.resolve(response);
        } catch (e) {
          return handler.next(err);
        }
      }
      
      _isRefreshing = true;
      
      try {
        final isRefreshed = await _refreshToken();
        if (isRefreshed) {
          talker.info('Token refreshed successfully, retrying request');
          final response = await _retryRequest(err.requestOptions);
          return handler.resolve(response);
        } else {
          talker.error('Token refresh failed, handling unauthorized');
          await _handleUnauthorized();
          return handler.next(err);
        }
      } catch (e) {
        talker.error('Exception during token refresh: $e');
        await _handleUnauthorized();
        return handler.next(err);
      } finally {
        _isRefreshing = false;
      }
    }
    
    return handler.next(err);
  }

  Future<bool> _refreshToken() async {
    try {
      talker.info('Refreshing token...');

      // Get the current token
      final token = await AuthSecureStorage.getAccessToken();
      talker.info('Retrieved token from storage: ${token != null ? 'exists' : 'null'}');

      // Check if token exists
      if (token == null || token.isEmpty) {
        talker.error('No token found for refresh');
        return false;
      }

      // Configure the refresh dio instance without interceptors to avoid loops
      _dio.options = BaseOptions(
        baseUrl: Constants.domainApi,
        headers: {
          'Content-Type': 'application/json',
        },
      );

      final response = await _dio.post(
        'refresh_token', // Remove leading slash if Constants.domainApi already has it
        data: {'token': token},
        options: Options(
          validateStatus: (status) => status != null && status < 500,
        ),
      );

      talker.info('Token refresh response status: ${response.statusCode}');
      talker.info('Token refresh response data: ${response.data}');

      if (response.statusCode == 200 && response.data != null) {
        final responseData = response.data;
        final newToken = responseData['token'] ?? responseData['access_token'];

        if (newToken != null && newToken.toString().isNotEmpty) {
          await AuthSecureStorage.saveAccessToken(newToken.toString());
          ApiHandel.getInstance.updateHeader(newToken.toString());
          talker.info('Token refreshed and saved successfully');
          return true;
        } else {
          talker.error('New token not found in response');
          return false;
        }
      }

      talker.error('Token refresh failed with status: ${response.statusCode}');
      return false;
    } catch (e) {
      talker.error('Token refresh failed with exception: $e');
      return false;
    }
  }

  Future<Response<dynamic>> _retryRequest(RequestOptions requestOptions) async {
    // Get the updated token for the retry
    final newToken = await AuthSecureStorage.getAccessToken();
    
    // Update headers with new token
    final headers = Map<String, dynamic>.from(requestOptions.headers);
    if (newToken != null && newToken.isNotEmpty) {
      headers['Authorization'] = newToken;
    }

    final options = Options(
      method: requestOptions.method,
      headers: headers,
      contentType: requestOptions.contentType,
      responseType: requestOptions.responseType,
      validateStatus: (status) => status != null && status < 500,
    );

    // Use the main dio instance (not _dio) for the retry to maintain consistency
    return ApiHandel.getInstance.dio.request<dynamic>(
      requestOptions.path,
      data: requestOptions.data,
      queryParameters: requestOptions.queryParameters,
      options: options,
    );
  }

  Future<void> _handleUnauthorized() async {
    if (_isShowingDialog) return;

    // Clear tokens
    await AuthSecureStorage.clearAuthData();

    final context = _context ?? Constants.globalContext();

    if (context != null && context.mounted) {
      _isShowingDialog = true;

      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext dialogContext) => WillPopScope(
          onWillPop: () async => false,
          child: AlertDialog(
            title: const Text("Session Expired"),
            content:
                const Text("Your session has expired. Please login again."),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(dialogContext).pop();
                  _isShowingDialog = false;
                  navPARU(const OnboardingScreen());
                },
                child: const Text("Login"),
              ),
            ],
          ),
        ),
      );
    }
  }
}