import 'dart:convert';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:time_machine/time_machine.dart' as time;
import 'package:swamiil/core/theme/app_colors.dart';
import '../constants/constants.dart';

//Jan 1, 2024 12:00 AM
String convertDateTimeToString(DateTime dateTime) {
  return DateFormat(
          'MMM d, y hh:mm a', Constants.globalContext().locale.languageCode)
      .format(
          dateTime); //DateFormat('MMM d, y hh:mm a', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

//1 Jan, 2024 12:00 AM
String convertDateTimeToStringDMY(DateTime dateTime) {
  return DateFormat(
          'd-M-y hh:mm a', Constants.globalContext().locale.languageCode)
      .format(
          dateTime); //DateFormat('d-M-y hh:mm a', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

String convertOperationDateTime(DateTime dateTime) {
  return DateFormat('d/M', Constants.globalContext().locale.languageCode).format(
      dateTime); //DateFormat('d/M', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false)
}

String convertDateToPM(String dateTime) {
  DateTime time = DateFormat("HH:mm:ss").parse(dateTime);
  String formattedTime = DateFormat('h:mm a').format(time);
  return formattedTime;
}

//2:00
String convertDateToStringHM(DateTime dateTime) {
  return DateFormat('HH:mm', 'en').format(dateTime);
}

//2:00:00
String convertDateToStringHMS(DateTime dateTime) {
  return DateFormat('HH:mm:ss', 'en').format(dateTime);
}

//2024-04-15
String convertDateToStringYMD(DateTime dateTime) {
  return DateFormat('yyyy-M-d', 'en').format(dateTime);
}

String checkDateIfNull(dynamic dateTime) {
  return dateTime == "null" || dateTime == null
      ? ""
      : DateFormat(
              'MMM d, y hh:mm a', Constants.globalContext().locale.languageCode)
          .format(DateTime.parse(
              dateTime)); //DateFormat('MMM d, y hh:mm a', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(DateTime.parse(dateTime));
}

String getDayName(DateTime date) {
  DateFormat dayFormat = DateFormat(
      'EEEE',
      Constants.globalContext()
          .locale
          .languageCode); //DateFormat('EEEE', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode);
  String dayName = dayFormat.format(date);

  return dayName;
}

//31-3-2024
String convertDateToStringDMY(DateTime dateTime) {
  // Extract the date components
  final day = dateTime.day.toString().padLeft(2, '0');
  final month = dateTime.month.toString().padLeft(2, '0');
  final year = dateTime.year.toString();

  // Concatenate the components with the desired format
  return '$day/$month/$year';
}

// sunday
String getDayNameFromDate(DateTime dateTime) {
  return DateFormat('EEEE', Constants.globalContext().locale.languageCode).format(
      dateTime); //DateFormat('EEEE', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

String convertDateToStringWithDay(DateTime dateTime) {
  final languageCode = Constants.globalContext()
      .locale
      .languageCode; //Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode;
  final currentYear = DateTime.now().year;
  final formatter = DateFormat(
    dateTime.year == currentYear
        ? 'EEEE d MMMM' // بدون السنة إذا كانت نفس السنة
        : 'EEEE d MMMM y', // مع السنة إذا كانت مختلفة
    languageCode,
  );

  return formatter.format(dateTime);
}

//Apr 15, 2024
DateFormat convertDateToString(DateTime dateTime) {
  return DateFormat(
      'd MMM y',
      Constants.globalContext()
          .locale
          .languageCode); //DateFormat('d MMM y', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

DateFormat convertDateWithoutYear(DateTime dateTime) {
  return DateFormat(
      'd MMM',
      Constants.globalContext()
          .locale
          .languageCode); //DateFormat('d MMM', Provider.of<LanguageProvider>(Constants.globalContext()  , listen: false).appLocal.languageCode).format(dateTime);
}

DateFormat convertDateToStringWithLines(DateTime dateTime) {
  return DateFormat(
      'd\n MMM\n y',
      Constants.globalContext()
          .locale
          .languageCode); //DateFormat('d\n MMM\n y', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

String convertTo12HourFormat(String time24) {
  DateTime dateTime = DateFormat("HH:mm:ss").parse(time24);
  return DateFormat("hh:mm a", Constants.globalContext().locale.languageCode)
      .format(
          dateTime); //DateFormat("hh:mm a", Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

// 15 Apr 2024
String convertDateToStringDMMMY(DateTime dateTime) {
  return DateFormat('d MMM y', Constants.globalContext().locale.languageCode)
      .format(
          dateTime); //DateFormat('d MMM y', Provider.of<LanguageProvider>(Constants.globalContext(), listen: false).appLocal.languageCode).format(dateTime);
}

int convertStringToInt(dynamic value) {
  if (value == null) {
    return 0;
  } else if (value is int) {
    return value;
  } else if (int.tryParse(value) != null) {
    return int.parse(value);
  }
  return 0;
}
int? convertStringToIntNull(dynamic value) {
  if (value == null) {
    return null;
  } else if (value is int) {
    return value;
  } else if (int.tryParse(value) != null) {
    return int.parse(value);
  }
  return 0;
}

num convertDataToNum(dynamic value) {
  if (value is num) {
    return value;
  } else if (num.tryParse(value) != null) {
    return num.parse(value);
  }
  return 0;
}

double convertDataToDouble(dynamic value) {
  if (value == null) {
    return 0;
  } else if (value is int) {
    return value.toDouble();
  } else if (value is String) {
    return double.parse(value);
  } else {
    return value;
  }
}

String convertMapToString(Map data) {
  String msg = '';
  data.forEach((key, value) {
    if (value is List) {
      msg += value.join('\n');
      msg += "\n";
    } else if (value is String) {
      msg += "$value\n";
    }
  });
  if (msg.endsWith('\n')) {
    msg = msg.substring(0, msg.length - 1);
  }
  return msg;
}

bool convertDataToBool(dynamic data) {
  if (data == null) {
    return false;
  } else if (data is num) {
    return data == 1;
  } else if (data is String) {
    if (int.tryParse(data) == null) {
      return data == 'yes';
    }
    return convertStringToInt(data) == 1;
  } else {
    return data;
  }
}

Map convertStringToMap(String data) {
  String jsonString = data
      .replaceAll('{', '{"')
      .replaceAll('}', '"}')
      .replaceAll('=', '":"')
      .replaceAll(', ', '","');
  return jsonDecode(jsonString);
}

String convertSecToMin(int sec) {
  int minutes = sec ~/ 60;
  int seconds = sec % 60;

  return '$minutes:${seconds.toString().padLeft(2, '0')}';
}

String getDiffTime(DateTime dateTime) {
  DateTime now = DateTime.now();
  time.LocalDate a = time.LocalDate.dateTime(dateTime);
  time.LocalDate b = time.LocalDate.dateTime(now);

  time.Period diff = b.periodSince(a);
  int years = diff.years;
  // years = now.year-noti.year;
  int month = 0;
  if (years == 0) {
    // month = now.month-noti.month;
    month = diff.months;
  }
  int days = 0;
  if (years == 0 && month == 0) {
    days = diff.days;
  }
  int hours = 0;
  if (days == 0 && years == 0 && month == 0) {
    hours = now.hour - dateTime.hour;
  }
  int min = 0;
  if (hours == 0 && days == 0 && years == 0 && month == 0) {
    min = now.minute - dateTime.minute;
  }
  int sec = 0;
  if (min == 0 && hours == 0 && days == 0 && years == 0 && month == 0) {
    sec = now.second + 10 - dateTime.second;
  }
  return '${'ago'.tr()} ${getTimeNumber(years, month, days, hours, min, sec)} ${getTimeChar(years, month, days, hours, min, sec)}';
}

String getTimeNumber(int year, int month, int day, int h, int m, int s) {
  if (year != 0) {
    return '$year';
  } else if (month != 0) {
    return '$month';
  } else if (day != 0) {
    return '$day';
  } else if (h != 0) {
    return '$h';
  } else if (m != 0) {
    return '$m';
  } else if (s != 0) {
    return '$s';
  }
  return '';
}

String getTimeChar(int year, int month, int day, int h, int m, int s) {
  if (year != 0) {
    return 'year'.tr();
  } else if (month != 0) {
    return 'month'.tr();
  } else if (day != 0) {
    return 'day'.tr();
  } else if (h != 0) {
    return 'hour'.tr();
  } else if (m != 0) {
    return 'min'.tr();
  } else if (s != 0) {
    return 'sec'.tr();
  }
  return '';
}

String getMediaType(String url) {
  if (url.endsWith('.mp4') || url.endsWith('.avi') || url.endsWith('.mov')) {
    return 'video';
  } else if (url.endsWith('.jpg') ||
      url.endsWith('.png') ||
      url.endsWith('.gif')) {
    return 'image';
  } else if (url.endsWith('.mp3') || url.endsWith('.wav')) {
    return 'audio';
  } else {
    // Default to unknown type or handle other types as needed
    return url;
  }
}

double convertRgbToHue(int color) {
  int red = (color >> 16) & 0xff;
  int green = (color >> 8) & 0xff;
  int blue = color & 0xff;

  double r = red / 255.0;
  double g = green / 255.0;
  double b = blue / 255.0;

  double max = r > g ? (r > b ? r : b) : (g > b ? g : b);
  double min = r < g ? (r < b ? r : b) : (g < b ? g : b);

  double hue;
  // double saturation;
  // double lightness = (max + min) / 2.0;

  if (max == min) {
    hue = 0.0; // achromatic
  } else {
    double d = max - min;
    // saturation = lightness > 0.5 ? d / (2.0 - max - min) : d / (max + min);
    if (max == r) {
      hue = (g - b) / d + (g < b ? 6.0 : 0.0);
    } else if (max == g) {
      hue = (b - r) / d + 2.0;
    } else {
      hue = (r - g) / d + 4.0;
    }
    hue /= 6.0;
  }

  // Scale hue to the range [0, 360]
  return hue * 360.0;
}

String formatNumber(int number) {
  if (number >= 1000000) {
    double result = number / 1000000;
    return '${result.toStringAsFixed(1)}M';
  } else if (number >= 1000) {
    double result = number / 1000;
    return '${result.toStringAsFixed(1)}K';
  } else {
    return number.toString();
  }
}

String formatTimeToAm(DateTime dateTime) {
  // Create a formatter for the time pattern
  final timeFormatter =
      DateFormat('h:mm a', Constants.globalContext().locale.languageCode);

  // Format the DateTime object to a string
  return timeFormatter.format(dateTime);
}

Color hexToColor(String code) {
  if (int.tryParse('0xFF$code') != null) {
    return Color(int.parse('0xFF$code'));
  }
  return Color(int.parse('0xFF${AppColors.mainColor}'));
}

int convertToSeconds(String time) {
  List<String> parts = time.split(':');
  int minutes = int.parse(parts[0]);
  int seconds = int.parse(parts[1]);
  return (minutes * 60) + seconds;
}

String convertTwoDateRange(
    {required DateTime fromDate, required DateTime toDate}) {
  String language = Constants.globalContext().locale.languageCode;
  String formattedDateRange = fromDate.year == toDate.year
      ? "${DateFormat('dd MMMM', 'ar').format(fromDate)} - ${DateFormat('dd MMMM ,yyyy', language).format(toDate)}"
      : "${DateFormat('dd MMMM ,yyyy', 'ar').format(fromDate)} - ${DateFormat('dd MMMM ,yyyy', language).format(toDate)}";
  return formattedDateRange;
}

bool convertStringToBool({required String data}) {
  if (data == "true") {
    return true;
  }
  return false;
}

String formatPrice(num price) {
  if (price > 1000000) {
    String priceFormatted = (price / 1000000).toStringAsFixed(1);
    if (priceFormatted.endsWith(".0")) {
      priceFormatted = priceFormatted.substring(0, priceFormatted.length - 2);
    }
    return "$priceFormatted${Constants.globalContext().locale.languageCode}";
  } else {
    final formatter = NumberFormat("#,##0.00");
    String priceFormatted = formatter.format(price);
    if (priceFormatted.endsWith(".00")) {
      priceFormatted = priceFormatted.substring(0, priceFormatted.length - 3);
    }
    return priceFormatted;
  }
}
//    String formatPrice(num price) {
//   if (price > 1000000) {
//     String priceFormatted = (price / 1000000).toStringAsFixed(1);
//     if (priceFormatted.endsWith(".0")) {
//       priceFormatted = priceFormatted.substring(0, priceFormatted.length - 2);
//     }
//     return "$priceFormatted${Constants.globalContext().locale.languageCode}";
//   } else {
//     final formatter = NumberFormat("#,##0.00");
//     String priceFormatted = formatter.format(price);
//     if (priceFormatted.endsWith(".00")) {
//       priceFormatted = priceFormatted.substring(0, priceFormatted.length - 3);
//     }
//     return priceFormatted;
//   }
//   }

// }

DateTime addMonths(DateTime date, int months) {
  int newMonth = date.month + months;
  int yearOffset = (newMonth - 1) ~/ 12;
  int finalMonth = ((newMonth - 1) % 12) + 1;
  int finalYear = date.year + yearOffset;
  int maxDaysInMonth = DateTime(finalYear, finalMonth + 1, 0).day;
  int finalDay = date.day > maxDaysInMonth ? maxDaysInMonth : date.day;

  return DateTime(
      finalYear, finalMonth, finalDay, date.hour, date.minute, date.second);
}

String getTimeAgo(DateTime dateTime) {
  if (dateTime == null) return '';

  final now = DateTime.now();
  final difference = now.difference(dateTime);

  final languageCode = Constants.globalContext().locale.languageCode;

  if (difference.isNegative) {
    return tr('just_now');
  }

  final seconds = difference.inSeconds;
  final minutes = difference.inMinutes;
  final hours = difference.inHours;
  final days = difference.inDays;
  final months = (days / 30).floor();
  final years = (days / 365).floor();

  if (seconds < 60) {
    return tr('just_now');
  } else if (minutes < 60) {
    return tr(
      minutes == 1 ? 'minutes_ago' : 'minutes_ago_plural',
      args: [minutes.toString()],
      namedArgs: {'count': minutes.toString()},
    );
  } else if (hours < 24) {
    return tr(
      hours == 1 ? 'hours_ago' : 'hours_ago_plural',
      args: [hours.toString()],
      namedArgs: {'count': hours.toString()},
    );
  } else if (days < 30) {
    return tr(
      days == 1 ? 'days_ago' : 'days_ago_plural',
      args: [days.toString()],
      namedArgs: {'count': days.toString()},
    );
  } else if (months < 12) {
    return tr(
      months == 1 ? 'months_ago' : 'months_ago_plural',
      args: [months.toString()],
      namedArgs: {'count': months.toString()},
    );
  } else {
    return tr(
      years == 1 ? 'years_ago' : 'years_ago_plural',
      args: [years.toString()],
      namedArgs: {'count': years.toString()},
    );
  }
}
