// import 'package:get_it/get_it.dart';
// import 'package:swamiil/core/helper_function/api.dart';
// import 'package:swamiil/features/offers/data/data_source/offers_remote_data_source.dart';
// import 'package:swamiil/features/offers/data/repos/offers_repo_Impl.dart';
// import 'package:swamiil/features/offers/domain/use_case/offers_use_case.dart';
// import 'package:swamiil/features/offers/Presentation/cubits/offers_cubit/offers_cubit.dart';
// import 'package:swamiil/features/orders/Presentation/cubits/new_order_cubit/new_order_cubit.dart';
// import 'package:swamiil/features/orders/data/data_source/order_remote_data_source.dart';
// import 'package:swamiil/features/orders/data/repos/order_repo_Impl.dart';
// import 'package:swamiil/features/orders/domain/use_case/order_use_case.dart';
// import 'package:swamiil/features/rate/data/data_source/rate_remote_data_source.dart';
// import 'package:swamiil/features/rate/data/repos/rate_repo_Impl.dart';
// import 'package:swamiil/features/rate/domain/use_case/rate_use_case.dart';
// import 'package:swamiil/features/rate/presentation/cubits/rate_cubit/rate_cubit.dart';
// import 'package:swamiil/features/suppliers_profile/data/data_source/supplier_profile_remote_data_source.dart';

import 'package:get_it/get_it.dart';
import 'package:swamiil/features/Home/Presentation/cubits/home%20cubit/home_cubit.dart';
import 'package:swamiil/features/Home/data/repos/home_repo_Impl.dart';
import 'package:swamiil/features/Home/domain/repos/home_repo.dart';
import 'package:swamiil/features/Home/domain/use_case/home_use_case.dart';
import 'package:swamiil/features/auth_supplier/data/repositries/supplier_auth_repo_Impl.dart';
import 'package:swamiil/features/auth_supplier/domain/use_cases/supplier_auth_use_case.dart';
import 'package:swamiil/features/brands/presentation/cubits/brands%20type%20cubit/brands_type_cubit.dart';
import 'package:swamiil/features/chat/Presentation/cubits/chat_cubit/chat_cubit.dart';
import 'package:swamiil/features/chat/Presentation/cubits/cubit/messages_cubit.dart';
import 'package:swamiil/features/chat/data/repos/chat_repository_impl.dart';
import 'package:swamiil/features/chat/domain/use_case/chat_use_case.dart';
import 'package:swamiil/features/city/domain/repositories/template_repository.dart';
import 'package:swamiil/features/city/presentation/cubit/area_cubit/area_cubit.dart';
import 'package:swamiil/features/offers/Presentation/cubits/supplier_offers_cubit/supplier_offers_cubit.dart';
import 'package:swamiil/features/orders/Presentation/cubits/waiting_order_cubit/waiting_order_cubit.dart';
import 'package:swamiil/features/profile/Presentation/cubits/settings_cubit/settings_cubit.dart';
import 'package:swamiil/features/profile/domain/repositries/settings_repo.dart';
import 'package:swamiil/features/profile/domain/usecases/settings_use_case.dart';
import 'package:swamiil/features/rate/data/repos/rate_repo_Impl.dart';
import 'package:swamiil/features/rate/domain/repos/rate_repo.dart';
import 'package:swamiil/features/rate/domain/use_case/rate_use_case.dart';
import 'package:swamiil/features/rate/presentation/cubits/rate_cubit/rate_cubit.dart';
import 'package:swamiil/features/user_auth/Data/repositories/auth_imply_repository.dart';
import 'package:swamiil/features/user_auth/Domain/repositories/auth_contract_repository.dart';
import 'package:swamiil/features/user_auth/Domain/usecases/auth_use_Case.dart';
import 'package:swamiil/features/user_auth/presentation/cubit/auth_cubit.dart';

import '../../features/Home/data/data_source/home_remote_data_source.dart';
import '../../features/auth_supplier/domain/repositries/supplier_auth_repo.dart';
import '../../features/auth_supplier/presentation/cubits/auth_supplier/auth_supplier_cubit.dart';
import '../../features/brands/data/repositories/brands_repository_impl.dart';
import '../../features/brands/domain/repositories/brands_contract_repository.dart';
import '../../features/brands/domain/usecases/get_brands_use_case.dart';
import '../../features/brands/presentation/cubits/brands cubit/brands_cubit.dart';
import '../../features/chat/domain/repos/chat_repository.dart';
import '../../features/city/data/repositories/template_repository_impl.dart';
import '../../features/city/domain/usecases/get_template.dart';
import '../../features/city/presentation/cubit/cities_cubit.dart';
import '../../features/favourite/data/repositories/favourites_imply_repo.dart';
import '../../features/favourite/domain/repositories/favourites_contract_repo.dart';
import '../../features/favourite/domain/usecases/favourites_use_cases.dart';
import '../../features/favourite/presentation/cubit/favourites_cubit_cubit.dart';
import '../../features/offers/Presentation/cubits/offers_cubit/offers_cubit.dart';
import '../../features/offers/data/data_source/offers_remote_data_source.dart';
import '../../features/offers/data/repos/offers_repo_Impl.dart';
import '../../features/offers/domain/repos/offer_repo.dart';
import '../../features/offers/domain/use_case/offers_use_case.dart';
import '../../features/orders/Presentation/cubits/finished_order_cubit/finished_order_cubit.dart';
import '../../features/orders/Presentation/cubits/new_order_cubit/new_order_cubit.dart';
import '../../features/orders/Presentation/cubits/supplier_cubit/supplier_orders_cubit.dart';
import '../../features/orders/data/data_source/order_remote_data_source.dart';
import '../../features/orders/data/repos/order_repo_Impl.dart';
import '../../features/orders/domain/repos/order_repo.dart';
import '../../features/orders/domain/use_case/order_use_case.dart';
import '../../features/profile/Data/repositries/settings_repo_Impl.dart';
import '../../features/profile/Presentation/cubits/user profile cubit/user_profile_cubit.dart';
import '../../features/rate/data/data_source/rate_remote_data_source.dart';
import '../../features/suppliers_profile/Presentation/cubits/cubit/supplier_profile_cubit.dart';
import 'api.dart';

final GetIt getIt = GetIt.instance;

void setupDependencies() {
  print('Setting up dependencies at ${DateTime.now().toLocal()}'); // Debug log

  /// ===================================supplier profile===============================

  getIt.registerLazySingleton<SupplierRepo>(() => SupplierRepoImpl());

  getIt.registerLazySingleton<SupplierAuthUseCase>(
      () => SupplierAuthUseCase(supplierRepo: getIt.get<SupplierRepo>()));

  getIt.registerLazySingleton<SupplierProfileCubit>(
      () => SupplierProfileCubit(useCase: getIt.get<SupplierAuthUseCase>()));
  getIt.registerLazySingleton<AuthSupplierCubit>(() =>
      AuthSupplierCubit(supplierAuthUseCase: getIt.get<SupplierAuthUseCase>()));

  /// ===================================Brands===============================

  getIt.registerLazySingleton<BrandsContractRepository>(
      () => BrandsRepositoryImpl());

  getIt.registerLazySingleton<GetBrandsUseCase>(() => GetBrandsUseCase(
      brandsContractRepository: getIt.get<BrandsContractRepository>()));

  getIt.registerLazySingleton(
      () => BrandsCubit(brandsUseCase: getIt.get<GetBrandsUseCase>()));
  getIt.registerLazySingleton(
      () => BrandsTypeCubit(getIt.get<GetBrandsUseCase>()));

  /// =================================== Chat ===============================
  getIt.registerLazySingleton<ChatRepository>(() => ChatRepositoryImpl());

  getIt.registerLazySingleton<ChatUseCase>(
      () => ChatUseCase(repository: getIt.get<ChatRepository>()));

  getIt.registerLazySingleton<ChatCubit>(
      () => ChatCubit(getIt.get<ChatUseCase>()));
  getIt.registerLazySingleton<MessagesCubit>(
      () => MessagesCubit(chatUseCase: getIt.get<ChatUseCase>()));

  /// =================================== City ===============================
  getIt.registerLazySingleton<CityRepository>(() => CityRepositoryImpl());

  getIt.registerLazySingleton<CityUseCase>(
      () => CityUseCase(repository: getIt.get<CityRepository>()));

  getIt.registerLazySingleton<CitiesCubit>(
      () => CitiesCubit(useCase: getIt.get<CityUseCase>()));
  getIt.registerLazySingleton<AreaCubit>(
      () => AreaCubit(useCase: getIt.get<CityUseCase>()));

  /// =================================== Favorite ===============================

  getIt.registerLazySingleton<FavouritesContractRepo>(
      () => FavouritesImplyRepo());

  getIt.registerLazySingleton<FavouritesUseCases>(
      () => FavouritesUseCases(repo: getIt.get<FavouritesContractRepo>()));

  getIt.registerLazySingleton<FavouritesCubit>(
      () => FavouritesCubit(useCases: getIt.get<FavouritesUseCases>()));

  /// =================================== Home ===============================

  getIt.registerLazySingleton<HomeRemoteDataSource>(
      () => HomeRemoteDataSource(apiHandel: ApiHandel.getInstance));

  getIt.registerLazySingleton<HomeRepo>(
      () => HomeRepoImpl(homeRemoteDataSource: getIt.get()));

  getIt.registerLazySingleton<HomeUseCase>(
      () => HomeUseCase(homeRepo: getIt.get()));

  getIt.registerLazySingleton<HomeCubit>(
      () => HomeCubit(homeUseCase: getIt.get()));

  /// =================================== offers ===============================

  getIt.registerLazySingleton<OffersRemoteDataSource>(
      () => OffersRemoteDataSource(apiHandel: ApiHandel.getInstance));

  getIt.registerLazySingleton<OffersRepo>(() => OffersRepoImpl(getIt.get()));

  getIt.registerLazySingleton<OffersUseCase>(
      () => OffersUseCase(offersRepo: getIt.get()));

  getIt.registerLazySingleton<OffersCubit>(
      () => OffersCubit(offersUseCase: getIt.get()));
      
  getIt.registerFactory<SupplierOffersCubit>(
      () => SupplierOffersCubit(useCases: getIt.get()));

  /// =================================== orders ===============================

  getIt.registerLazySingleton<OrderRemoteDataSource>(
      () => OrderRemoteDataSource(apiHandel: ApiHandel.getInstance));

  getIt.registerLazySingleton<OrderRepo>(
      () => OrderRepoImpl(orderRemoteDataSource: getIt.get()));

  getIt.registerLazySingleton<OrderUseCase>(
      () => OrderUseCase(orderRepo: getIt.get()));

  getIt.registerLazySingleton<FinishedOrdersCubit>(
      () => FinishedOrdersCubit(orderUseCase: getIt.get()));
  getIt.registerLazySingleton<NewOrderCubit>(
      () => NewOrderCubit(orderUseCase: getIt.get()));

  getIt.registerLazySingleton<WaitingOrdersCubit>(
      () => WaitingOrdersCubit(orderUseCase: getIt.get()));

  getIt.registerFactory<SupplierOrdersCubit>(
      () => SupplierOrdersCubit(useCases: getIt.get<OrderUseCase>()));

  // getIt.registerLazySingleton<SupplierOrdersCubit>(() =>
  //     SupplierOrdersCubit(useCases: getIt.get()));

  // =================================== profile ===============================
  getIt.registerLazySingleton<SettingsRepo>(() => SettingsRepoImpl());
  getIt.registerLazySingleton<SettingsUseCase>(
      () => SettingsUseCase(settingsRepo: getIt.get()));
  getIt.registerLazySingleton<SettingsCubit>(() => SettingsCubit(getIt.get()));
  getIt.registerLazySingleton<UserProfileCubit>(
      () => UserProfileCubit(settingsUseCase: getIt.get()));

  // =================================== rate ===============================

  getIt.registerLazySingleton<RateRemoteDataSource>(
      () => RateRemoteDataSource(apiHandel: ApiHandel.getInstance));

  getIt.registerLazySingleton<RateRepo>(
      () => RateRepoImpl(rateRemoteDataSource: getIt.get()));

  getIt.registerLazySingleton<RateUseCase>(
      () => RateUseCase(rateRepo: getIt.get()));

  getIt.registerLazySingleton<RateCubit>(
      () => RateCubit(rateUseCase: getIt.get()));

  // =================================== auth ===============================

  getIt.registerLazySingleton<AuthContractRepository>(
      () => AuthImplyRepository());

  getIt.registerLazySingleton<AuthUseCase>(
      () => AuthUseCase(authContractRepository: getIt.get()));

  getIt.registerLazySingleton<AuthCubit>(
      () => AuthCubit(authUseCase: getIt.get()));
}
