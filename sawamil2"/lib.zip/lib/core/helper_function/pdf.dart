// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:swamiil/core/theme/text_style.dart';


// class PdfScreen extends StatefulWidget {
//   const PdfScreen({
//     super.key,
//     required this.path,
//     required this.pageNum,
//     required this.titleName,
//   });

//   final String path, titleName;
//   final int pageNum;

//   @override
//   State<PdfScreen> createState() => _PdfScreenState();
// }

// class _PdfScreenState extends State<PdfScreen> {
//   late PDFViewController _pdfViewController;
//   bool isReady = false;
//   int totalPages = 0;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(widget.titleName, style: TextStyleClass.semiBigStyle()),
//       ),
//       body: Stack(
//         children: [
//           PDFView(
//             filePath: widget.path,
//             enableSwipe: true,
//             swipeHorizontal: false,
//             autoSpacing: false,
//             pageFling: false,
//             backgroundColor: Colors.grey,
//             onRender: (pages) {
//               setState(() {
//                 totalPages = pages ?? 0;
//                 isReady = true;
//               });
//               // ⏳ التنقل للصفحة المطلوبة بعد التحميل
//               if (widget.pageNum <= totalPages) {
//                 _pdfViewController.setPage(widget.pageNum - 1);
//               }
//             },
//             onViewCreated: (PDFViewController vc) {
//               _pdfViewController = vc;
//             },
//             onPageError: (page, error) {
//             },
//           ),
//           if (!isReady)
//             const Center(child: CircularProgressIndicator()),
//         ],
//       ),
//     );
//   }
// }