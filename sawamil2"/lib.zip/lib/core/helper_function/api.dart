import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:swamiil/core/helper_function/AuthInterceptor.dart';
import 'package:swamiil/core/helper_function/appSecureStore.dart';
import 'package:swamiil/main.dart';
import '../constants/constants.dart';
import 'convert.dart';
import 'helper_function.dart';

class ApiHandel {
  static ApiHandel? _instance;
  late Dio dio;

  ApiHandel._();

  String? token;
  String? lang;
  late CancelToken cancelToken;

  static ApiHandel get getInstance {
    _instance ??= ApiHandel._(); // Instantiate if null
    return _instance!;
  }

  Future<void> init() async {
    var prefs = await SharedPreferences.getInstance();
    var token = await AuthSecureStorage.getAccessToken();

    String? language = prefs.getString("language");

    if (language != null) {
      lang = language;
    }
    dio = Dio(BaseOptions(
      baseUrl: Constants.domainApi,
      // baseUrl: Constants.domain,
      followRedirects: false,
      // will not throw errors
      validateStatus: (status) => true,
      headers: {
        "lang": lang ?? "ar",
        'Content-Type': 'application/json',
        "Authorization": token ?? ""
      },
    ));
    dio.interceptors.add(AuthInterceptor(context: navigatorKey.currentContext));

    // await Future.wait([
    //   for(var i in LanguageProvider.languages)
    //     Dio().get('${Constants.baseUri}app_languages/user/${i.languageCode}.json'),
    // ]).then((value) {
    //   Map data = {};
    //   for(int i = 0;i<LanguageProvider.languages.length;i++){
    //     data[LanguageProvider.languages[i].languageCode] = value[i].data;
    //   }
    //   languages = data;
    // });
  }

  Map languages = {};

  void cancelFunction() async {
    cancelToken.cancel();
  }

  void updateHeader(String token, {String? language}) {
    if (language != null) {
      lang = language;
    }
    dio.options = BaseOptions(
      baseUrl: Constants.domainApi,
      // baseUrl: Constants.domain,
      headers: {
        "Authorization": token,
        "lang": lang ?? "ar",
        'Content-Type': 'application/json'
      },
    );
  }

  Future<Either<DioException, Response>> get(path,
      [Map<String, dynamic>? data]) async {
    try {
      await reLogin(path);
      cancelToken = CancelToken();
      Response response =
          await dio.get(path, queryParameters: data, cancelToken: cancelToken);
      if (response.statusCode == 200 && response.data['code'] == 200) {
        return Right(response);
      }
      return Left(dioException(response));
    } on DioException catch (e) {
      // print(e.toString());
      // print(e.message);
      return Left(e.response == null ? e : dioException(e.response!));
    } catch (e) {
      // print(e.toString());
      return Left(
        DioException(
            requestOptions:
                RequestOptions(baseUrl: Constants.domainApi, path: path),
            message: 'Server Error'),
      );
    }
  }

  Future<Either<DioException, Response>> post(
      String path, Map<String, dynamic> data) async {
    talker.info(path);
    talker.info(data);

    try {
      cancelToken = CancelToken();
      Response response = await dio.post(
        path,
        data: FormData.fromMap(data),
        cancelToken: cancelToken,
      );
      if (response.statusCode == 200 && response.data['code'] == 200) {
        return Right(response);
      }
      return Left(dioException(response));
    } on DioException catch (e) {
      print(" ON $path");
      return Left(e.response == null ? e : dioException(e.response!));
    } catch (e) {
      debugPrint(e.toString());
      return Left(
        DioException(
            requestOptions:
                RequestOptions(baseUrl: Constants.domainApi, path: path),
            message: 'Server Error'),
      );
    }
  }

  DioException dioException(Response response) {
    String msg = 'Server Error';
    if (response.data is Map) {
      Map data = response.data;
      if (data['message'] is Map) {
        msg = convertMapToString(data['message']);
      } else if (data['message'] is List) {
        msg = data['message'].join('\n');
      } else {
        msg = data['message'];
      }
    }
    return DioException(
      requestOptions: response.requestOptions,
      message: msg,
      type: msg == 'Server Error'
          ? DioExceptionType.unknown
          : DioExceptionType.badResponse,
      response: response,
      error: 'Server Error',
    );
  }

  Future<Either<DioException, Response>> download(
    String path,
  ) async {
    try {
      debugPrint([path].toString());
      await reLogin(path);
      cancelToken = CancelToken();
      Response response = await dio.download(
        path, await getDownloadPath(path.split('/').last),
        cancelToken: cancelToken,
        // onReceiveProgress: Provider.of<ProgressProvider>(Constants.globalContext(), listen: false).setData
      );
      // Provider.of<ProgressProvider>(Constants.globalContext(), listen: false).clear();
      if (response.statusCode == 200 && response.data['code'] == 200) {
        return Right(response);
      }
      return Left(dioException(response));
    } on DioException catch (e) {
      print(e.error);
      // Provider.of<ProgressProvider>(Constants.globalContext(), listen: false).clear();
      return Left(e.response == null ? e : dioException(e.response!));
    } catch (e) {
      print(e.toString());
      // Provider.of<ProgressProvider>(Constants.globalContext(), listen: false).clear();
      return Left(
        DioException(
            requestOptions:
                RequestOptions(baseUrl: Constants.domainApi, path: path),
            message: 'Server Error'),
      );
    }
  }

  Future reLogin(String url) async {
    // AuthProvider authProvider =
    //     Provider.of(Constants.globalContext(), listen: false);
    // if (AuthProvider.isLogin() &&
    //     authProvider.userEntity != null &&
    //     (DateTime.now().difference(authProvider.lastLogin).inMinutes > 58) &&
    //     url != 'user/login') {
    //   await authProvider.loginButton(fromSplash: true, fromJWT: true);
    // }
  }
  // Future reLogin(String url) async {
  //   AuthProvider authProvider = Provider.of(
  //       Constants.globalContext(), listen: false);
  //   if (AuthProvider.isLogin() && authProvider.userEntity != null && (DateTime
  //       .now()
  //       .difference(authProvider.lastLogin)
  //       .inMinutes > (60*24)-2) &&
  //       (url != 'user/login' )) {
  //     // await authProvider.ref(fromSplash: true, fromJWT: true);
  //   }
  // }
}
