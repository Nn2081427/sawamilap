import 'package:flutter/material.dart';

import '../constants/constants.dart';

Future navP(className, {void Function(dynamic val)? then}) async {
  // PageTransitionType type = PageTransitionType.fade,
  await Navigator.push(Constants.globalContext(),
      MaterialPageRoute(builder: (context) => className)).then((value) {
    if (then != null) {
      then(value);
    }
    return value;
  });
}

bool canPop() {
  return Navigator.canPop(Constants.globalContext());
}

void navPR(className) {
  Navigator.pushReplacement(Constants.globalContext(),
      MaterialPageRoute(builder: (context) => className));
}

void navPARU(className) {
  Navigator.pushAndRemoveUntil(Constants.globalContext(),
      MaterialPageRoute(builder: (context) => className), (route) => false);
}

void navPop([dynamic val]) {
  Navigator.pop(Constants.globalContext(), val);
}

void navPU() {
  Navigator.popUntil(Constants.globalContext(), (route) => route.isFirst);
}
