import 'dart:convert';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

Future<String> getStreetText(LatLng latLng)async{
  String des = '';
  List<Placemark> placeMarks = await placemarkFromCoordinates(latLng.latitude,latLng.longitude);
  if (placeMarks.isNotEmpty) {
    des = placeMarks[0].street??"";
  }
  return des;
}

