import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// Storage keys

class AppSecureStore {
  static const String userToken = 'accessToken';
  static const String refreshToken = 'refreshToken';
  static const String userPassword = 'userPassword';
  static const String userNationalId = 'userNationalId';
  static const String tempToken = 'tempToken';
// const String userIdKey = 'userId';
  static const String userPasswordKey = 'userPassword';
  static const String biometricEnabledKey = 'biometricEnabled';

  static const _storage = FlutterSecureStorage(
      iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
      aOptions: AndroidOptions(
        encryptedSharedPreferences: true,
      ));

  static Future<String?> getString(String key) async {
    try {
      return await _storage.read(key: key);
    } catch (e) {
      print('Error reading secure storage: $e');
      return null;
    }
  }

  static Future<bool?> getBool(String key) async {
    try {
      final value = await _storage.read(key: key);
      if (value == null) return null;
      return value.toLowerCase() == 'true';
    } catch (e) {
      print('Error reading secure storage: $e');
      return null;
    }
  }

  static Future<void> setString(String key, String value) async {
    try {
      await _storage.write(key: key, value: value);
    } catch (e) {
      print('Error writing to secure storage: $e');
      rethrow;
    }
  }

  static Future<void> setBool(String key, bool value) async {
    try {
      await _storage.write(key: key, value: value.toString());
    } catch (e) {
      print('Error writing to secure storage: $e');
      rethrow;
    }
  }

  static Future<void> removeValue(String key) async {
    try {
      await _storage.delete(key: key);
    } catch (e) {
      print('Error removing from secure storage: $e');
      rethrow;
    }
  }

  static Future<void> clearAll() async {
    try {
      await _storage.deleteAll();
    } catch (e) {
      print('Error clearing secure storage: $e');
      rethrow;
    }
  }

  static Future<bool> containsKey(String key) async {
    try {
      return await _storage.containsKey(key: key);
    } catch (e) {
      print('Error checking key in secure storage: $e');
      return false;
    }
  }

  static Future<Map<String, String>> getAll() async {
    try {
      return await _storage.readAll();
    } catch (e) {
      print('Error reading all secure storage values: $e');
      return {};
    }
  }
}

class AuthSecureStorage {
  static Future<void> saveAccessToken(String token) async {
    await AppSecureStore.setString(AppSecureStore.userToken, token);
  }

  static Future<String?> getAccessToken() async {
    return await AppSecureStore.getString(AppSecureStore.userToken);
  }

  static Future<void> saveRefreshToken(String token) async {
    await AppSecureStore.setString(AppSecureStore.refreshToken, token);
  }

  static Future<String?> getRefreshToken() async {
    return await AppSecureStore.getString(AppSecureStore.refreshToken);
  }

  static Future<void> saveTempToken(String token) async {
    await AppSecureStore.setString(AppSecureStore.tempToken, token);
  }

  static Future<String?> getTempToken() async {
    return await AppSecureStore.getString(AppSecureStore.tempToken);
  }
  // static Future<void> saveUserId(String userId) async {
  //   await AppSecureStore.setString(userIdKey, userId);
  // }

  // static Future<String?> getUserId() async {
  //   return await AppSecureStore.getString(userIdKey);
  // }

  static Future<void> clearAuthData() async {
    await AppSecureStore.removeValue(AppSecureStore.userToken);
    // await AppSecureStore.removeValue(AppSecureStore.refreshToken);
    // await AppSecureStore.removeValue(AppSecureStore.tempToken);
    // await AppSecureStore.removeValue(userIdKey);
  }

  static Future<void> setBiometricEnabled(bool enabled) async {
    await AppSecureStore.setBool(AppSecureStore.biometricEnabledKey, enabled);
  }

  static Future<bool> isBiometricEnabled() async {
    return await AppSecureStore.getBool(AppSecureStore.biometricEnabledKey) ??
        false;
  }
}
